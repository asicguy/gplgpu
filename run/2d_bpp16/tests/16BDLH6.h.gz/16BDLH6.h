///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2014 Francis Bruno, All Rights Reserved
// 
//  This program is free software; you can redistribute it and/or modify it 
//  under the terms of the GNU General Public License as published by the Free 
//  Software Foundation; either version 3 of the License, or (at your option) 
//  any later version.
//
//  This program is distributed in the hope that it will be useful, but 
//  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
//  or FITNESS FOR A PARTICULAR PURPOSE. 
//  See the GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License along with
//  this program; if not, see <http://www.gnu.org/licenses>.
//
//  This code is available under licenses for commercial use. Please contact
//  Francis Bruno for more information.
//
//  http://www.gplgpu.com
//  http://www.asicsolutions.com
//
//  Title       :  
//  File        :  
//  Author      :  Frank Bruno
//  Created     :  14-May-2011
//  RCS File    :  $Source:$
//  Status      :  $Id:$
//
///////////////////////////////////////////////////////////////////////////////
//
//  Description : 
//  2D test suite - 16Bpp
//
//////////////////////////////////////////////////////////////////////////////
//
//  Modules Instantiated:
//
///////////////////////////////////////////////////////////////////////////////
//
//  Modification History:
//
//  $Log:$
//
//
///////////////////////////////////////////////////////////////////////////////
/* VERILOG logging on. */
/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'h500);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0x500, 0x1000000); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'h500);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h1000000+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x500, 0x1000000, 0, 0, 191, 31); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h500);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h1000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'hbf001f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 96, 0);
VR.ram_fill32(32'h140, 96, 0);
VR.ram_fill32(32'h280, 96, 0);
VR.ram_fill32(32'h3c0, 96, 0);
VR.ram_fill32(32'h500, 96, 0);
VR.ram_fill32(32'h640, 96, 0);
VR.ram_fill32(32'h780, 96, 0);
VR.ram_fill32(32'h8c0, 96, 0);
VR.ram_fill32(32'ha00, 96, 0);
VR.ram_fill32(32'hb40, 96, 0);
VR.ram_fill32(32'hc80, 96, 0);
VR.ram_fill32(32'hdc0, 96, 0);
VR.ram_fill32(32'hf00, 96, 0);
VR.ram_fill32(32'h1040, 96, 0);
VR.ram_fill32(32'h1180, 96, 0);
VR.ram_fill32(32'h12c0, 96, 0);
VR.ram_fill32(32'h1400, 96, 0);
VR.ram_fill32(32'h1540, 96, 0);
VR.ram_fill32(32'h1680, 96, 0);
VR.ram_fill32(32'h17c0, 96, 0);
VR.ram_fill32(32'h1900, 96, 0);
VR.ram_fill32(32'h1a40, 96, 0);
VR.ram_fill32(32'h1b80, 96, 0);
VR.ram_fill32(32'h1cc0, 96, 0);
VR.ram_fill32(32'h1e00, 96, 0);
VR.ram_fill32(32'h1f40, 96, 0);
VR.ram_fill32(32'h2080, 96, 0);
VR.ram_fill32(32'h21c0, 96, 0);
VR.ram_fill32(32'h2300, 96, 0);
VR.ram_fill32(32'h2440, 96, 0);
VR.ram_fill32(32'h2580, 96, 0);
VR.ram_fill32(32'h26c0, 96, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x500, 0x1000000, 0, 0, 191, 31); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h500);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h1000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'hbf001f);
/* bbird_memxfer_setup(0, 0x4200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h4200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
/* bbird_memxfer_setup(1, 0x0, 0x0, 0x0, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW1_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_CTRL,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_WKEY,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_KYDAT,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_line_pat(0x16, 0x5); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h16);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h5);
wait_for_pipe_a;
/* bbird_colors(0x1, 0x9, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
pci_burst_data(rbase_a+BACK,4'h0,32'h9);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_rectangle(0x28, 0x8, 0x3b, 0xd); */
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 40, 8, 20, 6, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h140006);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h280008);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_write_pixel(0x0, 0x2, 0x33333333); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h33333333);
pci_burst_data(rbase_a+XY0,4'h0,32'h2);
pci_burst_data(rbase_a+XY1,4'h0,32'h2);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
wait_for_pipe_a;
/* bbird_write_pixel(0x2, 0x3, 0x33333333); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h33333333);
pci_burst_data(rbase_a+XY0,4'h0,32'h20003);
pci_burst_data(rbase_a+XY1,4'h0,32'h20003);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
wait_for_pipe_a;
/* bbird_colors(0x13, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h13);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
pci_burst_data(32'h40000004, 4'h0, 32'h01020300);
/* bbird_font_write("Hello world!"); { 0x5, 0x2 } */
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 5, 2, 198, 40, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'hc60028);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h50002);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h13);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h1000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'h4c0c01);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+32'hF8,4'h0,32'h0);
/* Writing character 'H' */
/* bbird_font_cache(0, 32, 'H', 0x1); */
/* caching character 'H' */
pci_burst_data(32'ha000a000, 4'h0, 32'h0);
pci_burst_data(32'ha000a004, 4'h0, 32'h0);
pci_burst_data(32'ha000a008, 4'h0, 32'h3cc000);
pci_burst_data(32'ha000a00c, 4'h0, 32'h3e6000);
pci_burst_data(32'ha000a010, 4'h0, 32'hc0033ffc);
pci_burst_data(32'ha000a014, 4'h0, 32'he0019ffe);
pci_burst_data(32'ha000a018, 4'h0, 32'h7000cfff);
pci_burst_data(32'ha000a01c, 4'h0, 32'h3000e7ff);
pci_burst_data(32'ha000a020, 4'h0, 32'h30c0f303);
pci_burst_data(32'ha000a024, 4'h0, 32'h11e0f383);
pci_burst_data(32'ha000a028, 4'h0, 32'h3f0f3c0);
pci_burst_data(32'ha000a02c, 4'h0, 32'h7f8f3c0);
pci_burst_data(32'ha000a030, 4'h0, 32'hfccf3c0);
pci_burst_data(32'ha000a034, 4'h0, 32'hf86f3c0);
pci_burst_data(32'ha000a038, 4'h0, 32'hf03f3c0);
pci_burst_data(32'ha000a03c, 4'h0, 32'hf01f3c0);
pci_burst_data(32'ha000a040, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha000a044, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha000a048, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha000a04c, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha000a050, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha000a054, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha000a058, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha000a05c, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha000a060, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha000a064, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha000a068, 4'h0, 32'hcf00f3c0);
pci_burst_data(32'ha000a06c, 4'h0, 32'hef00f3c0);
pci_burst_data(32'ha000a070, 4'h0, 32'hf780f3c0);
pci_burst_data(32'ha000a074, 4'h0, 32'hf3c079e0);
pci_burst_data(32'ha000a078, 4'h0, 32'h31e03cf0);
pci_burst_data(32'ha000a07c, 4'h0, 32'h10f01ef8);
pci_burst_data(32'ha000a080, 4'h0, 32'h780ffc);
pci_burst_data(32'ha000a084, 4'h0, 32'h3c07fe);
pci_burst_data(32'ha000a088, 4'h0, 32'h1c0003);
pci_burst_data(32'ha000a08c, 4'h0, 32'h180001);
pci_burst_data(32'ha000a090, 4'h0, 32'h300000);
pci_burst_data(32'ha000a094, 4'h0, 32'h200000);
pci_burst_data(32'ha000a098, 4'h0, 32'h0);
pci_burst_data(32'ha000a09c, 4'h0, 32'h0);
pci_burst_data(32'ha000a0a0, 4'h0, 32'ha000);
pci_burst_data(32'ha000a0a4, 4'h0, 32'h1c28);
/* Writing character 'e' */
/* bbird_font_cache(88, 32, 'e', 0x1); */
/* caching character 'e' */
pci_burst_data(32'ha000a0b0, 4'h0, 32'h0);
pci_burst_data(32'ha000a0b4, 4'h0, 32'h0);
pci_burst_data(32'ha000a0b8, 4'h0, 32'h0);
pci_burst_data(32'ha000a0bc, 4'h0, 32'h0);
pci_burst_data(32'ha000a0c0, 4'h0, 32'h0);
pci_burst_data(32'ha000a0c4, 4'h0, 32'hf800700);
pci_burst_data(32'ha000a0c8, 4'h0, 32'h3fe01fc0);
pci_burst_data(32'ha000a0cc, 4'h0, 32'h7e387f30);
pci_burst_data(32'ha000a0d0, 4'h0, 32'h3c3e7c3c);
pci_burst_data(32'ha000a0d4, 4'h0, 32'hc3d1c3f);
pci_burst_data(32'ha000a0d8, 4'h0, 32'h33c063c);
pci_burst_data(32'ha000a0dc, 4'h0, 32'hfc01fc);
pci_burst_data(32'ha000a0e0, 4'h0, 32'hfc00fc);
pci_burst_data(32'ha000a0e4, 4'h0, 32'hc3fe81fc);
pci_burst_data(32'ha000a0e8, 4'h0, 32'h3ff07ff9);
pci_burst_data(32'ha000a0ec, 4'h0, 32'hfc01fe0);
pci_burst_data(32'ha000a0f0, 4'h0, 32'h3000780);
pci_burst_data(32'ha000a0f4, 4'h0, 32'h0);
pci_burst_data(32'ha000a0f8, 4'h0, 32'h0);
pci_burst_data(32'ha000a0fc, 4'h0, 32'h0);
pci_burst_data(32'ha000a100, 4'h0, 32'ha0b0);
pci_burst_data(32'ha000a104, 4'h0, 32'h1028);
pci_burst_data(32'ha0000000, 4'h0, 32'ha00a0a0);
pci_burst_data(32'ha0000004, 4'h0, 32'h80002);
pci_burst_data(32'ha0000008, 4'h0, 32'ha100);
pci_burst_data(32'ha000000c, 4'h0, 32'h260002);
/* Writing character 'l' */
/* bbird_font_cache(136, 32, 'l', 0x1); */
/* caching character 'l' */
pci_burst_data(32'ha000a110, 4'h0, 32'hc0800000);
pci_burst_data(32'ha000a114, 4'h0, 32'h3c3c3663);
pci_burst_data(32'ha000a118, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha000a11c, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha000a120, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha000a124, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha000a128, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha000a12c, 4'h0, 32'hf8fc3e3f);
pci_burst_data(32'ha000a130, 4'h0, 32'h2070);
pci_burst_data(32'ha000a134, 4'h0, 32'h0);
pci_burst_data(32'ha000a138, 4'h0, 32'ha110);
pci_burst_data(32'ha000a13c, 4'h0, 32'h828);
/* Writing character 'l' */
pci_burst_data(32'ha0000010, 4'h0, 32'ha00a138);
pci_burst_data(32'ha0000014, 4'h0, 32'h380002);
pci_burst_data(32'ha0000018, 4'h0, 32'ha138);
pci_burst_data(32'ha000001c, 4'h0, 32'h430002);
/* Writing character 'o' */
/* bbird_font_cache(160, 32, 'o', 0x1); */
/* caching character 'o' */
pci_burst_data(32'ha000a140, 4'h0, 32'h0);
pci_burst_data(32'ha000a144, 4'h0, 32'h0);
pci_burst_data(32'ha000a148, 4'h0, 32'h0);
pci_burst_data(32'ha000a14c, 4'h0, 32'h0);
pci_burst_data(32'ha000a150, 4'h0, 32'h0);
pci_burst_data(32'ha000a154, 4'h0, 32'h7800300);
pci_burst_data(32'ha000a158, 4'h0, 32'h9fe00fc0);
pci_burst_data(32'ha000a15c, 4'h0, 32'h7ff8dff0);
pci_burst_data(32'ha000a160, 4'h0, 32'h3e0e3f1c);
pci_burst_data(32'ha000a164, 4'h0, 32'h3c0f3c0e);
pci_burst_data(32'ha000a168, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha000a16c, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha000a170, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha000a174, 4'h0, 32'h1c3e3c1f);
pci_burst_data(32'ha000a178, 4'h0, 32'hefc1c7e);
pci_burst_data(32'ha000a17c, 4'h0, 32'h3f007f8);
pci_burst_data(32'ha000a180, 4'h0, 32'hc001e0);
pci_burst_data(32'ha000a184, 4'h0, 32'h0);
pci_burst_data(32'ha000a188, 4'h0, 32'h0);
pci_burst_data(32'ha000a18c, 4'h0, 32'h0);
pci_burst_data(32'ha000a190, 4'h0, 32'ha140);
pci_burst_data(32'ha000a194, 4'h0, 32'he28);
/* Writing character ' ' */
/* bbird_font_cache(16, 33, ' ', 0x1); */
/* caching character ' ' */
/* Writing character 'w' */
/* bbird_font_cache(16, 33, 'w', 0x1); */
/* caching character 'w' */
pci_burst_data(32'ha000a520, 4'h0, 32'h0);
pci_burst_data(32'ha000a524, 4'h0, 32'h0);
pci_burst_data(32'ha000a528, 4'h0, 32'h0);
pci_burst_data(32'ha000a52c, 4'h0, 32'h18000030);
pci_burst_data(32'ha000a530, 4'h0, 32'hc0000);
pci_burst_data(32'ha000a534, 4'h0, 32'he00);
pci_burst_data(32'ha000a538, 4'h0, 32'h7000007);
pci_burst_data(32'ha000a53c, 4'h0, 32'h80f0000);
pci_burst_data(32'ha000a540, 4'h0, 32'h1c1c1f08);
pci_burst_data(32'ha000a544, 4'h0, 32'h7e3e3e3f);
pci_burst_data(32'ha000a548, 4'h0, 32'hfcfc3d7f);
pci_burst_data(32'ha000a54c, 4'h0, 32'hbc7c7c3c);
pci_burst_data(32'ha000a550, 4'h0, 32'h3cfc3c3c);
pci_burst_data(32'ha000a554, 4'h0, 32'h3c3c7c3c);
pci_burst_data(32'ha000a558, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha000a55c, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha000a560, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha000a564, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha000a568, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha000a56c, 4'h0, 32'h3c3c7c3c);
pci_burst_data(32'ha000a570, 4'h0, 32'hfc3c3cfc);
pci_burst_data(32'ha000a574, 4'h0, 32'hfefc7c7f);
pci_burst_data(32'ha000a578, 4'h0, 32'hc7f0fcfc);
pci_burst_data(32'ha000a57c, 4'h0, 32'hcf83e0df);
pci_burst_data(32'ha000a580, 4'h0, 32'h80c701c0);
pci_burst_data(32'ha000a584, 4'h0, 32'h4200);
pci_burst_data(32'ha000a588, 4'h0, 32'h0);
pci_burst_data(32'ha000a58c, 4'h0, 32'h0);
pci_burst_data(32'ha000a590, 4'h0, 32'h0);
pci_burst_data(32'ha000a594, 4'h0, 32'h0);
pci_burst_data(32'ha000a598, 4'h0, 32'ha520);
pci_burst_data(32'ha000a59c, 4'h0, 32'h1628);
pci_burst_data(32'ha0000020, 4'h0, 32'ha00a190);
pci_burst_data(32'ha0000024, 4'h0, 32'h4d0002);
pci_burst_data(32'ha0000028, 4'h0, 32'ha598);
pci_burst_data(32'ha000002c, 4'h0, 32'h690002);
/* Writing character 'o' */
/* Writing character 'r' */
/* bbird_font_cache(80, 33, 'r', 0x1); */
/* caching character 'r' */
pci_burst_data(32'ha000a5a0, 4'h0, 32'h0);
pci_burst_data(32'ha000a5a4, 4'h0, 32'h0);
pci_burst_data(32'ha000a5a8, 4'h0, 32'h0);
pci_burst_data(32'ha000a5ac, 4'h0, 32'h0);
pci_burst_data(32'ha000a5b0, 4'h0, 32'h0);
pci_burst_data(32'ha000a5b4, 4'h0, 32'h0);
pci_burst_data(32'ha000a5b8, 4'h0, 32'h0);
pci_burst_data(32'ha000a5bc, 4'h0, 32'h30300000);
pci_burst_data(32'ha000a5c0, 4'h0, 32'h787800);
pci_burst_data(32'ha000a5c4, 4'h0, 32'hfe00fcfc);
pci_burst_data(32'ha000a5c8, 4'h0, 32'hf3f701ff);
pci_burst_data(32'ha000a5cc, 4'h0, 32'hc3e1f383);
pci_burst_data(32'ha000a5d0, 4'h0, 32'hf0e3c0f0);
pci_burst_data(32'ha000a5d4, 4'h0, 32'hc0f0e3c0);
pci_burst_data(32'ha000a5d8, 4'h0, 32'he0c0f0e1);
pci_burst_data(32'ha000a5dc, 4'h0, 32'hf0e000f0);
pci_burst_data(32'ha000a5e0, 4'h0, 32'hf0e000);
pci_burst_data(32'ha000a5e4, 4'h0, 32'h8000f0c0);
pci_burst_data(32'ha000a5e8, 4'h0, 32'hf00000f0);
pci_burst_data(32'ha000a5ec, 4'h0, 32'hf40000);
pci_burst_data(32'ha000a5f0, 4'h0, 32'hc000fc80);
pci_burst_data(32'ha000a5f4, 4'h0, 32'hf0e03cf8);
pci_burst_data(32'ha000a5f8, 4'h0, 32'hfe0f01e);
pci_burst_data(32'ha000a5fc, 4'h0, 32'hc07c0f8);
pci_burst_data(32'ha000a600, 4'h0, 32'h40380);
pci_burst_data(32'ha000a604, 4'h0, 32'h1);
pci_burst_data(32'ha000a608, 4'h0, 32'h0);
pci_burst_data(32'ha000a60c, 4'h0, 32'h0);
pci_burst_data(32'ha000a610, 4'h0, 32'h0);
pci_burst_data(32'ha000a614, 4'h0, 32'h0);
pci_burst_data(32'ha000a618, 4'h0, 32'ha5a0);
pci_burst_data(32'ha000a61c, 4'h0, 32'h1228);
pci_burst_data(32'ha0000030, 4'h0, 32'ha00a190);
pci_burst_data(32'ha0000034, 4'h0, 32'h800002);
pci_burst_data(32'ha0000038, 4'h0, 32'ha618);
pci_burst_data(32'ha000003c, 4'h0, 32'h8f0002);
/* Writing character 'l' */
/* Writing character 'd' */
/* bbird_font_cache(144, 33, 'd', 0x1); */
/* caching character 'd' */
pci_burst_data(32'ha000a620, 4'h0, 32'h0);
pci_burst_data(32'ha000a624, 4'h0, 32'h0);
pci_burst_data(32'ha000a628, 4'h0, 32'h1e000c);
pci_burst_data(32'ha000a62c, 4'h0, 32'h7f003f);
pci_burst_data(32'ha000a630, 4'h0, 32'h1fb00ff);
pci_burst_data(32'ha000a634, 4'h0, 32'h7e003f0);
pci_burst_data(32'ha000a638, 4'h0, 32'h7fe0cfc0);
pci_burst_data(32'ha000a63c, 4'h0, 32'h3e183f30);
pci_burst_data(32'ha000a640, 4'h0, 32'h3c0e3c0c);
pci_burst_data(32'ha000a644, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha000a648, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha000a64c, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha000a650, 4'h0, 32'h3c3f3c1f);
pci_burst_data(32'ha000a654, 4'h0, 32'h3cff3c7f);
pci_burst_data(32'ha000a658, 4'h0, 32'hffc1ffe);
pci_burst_data(32'ha000a65c, 4'h0, 32'h3f007f8);
pci_burst_data(32'ha000a660, 4'h0, 32'hc001e0);
pci_burst_data(32'ha000a664, 4'h0, 32'h0);
pci_burst_data(32'ha000a668, 4'h0, 32'h0);
pci_burst_data(32'ha000a66c, 4'h0, 32'h0);
pci_burst_data(32'ha000a670, 4'h0, 32'ha620);
pci_burst_data(32'ha000a674, 4'h0, 32'h1028);
pci_burst_data(32'ha0000040, 4'h0, 32'ha00a138);
pci_burst_data(32'ha0000044, 4'h0, 32'ha30002);
pci_burst_data(32'ha0000048, 4'h0, 32'ha670);
pci_burst_data(32'ha000004c, 4'h0, 32'had0002);
/* Writing character '!' */
/* bbird_font_cache(192, 33, '!', 0x1); */
/* caching character '!' */
pci_burst_data(32'ha000a680, 4'h0, 32'h0);
pci_burst_data(32'ha000a684, 4'h0, 32'h0);
pci_burst_data(32'ha000a688, 4'h0, 32'h78783030);
pci_burst_data(32'ha000a68c, 4'h0, 32'hfdfefcfc);
pci_burst_data(32'ha000a690, 4'h0, 32'hffffffff);
pci_burst_data(32'ha000a694, 4'h0, 32'h79fe7bff);
pci_burst_data(32'ha000a698, 4'h0, 32'h31fe31fe);
pci_burst_data(32'ha000a69c, 4'h0, 32'hfc01fe);
pci_burst_data(32'ha000a6a0, 4'h0, 32'hfc00fc);
pci_burst_data(32'ha000a6a4, 4'h0, 32'h780078);
pci_burst_data(32'ha000a6a8, 4'h0, 32'h780078);
pci_burst_data(32'ha000a6ac, 4'h0, 32'h300030);
pci_burst_data(32'ha000a6b0, 4'h0, 32'h0);
pci_burst_data(32'ha000a6b4, 4'h0, 32'h780030);
pci_burst_data(32'ha000a6b8, 4'h0, 32'hfc00fc);
pci_burst_data(32'ha000a6bc, 4'h0, 32'h300078);
pci_burst_data(32'ha000a6c0, 4'h0, 32'h0);
pci_burst_data(32'ha000a6c4, 4'h0, 32'h0);
pci_burst_data(32'ha000a6c8, 4'h0, 32'h0);
pci_burst_data(32'ha000a6cc, 4'h0, 32'h0);
pci_burst_data(32'ha000a6d0, 4'h0, 32'ha680);
pci_burst_data(32'ha000a6d4, 4'h0, 32'ha28);
pci_burst_data(32'ha0000050, 4'h0, 32'h200a6d0);
pci_burst_data(32'ha0000054, 4'h0, 32'hc00002);
pci_burst_data(rbase_a+32'hFC,4'h0,32'h60);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
rd(MEM_RD, 32'h40000000, 1);
wait_for_pipe_a;
/* bbird_write_pixel(0x2, 0x5, 0xcc); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'hcc);
pci_burst_data(rbase_a+XY0,4'h0,32'h20005);
pci_burst_data(rbase_a+XY1,4'h0,32'h20005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'hc0, 32'h20, "junk", 32'h500, 2'h1);
