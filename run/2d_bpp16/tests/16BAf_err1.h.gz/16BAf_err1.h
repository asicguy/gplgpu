///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2014 Francis Bruno, All Rights Reserved
// 
//  This program is free software; you can redistribute it and/or modify it 
//  under the terms of the GNU General Public License as published by the Free 
//  Software Foundation; either version 3 of the License, or (at your option) 
//  any later version.
//
//  This program is distributed in the hope that it will be useful, but 
//  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
//  or FITNESS FOR A PARTICULAR PURPOSE. 
//  See the GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License along with
//  this program; if not, see <http://www.gnu.org/licenses>.
//
//  This code is available under licenses for commercial use. Please contact
//  Francis Bruno for more information.
//
//  http://www.gplgpu.com
//  http://www.asicsolutions.com
//
//  Title       :  
//  File        :  
//  Author      :  Frank Bruno
//  Created     :  14-May-2011
//  RCS File    :  $Source:$
//  Status      :  $Id:$
//
///////////////////////////////////////////////////////////////////////////////
//
//  Description : 
//  2D test suite - 16Bpp
//
//////////////////////////////////////////////////////////////////////////////
//
//  Modules Instantiated:
//
///////////////////////////////////////////////////////////////////////////////
//
//  Modification History:
//
//  $Log:$
//
//
///////////////////////////////////////////////////////////////////////////////
/* VERILOG logging on. */
/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'h300);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0x300, 0x1000000); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'h300);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h1000000+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x300, 0x1000000, 0, 0, 287, 95); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h300);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h1000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h11f005f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 144, 0);
VR.ram_fill32(32'hc0, 144, 0);
VR.ram_fill32(32'h180, 144, 0);
VR.ram_fill32(32'h240, 144, 0);
VR.ram_fill32(32'h300, 144, 0);
VR.ram_fill32(32'h3c0, 144, 0);
VR.ram_fill32(32'h480, 144, 0);
VR.ram_fill32(32'h540, 144, 0);
VR.ram_fill32(32'h600, 144, 0);
VR.ram_fill32(32'h6c0, 144, 0);
VR.ram_fill32(32'h780, 144, 0);
VR.ram_fill32(32'h840, 144, 0);
VR.ram_fill32(32'h900, 144, 0);
VR.ram_fill32(32'h9c0, 144, 0);
VR.ram_fill32(32'ha80, 144, 0);
VR.ram_fill32(32'hb40, 144, 0);
VR.ram_fill32(32'hc00, 144, 0);
VR.ram_fill32(32'hcc0, 144, 0);
VR.ram_fill32(32'hd80, 144, 0);
VR.ram_fill32(32'he40, 144, 0);
VR.ram_fill32(32'hf00, 144, 0);
VR.ram_fill32(32'hfc0, 144, 0);
VR.ram_fill32(32'h1080, 144, 0);
VR.ram_fill32(32'h1140, 144, 0);
VR.ram_fill32(32'h1200, 144, 0);
VR.ram_fill32(32'h12c0, 144, 0);
VR.ram_fill32(32'h1380, 144, 0);
VR.ram_fill32(32'h1440, 144, 0);
VR.ram_fill32(32'h1500, 144, 0);
VR.ram_fill32(32'h15c0, 144, 0);
VR.ram_fill32(32'h1680, 144, 0);
VR.ram_fill32(32'h1740, 144, 0);
VR.ram_fill32(32'h1800, 144, 0);
VR.ram_fill32(32'h18c0, 144, 0);
VR.ram_fill32(32'h1980, 144, 0);
VR.ram_fill32(32'h1a40, 144, 0);
VR.ram_fill32(32'h1b00, 144, 0);
VR.ram_fill32(32'h1bc0, 144, 0);
VR.ram_fill32(32'h1c80, 144, 0);
VR.ram_fill32(32'h1d40, 144, 0);
VR.ram_fill32(32'h1e00, 144, 0);
VR.ram_fill32(32'h1ec0, 144, 0);
VR.ram_fill32(32'h1f80, 144, 0);
VR.ram_fill32(32'h2040, 144, 0);
VR.ram_fill32(32'h2100, 144, 0);
VR.ram_fill32(32'h21c0, 144, 0);
VR.ram_fill32(32'h2280, 144, 0);
VR.ram_fill32(32'h2340, 144, 0);
VR.ram_fill32(32'h2400, 144, 0);
VR.ram_fill32(32'h24c0, 144, 0);
VR.ram_fill32(32'h2580, 144, 0);
VR.ram_fill32(32'h2640, 144, 0);
VR.ram_fill32(32'h2700, 144, 0);
VR.ram_fill32(32'h27c0, 144, 0);
VR.ram_fill32(32'h2880, 144, 0);
VR.ram_fill32(32'h2940, 144, 0);
VR.ram_fill32(32'h2a00, 144, 0);
VR.ram_fill32(32'h2ac0, 144, 0);
VR.ram_fill32(32'h2b80, 144, 0);
VR.ram_fill32(32'h2c40, 144, 0);
VR.ram_fill32(32'h2d00, 144, 0);
VR.ram_fill32(32'h2dc0, 144, 0);
VR.ram_fill32(32'h2e80, 144, 0);
VR.ram_fill32(32'h2f40, 144, 0);
VR.ram_fill32(32'h3000, 144, 0);
VR.ram_fill32(32'h30c0, 144, 0);
VR.ram_fill32(32'h3180, 144, 0);
VR.ram_fill32(32'h3240, 144, 0);
VR.ram_fill32(32'h3300, 144, 0);
VR.ram_fill32(32'h33c0, 144, 0);
VR.ram_fill32(32'h3480, 144, 0);
VR.ram_fill32(32'h3540, 144, 0);
VR.ram_fill32(32'h3600, 144, 0);
VR.ram_fill32(32'h36c0, 144, 0);
VR.ram_fill32(32'h3780, 144, 0);
VR.ram_fill32(32'h3840, 144, 0);
VR.ram_fill32(32'h3900, 144, 0);
VR.ram_fill32(32'h39c0, 144, 0);
VR.ram_fill32(32'h3a80, 144, 0);
VR.ram_fill32(32'h3b40, 144, 0);
VR.ram_fill32(32'h3c00, 144, 0);
VR.ram_fill32(32'h3cc0, 144, 0);
VR.ram_fill32(32'h3d80, 144, 0);
VR.ram_fill32(32'h3e40, 144, 0);
VR.ram_fill32(32'h3f00, 144, 0);
VR.ram_fill32(32'h3fc0, 144, 0);
VR.ram_fill32(32'h4080, 144, 0);
VR.ram_fill32(32'h4140, 144, 0);
VR.ram_fill32(32'h4200, 144, 0);
VR.ram_fill32(32'h42c0, 144, 0);
VR.ram_fill32(32'h4380, 144, 0);
VR.ram_fill32(32'h4440, 144, 0);
VR.ram_fill32(32'h4500, 144, 0);
VR.ram_fill32(32'h45c0, 144, 0);
VR.ram_fill32(32'h4680, 144, 0);
VR.ram_fill32(32'h4740, 144, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x300, 0x1000000, 0, 0, 287, 95); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h300);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h1000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h11f005f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x8400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
wait_for_pipe_a;
/* bbird_line_pat(0x93939393, 0x10); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h93939393);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h10);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0xc00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'hc00);
/* bbird_area_pattern(0x0, 0x80, 0x2080000); */
wait_for_pipe_a;
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h41000300+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'hc01);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h400001);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ff34, 0x0, 0x20, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'hffffffff);
pci_burst_data(32'h10000004, 4'h0, 32'h0);
pci_burst_data(32'h10000008, 4'h0, 32'hffffffff);
pci_burst_data(32'h1000000c, 4'h0, 32'h0);
pci_burst_data(32'h10000010, 4'h0, 32'hffffffff);
pci_burst_data(32'h10000014, 4'h0, 32'h0);
pci_burst_data(32'h10000018, 4'h0, 32'hffffffff);
pci_burst_data(32'h1000001c, 4'h0, 32'h0);
pci_burst_data(32'h10000020, 4'h0, 32'hffffffff);
pci_burst_data(32'h10000024, 4'h0, 32'h0);
pci_burst_data(32'h10000028, 4'h0, 32'hffffffff);
pci_burst_data(32'h1000002c, 4'h0, 32'h0);
pci_burst_data(32'h10000030, 4'h0, 32'hffffffff);
pci_burst_data(32'h10000034, 4'h0, 32'h0);
pci_burst_data(32'h10000038, 4'h0, 32'hffffffff);
pci_burst_data(32'h1000003c, 4'h0, 32'h0);
pci_burst_data(32'h10000040, 4'h0, 32'hffffffff);
pci_burst_data(32'h10000044, 4'h0, 32'h0);
pci_burst_data(32'h10000048, 4'h0, 32'hffffffff);
pci_burst_data(32'h1000004c, 4'h0, 32'h0);
pci_burst_data(32'h10000050, 4'h0, 32'hffffffff);
pci_burst_data(32'h10000054, 4'h0, 32'h0);
pci_burst_data(32'h10000058, 4'h0, 32'hffffffff);
pci_burst_data(32'h1000005c, 4'h0, 32'h0);
pci_burst_data(32'h10000060, 4'h0, 32'hffffffff);
pci_burst_data(32'h10000064, 4'h0, 32'h0);
pci_burst_data(32'h10000068, 4'h0, 32'hffffffff);
pci_burst_data(32'h1000006c, 4'h0, 32'h0);
pci_burst_data(32'h10000070, 4'h0, 32'hffffffff);
pci_burst_data(32'h10000074, 4'h0, 32'h0);
pci_burst_data(32'h10000078, 4'h0, 32'hffffffff);
pci_burst_data(32'h1000007c, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h80);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h1000000+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x2480c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h2480c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 128, 0, 0, 288, 96, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h1200060);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h80);
pci_burst_data(rbase_a+XY1,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 6, 52, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h340003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10006);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 9, 53, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h350003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10009);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 12, 54, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h360003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1000c);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 15, 55, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h370003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1000f);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 18, 56, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h380003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10012);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 21, 57, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h390003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10015);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 24, 58, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h3a0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10018);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 27, 59, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h3b0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1001b);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 30, 60, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h3c0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1001e);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 33, 61, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h3d0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10021);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 36, 62, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h3e0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10024);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 39, 63, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h3f0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10027);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 42, 64, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h400003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1002a);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 45, 65, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h410003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1002d);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 48, 66, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h420003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10030);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 51, 67, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h430003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10033);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 54, 68, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h440003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10036);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 57, 69, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h450003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10039);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 60, 70, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h460003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1003c);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 63, 71, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h470003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1003f);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 66, 72, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h480003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10042);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 69, 73, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h490003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10045);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 72, 74, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h4a0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10048);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 75, 75, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h4b0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1004b);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_memxfer_setup(0, 0x4200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h4200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h120, 32'h60, "junk", 32'h300, 2'h1);
