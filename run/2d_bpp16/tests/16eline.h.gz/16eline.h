///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2014 Francis Bruno, All Rights Reserved
// 
//  This program is free software; you can redistribute it and/or modify it 
//  under the terms of the GNU General Public License as published by the Free 
//  Software Foundation; either version 3 of the License, or (at your option) 
//  any later version.
//
//  This program is distributed in the hope that it will be useful, but 
//  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
//  or FITNESS FOR A PARTICULAR PURPOSE. 
//  See the GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License along with
//  this program; if not, see <http://www.gnu.org/licenses>.
//
//  This code is available under licenses for commercial use. Please contact
//  Francis Bruno for more information.
//
//  http://www.gplgpu.com
//  http://www.asicsolutions.com
//
//  Title       :  
//  File        :  
//  Author      :  Frank Bruno
//  Created     :  14-May-2011
//  RCS File    :  $Source:$
//  Status      :  $Id:$
//
///////////////////////////////////////////////////////////////////////////////
//
//  Description : 
//  2D test suite - 16Bpp
//
//////////////////////////////////////////////////////////////////////////////
//
//  Modules Instantiated:
//
///////////////////////////////////////////////////////////////////////////////
//
//  Modification History:
//
//  $Log:$
//
//
///////////////////////////////////////////////////////////////////////////////
// 
// # Eline tests
$display("# Eline tests");
// memxfer_setup 0 0 0xFFFFFFFF
pci_burst_data(rbase_w + 32'h00000000, 4'h0, 32'h00000000);
pci_burst_data(rbase_w + 32'h00000024, 4'h0, 32'hffffffff);
// 
// # Set bitmap to 16 bits/pixel, 64x32, starting at address 0.
$display("# Set bitmap to 16 bits/pixel, 64x32, starting at address 0.");
// bitmap 16 64 32 0
pci_burst_data(rbase_a + 32'h00000020, 4'h0, 32'h01000000);
pci_burst_data(rbase_a + 32'h00000028, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000002c, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000040, 4'h0, 32'h00000080);
pci_burst_data(rbase_a + 32'h00000044, 4'h0, 32'h00000080);
pci_burst_data(rbase_a + 32'h00000080, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000084, 4'h0, 32'h00400020);
// clear_mem
VR.ram_fill32(32'h00000000, 32, 0);
VR.ram_fill32(32'h00000020, 32, 0);
VR.ram_fill32(32'h00000040, 32, 0);
VR.ram_fill32(32'h00000060, 32, 0);
VR.ram_fill32(32'h00000080, 32, 0);
VR.ram_fill32(32'h000000a0, 32, 0);
VR.ram_fill32(32'h000000c0, 32, 0);
VR.ram_fill32(32'h000000e0, 32, 0);
VR.ram_fill32(32'h00000100, 32, 0);
VR.ram_fill32(32'h00000120, 32, 0);
VR.ram_fill32(32'h00000140, 32, 0);
VR.ram_fill32(32'h00000160, 32, 0);
VR.ram_fill32(32'h00000180, 32, 0);
VR.ram_fill32(32'h000001a0, 32, 0);
VR.ram_fill32(32'h000001c0, 32, 0);
VR.ram_fill32(32'h000001e0, 32, 0);
VR.ram_fill32(32'h00000200, 32, 0);
VR.ram_fill32(32'h00000220, 32, 0);
VR.ram_fill32(32'h00000240, 32, 0);
VR.ram_fill32(32'h00000260, 32, 0);
VR.ram_fill32(32'h00000280, 32, 0);
VR.ram_fill32(32'h000002a0, 32, 0);
VR.ram_fill32(32'h000002c0, 32, 0);
VR.ram_fill32(32'h000002e0, 32, 0);
VR.ram_fill32(32'h00000300, 32, 0);
VR.ram_fill32(32'h00000320, 32, 0);
VR.ram_fill32(32'h00000340, 32, 0);
VR.ram_fill32(32'h00000360, 32, 0);
VR.ram_fill32(32'h00000380, 32, 0);
VR.ram_fill32(32'h000003a0, 32, 0);
VR.ram_fill32(32'h000003c0, 32, 0);
VR.ram_fill32(32'h000003e0, 32, 0);
// 
// cmd 0x00410C03	// Clip in, Solid, Copy, Eline
pci_burst_data(rbase_a + 32'h00000048, 4'h0, 32'h00410c03);
// 
// foreground 0xFFFFFFFF
pci_burst_data(rbase_a + 32'h00000068, 4'h0, 32'hffffffff);
// 
// # 1st line - 3,3 to 43,8
$display("# 1st line - 3,3 to 43,8");
// # major_delta = 40, minor_delta = 5
$display("# major_delta = 40, minor_delta = 5");
// xy2 0xFFD80000
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'hffd80000);
// xy3 0x0050000A
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h0050000a);
// xy0 0x00030003
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00030003);
// xy1 0x002B0008
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h002b0008);
// 
// # 2nd line - 2,2 to 7,32
$display("# 2nd line - 2,2 to 7,32");
// xy2 0xFFD20000
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'hffd20000);
// xy3 0x003C000A
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h003c000a);
// cmd_style 2	// Transparent
pci_burst_data(rbase_a + 32'h00000058, 4'h0, 32'h00000002);
// cmd_pattern 8	// pattern reset
pci_burst_data(rbase_a + 32'h0000005c, 4'h0, 32'h00000008);
// foreground 0x55555555
pci_burst_data(rbase_a + 32'h00000068, 4'h0, 32'h55555555);
// line_pattern 0x55555555
pci_burst_data(rbase_a + 32'h00000078, 4'h0, 32'h55555555);
// pattern_ctrl 0x00000002
pci_burst_data(rbase_a + 32'h0000007c, 4'h0, 32'h00000002);
// 
// xy0 0x00020002
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00020002);
// xy1 0x00070020
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00070020);
// 
// # 3rd line -  5,5 to 21,21
$display("# 3rd line -  5,5 to 21,21");
// xy2 0xFFE00000
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'hffe00000);
// xy3 0x00200020
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00200020);
// cmd_style 0	// two-color
pci_burst_data(rbase_a + 32'h00000058, 4'h0, 32'h00000000);
// foreground 0x11111111
pci_burst_data(rbase_a + 32'h00000068, 4'h0, 32'h11111111);
// background 0x33333333
pci_burst_data(rbase_a + 32'h0000006c, 4'h0, 32'h33333333);
// 
// xy0 0x00050005
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00050005);
// xy1 0x00150015
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00150015);
// 
// 
// 
// 
// 
// save_bmp junk 0 0 64 32
wait_for_pipe_a;
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h40, 32'h20, "junk", 32'h80, 32'h1);
// 
// end
