///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2014 Francis Bruno, All Rights Reserved
// 
//  This program is free software; you can redistribute it and/or modify it 
//  under the terms of the GNU General Public License as published by the Free 
//  Software Foundation; either version 3 of the License, or (at your option) 
//  any later version.
//
//  This program is distributed in the hope that it will be useful, but 
//  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
//  or FITNESS FOR A PARTICULAR PURPOSE. 
//  See the GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License along with
//  this program; if not, see <http://www.gnu.org/licenses>.
//
//  This code is available under licenses for commercial use. Please contact
//  Francis Bruno for more information.
//
//  http://www.gplgpu.com
//  http://www.asicsolutions.com
//
//  Title       :  
//  File        :  
//  Author      :  Frank Bruno
//  Created     :  14-May-2011
//  RCS File    :  $Source:$
//  Status      :  $Id:$
//
///////////////////////////////////////////////////////////////////////////////
//
//  Description : 
//  2D test suite - 16Bpp
//
//////////////////////////////////////////////////////////////////////////////
//
//  Modules Instantiated:
//
///////////////////////////////////////////////////////////////////////////////
//
//  Modification History:
//
//  $Log:$
//
//
///////////////////////////////////////////////////////////////////////////////
/* VERILOG logging on. */
/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'h500);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0x500, 0x1000000); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'h500);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h1000000+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x500, 0x1000000, 0, 0, 95, 31); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h500);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h1000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h5f001f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 48, 0);
VR.ram_fill32(32'h140, 48, 0);
VR.ram_fill32(32'h280, 48, 0);
VR.ram_fill32(32'h3c0, 48, 0);
VR.ram_fill32(32'h500, 48, 0);
VR.ram_fill32(32'h640, 48, 0);
VR.ram_fill32(32'h780, 48, 0);
VR.ram_fill32(32'h8c0, 48, 0);
VR.ram_fill32(32'ha00, 48, 0);
VR.ram_fill32(32'hb40, 48, 0);
VR.ram_fill32(32'hc80, 48, 0);
VR.ram_fill32(32'hdc0, 48, 0);
VR.ram_fill32(32'hf00, 48, 0);
VR.ram_fill32(32'h1040, 48, 0);
VR.ram_fill32(32'h1180, 48, 0);
VR.ram_fill32(32'h12c0, 48, 0);
VR.ram_fill32(32'h1400, 48, 0);
VR.ram_fill32(32'h1540, 48, 0);
VR.ram_fill32(32'h1680, 48, 0);
VR.ram_fill32(32'h17c0, 48, 0);
VR.ram_fill32(32'h1900, 48, 0);
VR.ram_fill32(32'h1a40, 48, 0);
VR.ram_fill32(32'h1b80, 48, 0);
VR.ram_fill32(32'h1cc0, 48, 0);
VR.ram_fill32(32'h1e00, 48, 0);
VR.ram_fill32(32'h1f40, 48, 0);
VR.ram_fill32(32'h2080, 48, 0);
VR.ram_fill32(32'h21c0, 48, 0);
VR.ram_fill32(32'h2300, 48, 0);
VR.ram_fill32(32'h2440, 48, 0);
VR.ram_fill32(32'h2580, 48, 0);
VR.ram_fill32(32'h26c0, 48, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x500, 0x1000000, 0, 0, 95, 31); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h500);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h1000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h5f001f);
/* bbird_memxfer_setup(0, 0x4200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h4200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
/* bbird_memxfer_setup(1, 0x0, 0x0, 0x0, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW1_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_CTRL,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_WKEY,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_KYDAT,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_line_pat(0x16, 0x5); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h16);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h5);
wait_for_pipe_a;
/* bbird_colors(0x1, 0x9, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
pci_burst_data(rbase_a+BACK,4'h0,32'h9);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_rectangle(0x28, 0x8, 0x3b, 0xd); */
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 40, 8, 20, 6, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h140006);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h280008);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_write_pixel(0x0, 0x2, 0x33333333); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h33333333);
pci_burst_data(rbase_a+XY0,4'h0,32'h2);
pci_burst_data(rbase_a+XY1,4'h0,32'h2);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
wait_for_pipe_a;
/* bbird_write_pixel(0x2, 0x3, 0x33333333); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h33333333);
pci_burst_data(rbase_a+XY0,4'h0,32'h20003);
pci_burst_data(rbase_a+XY1,4'h0,32'h20003);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
wait_for_pipe_a;
/* bbird_colors(0x13, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h13);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
pci_burst_data(32'h40000004, 4'h0, 32'h01020300);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x420c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h420c00);
/* bbird_font_write("Hello world!"); { 0x5, 0x2 } */
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h1000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'h4e0c01);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+32'hF8,4'h0,32'h0);
/* Writing character 'H' */
/* bbird_font_cache(0, 32, 'H', 0x1); */
/* caching character 'H' */
pci_burst_data(32'ha000a000, 4'h0, 32'he3e30000);
pci_burst_data(32'ha000a004, 4'h0, 32'he3ffe3e3);
pci_burst_data(32'ha000a008, 4'h0, 32'he3e3e3e3);
pci_burst_data(32'ha000a00c, 4'h0, 32'h0);
pci_burst_data(32'ha0000000, 4'h0, 32'h20);
pci_burst_data(32'ha0000004, 4'h0, 32'h7000f);
pci_burst_data(32'ha0000008, 4'h0, 32'h2);
pci_burst_data(32'ha000000c, 4'h0, 32'h50002);
pci_burst_data(rbase_a+32'hFC,4'h0,32'h20000010);
/* Writing character 'e' */
/* bbird_font_cache(8, 32, 'e', 0x1); */
/* caching character 'e' */
pci_burst_data(32'ha000a010, 4'h0, 32'hc0800000);
pci_burst_data(32'ha000a014, 4'h0, 32'hf3f3dec0);
pci_burst_data(32'ha000a018, 4'h0, 32'hfec3c3ff);
pci_burst_data(32'ha000a01c, 4'h0, 32'h0);
pci_burst_data(32'ha0000010, 4'h0, 32'h80020);
pci_burst_data(32'ha0000014, 4'h0, 32'h6000f);
pci_burst_data(32'ha0000018, 4'h0, 32'h2);
pci_burst_data(32'ha000001c, 4'h0, 32'hd0002);
pci_burst_data(rbase_a+32'hFC,4'h0,32'h20000020);
/* Writing character 'l' */
/* bbird_font_cache(16, 32, 'l', 0x1); */
/* caching character 'l' */
pci_burst_data(32'ha000a020, 4'h0, 32'h3030000);
pci_burst_data(32'ha000a024, 4'h0, 32'h6f6fbf03);
pci_burst_data(32'ha000a028, 4'h0, 32'h6f6f6f6f);
pci_burst_data(32'ha000a02c, 4'h0, 32'h0);
pci_burst_data(32'ha0000020, 4'h0, 32'h100020);
pci_burst_data(32'ha0000024, 4'h0, 32'h2000f);
pci_burst_data(32'ha0000028, 4'h0, 32'h2);
pci_burst_data(32'ha000002c, 4'h0, 32'h140002);
pci_burst_data(rbase_a+32'hFC,4'h0,32'h20000030);
/* Writing character 'l' */
pci_burst_data(32'ha0000030, 4'h0, 32'h100020);
pci_burst_data(32'ha0000034, 4'h0, 32'h2000f);
pci_burst_data(32'ha0000038, 4'h0, 32'h2);
pci_burst_data(32'ha000003c, 4'h0, 32'h170002);
pci_burst_data(rbase_a+32'hFC,4'h0,32'h20000040);
/* Writing character 'o' */
/* bbird_font_cache(24, 32, 'o', 0x1); */
/* caching character 'o' */
pci_burst_data(32'ha000a030, 4'h0, 32'h0);
pci_burst_data(32'ha000a034, 4'h0, 32'hf3f3de00);
pci_burst_data(32'ha000a038, 4'h0, 32'hdef3f3f3);
pci_burst_data(32'ha000a03c, 4'h0, 32'hc0c0c0);
pci_burst_data(32'ha0000040, 4'h0, 32'h180020);
pci_burst_data(32'ha0000044, 4'h0, 32'h6000f);
pci_burst_data(32'ha0000048, 4'h0, 32'h2);
pci_burst_data(32'ha000004c, 4'h0, 32'h1a0002);
pci_burst_data(rbase_a+32'hFC,4'h0,32'h20000050);
/* Writing character ' ' */
/* bbird_font_cache(32, 32, ' ', 0x1); */
/* caching character ' ' */
/* Writing character 'w' */
/* bbird_font_cache(32, 32, 'w', 0x1); */
/* caching character 'w' */
pci_burst_data(32'ha000a040, 4'h0, 32'h0);
pci_burst_data(32'ha000a044, 4'h0, 32'h63e3e300);
pci_burst_data(32'ha000a048, 4'h0, 32'hf7ff6b63);
pci_burst_data(32'ha000a04c, 4'h0, 32'h0);
pci_burst_data(32'ha0000050, 4'h0, 32'h200020);
pci_burst_data(32'ha0000054, 4'h0, 32'h7000f);
pci_burst_data(32'ha0000058, 4'h0, 32'h2);
pci_burst_data(32'ha000005c, 4'h0, 32'h250002);
pci_burst_data(rbase_a+32'hFC,4'h0,32'h20000060);
/* Writing character 'o' */
pci_burst_data(32'ha0000060, 4'h0, 32'h180020);
pci_burst_data(32'ha0000064, 4'h0, 32'h6000f);
pci_burst_data(32'ha0000068, 4'h0, 32'h2);
pci_burst_data(32'ha000006c, 4'h0, 32'h2d0002);
pci_burst_data(rbase_a+32'hFC,4'h0,32'h20000070);
/* Writing character 'r' */
/* bbird_font_cache(40, 32, 'r', 0x1); */
/* caching character 'r' */
pci_burst_data(32'ha000a050, 4'h0, 32'h0);
pci_burst_data(32'ha000a054, 4'h0, 32'he37bcf00);
pci_burst_data(32'ha000a058, 4'h0, 32'he30383c3);
pci_burst_data(32'ha000a05c, 4'h0, 32'h0);
pci_burst_data(32'ha0000070, 4'h0, 32'h280020);
pci_burst_data(32'ha0000074, 4'h0, 32'h5000f);
pci_burst_data(32'ha0000078, 4'h0, 32'h2);
pci_burst_data(32'ha000007c, 4'h0, 32'h340002);
pci_burst_data(rbase_a+32'hFC,4'h0,32'h20000080);
/* Writing character 'l' */
pci_burst_data(32'ha0000080, 4'h0, 32'h100020);
pci_burst_data(32'ha0000084, 4'h0, 32'h2000f);
pci_burst_data(32'ha0000088, 4'h0, 32'h2);
pci_burst_data(32'ha000008c, 4'h0, 32'h3a0002);
pci_burst_data(rbase_a+32'hFC,4'h0,32'h20000090);
/* Writing character 'd' */
/* bbird_font_cache(48, 32, 'd', 0x1); */
/* caching character 'd' */
pci_burst_data(32'ha000a060, 4'h0, 32'h30300000);
pci_burst_data(32'ha000a064, 4'h0, 32'hf3f3be30);
pci_burst_data(32'ha000a068, 4'h0, 32'hbef3f3f3);
pci_burst_data(32'ha000a06c, 4'h0, 32'h0);
pci_burst_data(32'ha0000090, 4'h0, 32'h300020);
pci_burst_data(32'ha0000094, 4'h0, 32'h6000f);
pci_burst_data(32'ha0000098, 4'h0, 32'h2);
pci_burst_data(32'ha000009c, 4'h0, 32'h3d0002);
pci_burst_data(rbase_a+32'hFC,4'h0,32'h200000a0);
/* Writing character '!' */
/* bbird_font_cache(56, 32, '!', 0x1); */
/* caching character '!' */
pci_burst_data(32'ha000a070, 4'h0, 32'h4b6f0300);
pci_burst_data(32'ha000a074, 4'h0, 32'h38303a7);
pci_burst_data(32'ha000a078, 4'h0, 32'h3030000);
pci_burst_data(32'ha000a07c, 4'h0, 32'h0);
pci_burst_data(32'ha00000a0, 4'h0, 32'h380020);
pci_burst_data(32'ha00000a4, 4'h0, 32'h2000f);
pci_burst_data(32'ha00000a8, 4'h0, 32'h2);
pci_burst_data(32'ha00000ac, 4'h0, 32'h450002);
pci_burst_data(rbase_a+32'hFC,4'h0,32'h200000b0);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x420c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h420c00);
rd(MEM_RD, 32'h40000000, 1);
wait_for_pipe_a;
/* bbird_write_pixel(0x2, 0x5, 0xcc); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'hcc);
pci_burst_data(rbase_a+XY0,4'h0,32'h20005);
pci_burst_data(rbase_a+XY1,4'h0,32'h20005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h420c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h60, 32'h20, "junk", 32'h500, 2'h1);
