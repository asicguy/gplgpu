///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2014 Francis Bruno, All Rights Reserved
// 
//  This program is free software; you can redistribute it and/or modify it 
//  under the terms of the GNU General Public License as published by the Free 
//  Software Foundation; either version 3 of the License, or (at your option) 
//  any later version.
//
//  This program is distributed in the hope that it will be useful, but 
//  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
//  or FITNESS FOR A PARTICULAR PURPOSE. 
//  See the GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License along with
//  this program; if not, see <http://www.gnu.org/licenses>.
//
//  This code is available under licenses for commercial use. Please contact
//  Francis Bruno for more information.
//
//  http://www.gplgpu.com
//  http://www.asicsolutions.com
//
//  Title       :  
//  File        :  
//  Author      :  Frank Bruno
//  Created     :  14-May-2011
//  RCS File    :  $Source:$
//  Status      :  $Id:$
//
///////////////////////////////////////////////////////////////////////////////
//
//  Description : 
//  2D test suite - 16Bpp
//
//////////////////////////////////////////////////////////////////////////////
//
//  Modules Instantiated:
//
///////////////////////////////////////////////////////////////////////////////
//
//  Modification History:
//
//  $Log:$
//
//
///////////////////////////////////////////////////////////////////////////////
// 
// # Reverse direction bitblit test 2 - width is exactly 128 bytes
$display("# Reverse direction bitblit test 2 - width is exactly 128 bytes");
// memxfer_setup 0 0 0xFFFFFFFF
pci_burst_data(rbase_w + 32'h00000000, 4'h0, 32'h00000000);
pci_burst_data(rbase_w + 32'h00000024, 4'h0, 32'hffffffff);
// 
// # Set bitmap to 16 bits/pixel, 80x16, starting at address 0.
$display("# Set bitmap to 16 bits/pixel, 80x16, starting at address 0.");
// bitmap 16 80 16 0
pci_burst_data(rbase_a + 32'h00000048, 4'h0, 32'h0);
pci_burst_data(rbase_a + 32'h00000020, 4'h0, 32'h01000000);
pci_burst_data(rbase_a + 32'h00000028, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000002c, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000040, 4'h0, 32'h000000a0);
pci_burst_data(rbase_a + 32'h00000044, 4'h0, 32'h000000a0);
pci_burst_data(rbase_a + 32'h00000080, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000084, 4'h0, 32'h00500010);
// clear_mem
VR.ram_fill32(32'h00000000, 40, 0);
VR.ram_fill32(32'h00000028, 40, 0);
VR.ram_fill32(32'h00000050, 40, 0);
VR.ram_fill32(32'h00000078, 40, 0);
VR.ram_fill32(32'h000000a0, 40, 0);
VR.ram_fill32(32'h000000c8, 40, 0);
VR.ram_fill32(32'h000000f0, 40, 0);
VR.ram_fill32(32'h00000118, 40, 0);
VR.ram_fill32(32'h00000140, 40, 0);
VR.ram_fill32(32'h00000168, 40, 0);
VR.ram_fill32(32'h00000190, 40, 0);
VR.ram_fill32(32'h000001b8, 40, 0);
VR.ram_fill32(32'h000001e0, 40, 0);
VR.ram_fill32(32'h00000208, 40, 0);
VR.ram_fill32(32'h00000230, 40, 0);
VR.ram_fill32(32'h00000258, 40, 0);
// 
// cmd_raster_op 0xC	// Copy
pci_burst_data(rbase_a + 32'h00000054, 4'h0, 32'h0000000c);
// cmd_style 0 
pci_burst_data(rbase_a + 32'h00000058, 4'h0, 32'h00000000);
// cmd_clip 2	// Clip in
pci_burst_data(rbase_a + 32'h00000060, 4'h0, 32'h00000002);
// 
// write_mem 0x40000000 40	// 
//  0x1b0014  0x13001b  0x120014  0x17001e  0x1f0016  0x1e0019  0x1a0014  0x12001f 
pci_burst_data(0 + 32'h40000000, 4'h0, 32'h001b0014);
pci_burst_data(0 + 32'h40000004, 4'h0, 32'h0013001b);
pci_burst_data(0 + 32'h40000008, 4'h0, 32'h00120014);
pci_burst_data(0 + 32'h4000000c, 4'h0, 32'h0017001e);
pci_burst_data(0 + 32'h40000010, 4'h0, 32'h001f0016);
pci_burst_data(0 + 32'h40000014, 4'h0, 32'h001e0019);
pci_burst_data(0 + 32'h40000018, 4'h0, 32'h001a0014);
pci_burst_data(0 + 32'h4000001c, 4'h0, 32'h0012001f);
//  0x15001d  0x160011  0x1c0015  0x190010  0x1d001d  0x160018  0x170019  0x1d001b 
pci_burst_data(0 + 32'h40000020, 4'h0, 32'h0015001d);
pci_burst_data(0 + 32'h40000024, 4'h0, 32'h00160011);
pci_burst_data(0 + 32'h40000028, 4'h0, 32'h001c0015);
pci_burst_data(0 + 32'h4000002c, 4'h0, 32'h00190010);
pci_burst_data(0 + 32'h40000030, 4'h0, 32'h001d001d);
pci_burst_data(0 + 32'h40000034, 4'h0, 32'h00160018);
pci_burst_data(0 + 32'h40000038, 4'h0, 32'h00170019);
pci_burst_data(0 + 32'h4000003c, 4'h0, 32'h001d001b);
//  0x160013  0x170010  0x1f0018  0x1f001f  0x18001e  0x12001d  0x1c0013  0x100014 
pci_burst_data(0 + 32'h40000040, 4'h0, 32'h00160013);
pci_burst_data(0 + 32'h40000044, 4'h0, 32'h00170010);
pci_burst_data(0 + 32'h40000048, 4'h0, 32'h001f0018);
pci_burst_data(0 + 32'h4000004c, 4'h0, 32'h001f001f);
pci_burst_data(0 + 32'h40000050, 4'h0, 32'h0018001e);
pci_burst_data(0 + 32'h40000054, 4'h0, 32'h0012001d);
pci_burst_data(0 + 32'h40000058, 4'h0, 32'h001c0013);
pci_burst_data(0 + 32'h4000005c, 4'h0, 32'h00100014);
//  0x160012  0x170016  0x160012  0x1f0010  0x180014  0x1d0015  0x100010  0x13001b 
pci_burst_data(0 + 32'h40000060, 4'h0, 32'h00160012);
pci_burst_data(0 + 32'h40000064, 4'h0, 32'h00170016);
pci_burst_data(0 + 32'h40000068, 4'h0, 32'h00160012);
pci_burst_data(0 + 32'h4000006c, 4'h0, 32'h001f0010);
pci_burst_data(0 + 32'h40000070, 4'h0, 32'h00180014);
pci_burst_data(0 + 32'h40000074, 4'h0, 32'h001d0015);
pci_burst_data(0 + 32'h40000078, 4'h0, 32'h00100010);
pci_burst_data(0 + 32'h4000007c, 4'h0, 32'h0013001b);
//  0x1b0017  0x1f001a  0x19001a  0x19001e  0x1c0012  0x15001b  0x100018  0x1a0015 
pci_burst_data(0 + 32'h40000080, 4'h0, 32'h001b0017);
pci_burst_data(0 + 32'h40000084, 4'h0, 32'h001f001a);
pci_burst_data(0 + 32'h40000088, 4'h0, 32'h0019001a);
pci_burst_data(0 + 32'h4000008c, 4'h0, 32'h0019001e);
pci_burst_data(0 + 32'h40000090, 4'h0, 32'h001c0012);
pci_burst_data(0 + 32'h40000094, 4'h0, 32'h0015001b);
pci_burst_data(0 + 32'h40000098, 4'h0, 32'h00100018);
pci_burst_data(0 + 32'h4000009c, 4'h0, 32'h001a0015);
// 
// bitblit   0  0  0  1  80 1
pci_burst_data(rbase_a + 32'h00000050, 4'h0, 32'h00000001);
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00500001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00000001);
// bitblit   0  0  0  2  80 2
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00500002);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00000002);
// bitblit   0  0  0  4  80 4
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00500004);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00000004);
// bitblit   0  0  0  8  80 8
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00500008);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00000008);
// 
$display("#define T2R_DIR_RL_TB         0x02            /* right-left, top-bottom */");
// #bitblit srcx srcy dstx dsty width height dir zoom
$display("#bitblit srcx srcy dstx dsty width height dir zoom");
// bitblit 64 1 65 1 64 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00400001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00400001);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00410001);
// bitblit 64 2 66 2 64 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00400001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00400002);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00420002);
// bitblit 64 3 67 3 64 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00400001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00400003);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00430003);
// bitblit 64 4 68 4 64 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00400001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00400004);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00440004);
// bitblit 64 5 69 5 64 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00400001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00400005);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00450005);
// bitblit 64 6 70 6 64 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00400001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00400006);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00460006);
// bitblit 64 7 71 7 64 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00400001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00400007);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00470007);
// bitblit 64 8 72 8 64 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00400001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00400008);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00480008);
// bitblit 64 9 73 9 64 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00400001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00400009);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00490009);
// bitblit 64 10 74 10 64 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00400001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0040000a);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h004a000a);
// bitblit 64 11 75 11 64 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00400001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0040000b);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h004b000b);
// bitblit 64 12 76 12 64 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00400001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0040000c);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h004c000c);
// bitblit 64 13 77 13 64 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00400001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0040000d);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h004d000d);
// bitblit 64 14 78 14 64 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00400001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0040000e);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h004e000e);
// bitblit 64 15 79 15 64 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00400001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0040000f);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h004f000f);
// 
// 
// 
// 
// save_bmp junk 0 0 80 16
wait_for_pipe_a;
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h50, 32'h10, "junk", 32'ha0, 32'h1);
// 
// end
