/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'h180);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0x180, 0x0); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'h180);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x180, 0x0, 0, 0, 287, 95); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h180);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h11f005f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 72, 0);
VR.ram_fill32(32'h60, 72, 0);
VR.ram_fill32(32'hc0, 72, 0);
VR.ram_fill32(32'h120, 72, 0);
VR.ram_fill32(32'h180, 72, 0);
VR.ram_fill32(32'h1e0, 72, 0);
VR.ram_fill32(32'h240, 72, 0);
VR.ram_fill32(32'h2a0, 72, 0);
VR.ram_fill32(32'h300, 72, 0);
VR.ram_fill32(32'h360, 72, 0);
VR.ram_fill32(32'h3c0, 72, 0);
VR.ram_fill32(32'h420, 72, 0);
VR.ram_fill32(32'h480, 72, 0);
VR.ram_fill32(32'h4e0, 72, 0);
VR.ram_fill32(32'h540, 72, 0);
VR.ram_fill32(32'h5a0, 72, 0);
VR.ram_fill32(32'h600, 72, 0);
VR.ram_fill32(32'h660, 72, 0);
VR.ram_fill32(32'h6c0, 72, 0);
VR.ram_fill32(32'h720, 72, 0);
VR.ram_fill32(32'h780, 72, 0);
VR.ram_fill32(32'h7e0, 72, 0);
VR.ram_fill32(32'h840, 72, 0);
VR.ram_fill32(32'h8a0, 72, 0);
VR.ram_fill32(32'h900, 72, 0);
VR.ram_fill32(32'h960, 72, 0);
VR.ram_fill32(32'h9c0, 72, 0);
VR.ram_fill32(32'ha20, 72, 0);
VR.ram_fill32(32'ha80, 72, 0);
VR.ram_fill32(32'hae0, 72, 0);
VR.ram_fill32(32'hb40, 72, 0);
VR.ram_fill32(32'hba0, 72, 0);
VR.ram_fill32(32'hc00, 72, 0);
VR.ram_fill32(32'hc60, 72, 0);
VR.ram_fill32(32'hcc0, 72, 0);
VR.ram_fill32(32'hd20, 72, 0);
VR.ram_fill32(32'hd80, 72, 0);
VR.ram_fill32(32'hde0, 72, 0);
VR.ram_fill32(32'he40, 72, 0);
VR.ram_fill32(32'hea0, 72, 0);
VR.ram_fill32(32'hf00, 72, 0);
VR.ram_fill32(32'hf60, 72, 0);
VR.ram_fill32(32'hfc0, 72, 0);
VR.ram_fill32(32'h1020, 72, 0);
VR.ram_fill32(32'h1080, 72, 0);
VR.ram_fill32(32'h10e0, 72, 0);
VR.ram_fill32(32'h1140, 72, 0);
VR.ram_fill32(32'h11a0, 72, 0);
VR.ram_fill32(32'h1200, 72, 0);
VR.ram_fill32(32'h1260, 72, 0);
VR.ram_fill32(32'h12c0, 72, 0);
VR.ram_fill32(32'h1320, 72, 0);
VR.ram_fill32(32'h1380, 72, 0);
VR.ram_fill32(32'h13e0, 72, 0);
VR.ram_fill32(32'h1440, 72, 0);
VR.ram_fill32(32'h14a0, 72, 0);
VR.ram_fill32(32'h1500, 72, 0);
VR.ram_fill32(32'h1560, 72, 0);
VR.ram_fill32(32'h15c0, 72, 0);
VR.ram_fill32(32'h1620, 72, 0);
VR.ram_fill32(32'h1680, 72, 0);
VR.ram_fill32(32'h16e0, 72, 0);
VR.ram_fill32(32'h1740, 72, 0);
VR.ram_fill32(32'h17a0, 72, 0);
VR.ram_fill32(32'h1800, 72, 0);
VR.ram_fill32(32'h1860, 72, 0);
VR.ram_fill32(32'h18c0, 72, 0);
VR.ram_fill32(32'h1920, 72, 0);
VR.ram_fill32(32'h1980, 72, 0);
VR.ram_fill32(32'h19e0, 72, 0);
VR.ram_fill32(32'h1a40, 72, 0);
VR.ram_fill32(32'h1aa0, 72, 0);
VR.ram_fill32(32'h1b00, 72, 0);
VR.ram_fill32(32'h1b60, 72, 0);
VR.ram_fill32(32'h1bc0, 72, 0);
VR.ram_fill32(32'h1c20, 72, 0);
VR.ram_fill32(32'h1c80, 72, 0);
VR.ram_fill32(32'h1ce0, 72, 0);
VR.ram_fill32(32'h1d40, 72, 0);
VR.ram_fill32(32'h1da0, 72, 0);
VR.ram_fill32(32'h1e00, 72, 0);
VR.ram_fill32(32'h1e60, 72, 0);
VR.ram_fill32(32'h1ec0, 72, 0);
VR.ram_fill32(32'h1f20, 72, 0);
VR.ram_fill32(32'h1f80, 72, 0);
VR.ram_fill32(32'h1fe0, 72, 0);
VR.ram_fill32(32'h2040, 72, 0);
VR.ram_fill32(32'h20a0, 72, 0);
VR.ram_fill32(32'h2100, 72, 0);
VR.ram_fill32(32'h2160, 72, 0);
VR.ram_fill32(32'h21c0, 72, 0);
VR.ram_fill32(32'h2220, 72, 0);
VR.ram_fill32(32'h2280, 72, 0);
VR.ram_fill32(32'h22e0, 72, 0);
VR.ram_fill32(32'h2340, 72, 0);
VR.ram_fill32(32'h23a0, 72, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x180, 0x0, 0, 0, 287, 95); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h180);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h11f005f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x8400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
wait_for_pipe_a;
/* bbird_line_pat(0x93939393, 0x10); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h93939393);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h10);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0xc00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'hc00);
/* bbird_area_pattern(0x0, 0x80, 0x1000000); */
wait_for_pipe_a;
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h40000300+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'hc01);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h80001);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800feec, 0x8, 0x2, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3);
pci_burst_data(32'h10000004, 4'h0, 32'h30000);
pci_burst_data(rbase_a+XY1,4'h0,32'h80);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800fef4, 0x8, 0x2, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h300);
pci_burst_data(32'h10000004, 4'h0, 32'h300);
pci_burst_data(rbase_a+XY1,4'h0,32'h81);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800fefc, 0x8, 0x2, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h30000);
pci_burst_data(32'h10000004, 4'h0, 32'h3);
pci_burst_data(rbase_a+XY1,4'h0,32'h82);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ff04, 0x8, 0x2, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3000000);
pci_burst_data(32'h10000004, 4'h0, 32'h2000000);
pci_burst_data(rbase_a+XY1,4'h0,32'h83);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ff0c, 0x8, 0x2, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h30000);
pci_burst_data(32'h10000004, 4'h0, 32'h3);
pci_burst_data(rbase_a+XY1,4'h0,32'h84);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ff14, 0x8, 0x2, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h300);
pci_burst_data(32'h10000004, 4'h0, 32'h300);
pci_burst_data(rbase_a+XY1,4'h0,32'h85);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ff1c, 0x8, 0x2, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3);
pci_burst_data(32'h10000004, 4'h0, 32'h30000);
pci_burst_data(rbase_a+XY1,4'h0,32'h86);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ff24, 0x8, 0x2, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1000000);
pci_burst_data(32'h10000004, 4'h0, 32'h3000000);
pci_burst_data(rbase_a+XY1,4'h0,32'h87);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+XY0,4'h0,32'h80);
pci_burst_data(rbase_a+XY2,4'h0,32'h80008);
pci_burst_data(rbase_a+XY1,4'h0,32'h80080);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x1400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h1400c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 128, 0, 0, 288, 96, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h1200060);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h80);
pci_burst_data(rbase_a+XY1,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 6, 108, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h6c0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10006);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 9, 109, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h6d0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10009);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 12, 110, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h6e0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1000c);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 15, 111, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h6f0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1000f);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 18, 112, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h700003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10012);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 21, 113, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h710003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10015);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 24, 114, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h720003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10018);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 27, 115, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h730003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1001b);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 30, 116, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h740003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1001e);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 33, 117, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h750003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10021);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 36, 118, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h760003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10024);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 39, 119, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h770003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10027);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 42, 120, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h780003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1002a);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 45, 121, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h790003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1002d);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 48, 122, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h7a0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10030);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 51, 123, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h7b0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10033);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 54, 124, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h7c0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10036);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 57, 125, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h7d0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10039);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 60, 126, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h7e0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1003c);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 63, 127, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h7f0003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1003f);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 66, 128, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h800003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10042);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 69, 129, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h810003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10045);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 72, 130, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h820003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10048);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 1, 75, 131, 3, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h830003);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h1004b);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_memxfer_setup(0, 0x200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h120, 32'h60, "junk", 32'h180, 2'h0);
