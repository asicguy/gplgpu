/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'h280);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0x280, 0x0); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'h280);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x280, 0x0, 0, 0, 63, 15); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h280);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h3f000f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 16, 0);
VR.ram_fill32(32'ha0, 16, 0);
VR.ram_fill32(32'h140, 16, 0);
VR.ram_fill32(32'h1e0, 16, 0);
VR.ram_fill32(32'h280, 16, 0);
VR.ram_fill32(32'h320, 16, 0);
VR.ram_fill32(32'h3c0, 16, 0);
VR.ram_fill32(32'h460, 16, 0);
VR.ram_fill32(32'h500, 16, 0);
VR.ram_fill32(32'h5a0, 16, 0);
VR.ram_fill32(32'h640, 16, 0);
VR.ram_fill32(32'h6e0, 16, 0);
VR.ram_fill32(32'h780, 16, 0);
VR.ram_fill32(32'h820, 16, 0);
VR.ram_fill32(32'h8c0, 16, 0);
VR.ram_fill32(32'h960, 16, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x280, 0x0, 0, 0, 63, 15); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h280);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h3f000f);
/* bbird_memxfer_setup(0, 0x200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x8400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
wait_for_pipe_a;
/* bbird_line_pat(0x16, 0x5); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h16);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h5);
wait_for_pipe_a;
/* bbird_colors(0x1, 0x9, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
pci_burst_data(rbase_a+BACK,4'h0,32'h9);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_rectangle(0x28, 0x8, 0x3b, 0xd); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 40, 8, 20, 6, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h140006);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h280008);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
wait_for_pipe_a;
/* bbird_write_pixel(0x0, 0x2, 0x33333333); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h33333333);
pci_burst_data(rbase_a+XY0,4'h0,32'h2);
pci_burst_data(rbase_a+XY1,4'h0,32'h2);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
wait_for_pipe_a;
/* bbird_write_pixel(0x2, 0x3, 0x33333333); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h33333333);
pci_burst_data(rbase_a+XY0,4'h0,32'h20003);
pci_burst_data(rbase_a+XY1,4'h0,32'h20003);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
pci_burst_data(32'h40000004, 4'h0, 32'h01020300);
wait_for_pipe_a;
/* bbird_write_pixel(0x8, 0x7, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h80007);
pci_burst_data(rbase_a+XY1,4'h0,32'h80007);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x9, 0x8, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h90008);
pci_burst_data(rbase_a+XY1,4'h0,32'h90008);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0xa, 0x9, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'ha0009);
pci_burst_data(rbase_a+XY1,4'h0,32'ha0009);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0xb, 0x5, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'hb0005);
pci_burst_data(rbase_a+XY1,4'h0,32'hb0005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x5, 0x6, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h50006);
pci_burst_data(rbase_a+XY1,4'h0,32'h50006);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x6, 0x7, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h60007);
pci_burst_data(rbase_a+XY1,4'h0,32'h60007);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x7, 0x8, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h70008);
pci_burst_data(rbase_a+XY1,4'h0,32'h70008);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x8, 0x9, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h80009);
pci_burst_data(rbase_a+XY1,4'h0,32'h80009);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x9, 0x5, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h90005);
pci_burst_data(rbase_a+XY1,4'h0,32'h90005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0xa, 0x6, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'ha0006);
pci_burst_data(rbase_a+XY1,4'h0,32'ha0006);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0xb, 0x7, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'hb0007);
pci_burst_data(rbase_a+XY1,4'h0,32'hb0007);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x5, 0x8, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h50008);
pci_burst_data(rbase_a+XY1,4'h0,32'h50008);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x6, 0x9, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h60009);
pci_burst_data(rbase_a+XY1,4'h0,32'h60009);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x7, 0x5, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h70005);
pci_burst_data(rbase_a+XY1,4'h0,32'h70005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x8, 0x6, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h80006);
pci_burst_data(rbase_a+XY1,4'h0,32'h80006);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x9, 0x7, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h90007);
pci_burst_data(rbase_a+XY1,4'h0,32'h90007);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_line(39, 0, 58, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h270000);
pci_burst_data(rbase_a+XY1,4'h0,32'h3a0000);
wait_for_pipe_a;
/* bbird_line(39, 1, 59, 1); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h270001);
pci_burst_data(rbase_a+XY1,4'h0,32'h3b0001);
wait_for_pipe_a;
/* bbird_line(39, 2, 60, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h270002);
pci_burst_data(rbase_a+XY1,4'h0,32'h3c0002);
wait_for_pipe_a;
/* bbird_line(39, 3, 61, 3); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h270003);
pci_burst_data(rbase_a+XY1,4'h0,32'h3d0003);
wait_for_pipe_a;
/* bbird_line(39, 4, 62, 4); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h270004);
pci_burst_data(rbase_a+XY1,4'h0,32'h3e0004);
wait_for_pipe_a;
/* bbird_line(39, 5, 63, 5); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h270005);
pci_burst_data(rbase_a+XY1,4'h0,32'h3f0005);
wait_for_pipe_a;
/* bbird_line(39, 6, 64, 6); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h270006);
pci_burst_data(rbase_a+XY1,4'h0,32'h400006);
wait_for_pipe_a;
/* bbird_line(39, 7, 65, 7); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h270007);
pci_burst_data(rbase_a+XY1,4'h0,32'h410007);
wait_for_pipe_a;
/* bbird_line(39, 8, 66, 8); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h270008);
pci_burst_data(rbase_a+XY1,4'h0,32'h420008);
wait_for_pipe_a;
/* bbird_line(39, 9, 67, 9); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h270009);
pci_burst_data(rbase_a+XY1,4'h0,32'h430009);
wait_for_pipe_a;
/* bbird_line(39, 10, 68, 10); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h27000a);
pci_burst_data(rbase_a+XY1,4'h0,32'h44000a);
wait_for_pipe_a;
/* bbird_line(39, 11, 69, 11); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h27000b);
pci_burst_data(rbase_a+XY1,4'h0,32'h45000b);
wait_for_pipe_a;
/* bbird_line(39, 12, 70, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h27000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h46000c);
wait_for_pipe_a;
/* bbird_line(39, 13, 71, 13); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h27000d);
pci_burst_data(rbase_a+XY1,4'h0,32'h47000d);
wait_for_pipe_a;
/* bbird_line(39, 14, 72, 14); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h27000e);
pci_burst_data(rbase_a+XY1,4'h0,32'h48000e);
wait_for_pipe_a;
/* bbird_line(39, 15, 73, 15); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h27000f);
pci_burst_data(rbase_a+XY1,4'h0,32'h49000f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x8400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
rd(MEM_RD, 32'h40000000, 1);
wait_for_pipe_a;
/* bbird_write_pixel(0x2, 0x5, 0xcc); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'hcc);
pci_burst_data(rbase_a+XY0,4'h0,32'h20005);
pci_burst_data(rbase_a+XY1,4'h0,32'h20005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h40, 32'h10, "junk", 32'h280, 2'h0);
