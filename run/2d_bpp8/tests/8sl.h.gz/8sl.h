/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'h180);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0x180, 0x0); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'h180);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x180, 0x0, 0, 0, 63, 15); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h180);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h3f000f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 16, 0);
VR.ram_fill32(32'h60, 16, 0);
VR.ram_fill32(32'hc0, 16, 0);
VR.ram_fill32(32'h120, 16, 0);
VR.ram_fill32(32'h180, 16, 0);
VR.ram_fill32(32'h1e0, 16, 0);
VR.ram_fill32(32'h240, 16, 0);
VR.ram_fill32(32'h2a0, 16, 0);
VR.ram_fill32(32'h300, 16, 0);
VR.ram_fill32(32'h360, 16, 0);
VR.ram_fill32(32'h3c0, 16, 0);
VR.ram_fill32(32'h420, 16, 0);
VR.ram_fill32(32'h480, 16, 0);
VR.ram_fill32(32'h4e0, 16, 0);
VR.ram_fill32(32'h540, 16, 0);
VR.ram_fill32(32'h5a0, 16, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x180, 0x0, 0, 0, 63, 15); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h180);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h3f000f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x8400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
wait_for_pipe_a;
/* bbird_line_pat(0x93939393, 0x10); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h93939393);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h10);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line(1, 2, 1, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h10002);
pci_burst_data(rbase_a+XY1,4'h0,32'h1000c);
wait_for_pipe_a;
/* bbird_line(2, 1, 2, 11); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h20001);
pci_burst_data(rbase_a+XY1,4'h0,32'h2000b);
wait_for_pipe_a;
/* bbird_line(3, 0, 3, 10); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h30000);
pci_burst_data(rbase_a+XY1,4'h0,32'h3000a);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_rectangle(0x38, 0x0, 0x3a, 0x3); */
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 56, 0, 3, 4, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h30004);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h380000);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0x11, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h11);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_rectangle(0x38, 0x4, 0x3a, 0x7); */
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 56, 4, 3, 4, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h30004);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h380004);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_line(6, 2, 6, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h60002);
pci_burst_data(rbase_a+XY1,4'h0,32'h6000c);
wait_for_pipe_a;
/* bbird_line(7, 2, 7, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h70002);
pci_burst_data(rbase_a+XY1,4'h0,32'h7000c);
wait_for_pipe_a;
/* bbird_line(8, 2, 8, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h80002);
pci_burst_data(rbase_a+XY1,4'h0,32'h8000c);
wait_for_pipe_a;
/* bbird_line(9, 2, 9, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h90002);
pci_burst_data(rbase_a+XY1,4'h0,32'h9000c);
wait_for_pipe_a;
/* bbird_line(10, 2, 10, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'ha0002);
pci_burst_data(rbase_a+XY1,4'h0,32'ha000c);
wait_for_pipe_a;
/* bbird_line(11, 2, 11, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'hb0002);
pci_burst_data(rbase_a+XY1,4'h0,32'hb000c);
wait_for_pipe_a;
/* bbird_line(12, 2, 12, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'hc0002);
pci_burst_data(rbase_a+XY1,4'h0,32'hc000c);
wait_for_pipe_a;
/* bbird_line(13, 2, 13, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'hd0002);
pci_burst_data(rbase_a+XY1,4'h0,32'hd000c);
wait_for_pipe_a;
/* bbird_line(14, 2, 14, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'he0002);
pci_burst_data(rbase_a+XY1,4'h0,32'he000c);
wait_for_pipe_a;
/* bbird_line(15, 2, 15, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'hf0002);
pci_burst_data(rbase_a+XY1,4'h0,32'hf000c);
wait_for_pipe_a;
/* bbird_line(16, 2, 16, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h100002);
pci_burst_data(rbase_a+XY1,4'h0,32'h10000c);
wait_for_pipe_a;
/* bbird_line(17, 2, 17, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h110002);
pci_burst_data(rbase_a+XY1,4'h0,32'h11000c);
wait_for_pipe_a;
/* bbird_line(18, 2, 18, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h120002);
pci_burst_data(rbase_a+XY1,4'h0,32'h12000c);
wait_for_pipe_a;
/* bbird_line(19, 2, 19, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h130002);
pci_burst_data(rbase_a+XY1,4'h0,32'h13000c);
wait_for_pipe_a;
/* bbird_line(20, 2, 20, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h140002);
pci_burst_data(rbase_a+XY1,4'h0,32'h14000c);
wait_for_pipe_a;
/* bbird_line(21, 2, 21, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h150002);
pci_burst_data(rbase_a+XY1,4'h0,32'h15000c);
wait_for_pipe_a;
/* bbird_line(22, 2, 22, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h160002);
pci_burst_data(rbase_a+XY1,4'h0,32'h16000c);
wait_for_pipe_a;
/* bbird_line(23, 2, 23, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h170002);
pci_burst_data(rbase_a+XY1,4'h0,32'h17000c);
wait_for_pipe_a;
/* bbird_line(24, 2, 24, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h180002);
pci_burst_data(rbase_a+XY1,4'h0,32'h18000c);
wait_for_pipe_a;
/* bbird_line(25, 2, 25, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h190002);
pci_burst_data(rbase_a+XY1,4'h0,32'h19000c);
wait_for_pipe_a;
/* bbird_line(26, 2, 26, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h1a0002);
pci_burst_data(rbase_a+XY1,4'h0,32'h1a000c);
wait_for_pipe_a;
/* bbird_line(27, 2, 27, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h1b0002);
pci_burst_data(rbase_a+XY1,4'h0,32'h1b000c);
wait_for_pipe_a;
/* bbird_line(28, 2, 28, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h1c0002);
pci_burst_data(rbase_a+XY1,4'h0,32'h1c000c);
wait_for_pipe_a;
/* bbird_line(29, 2, 29, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h1d0002);
pci_burst_data(rbase_a+XY1,4'h0,32'h1d000c);
wait_for_pipe_a;
/* bbird_line(30, 2, 30, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h1e0002);
pci_burst_data(rbase_a+XY1,4'h0,32'h1e000c);
wait_for_pipe_a;
/* bbird_line(31, 2, 31, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h1f0002);
pci_burst_data(rbase_a+XY1,4'h0,32'h1f000c);
wait_for_pipe_a;
/* bbird_line(32, 2, 32, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h200002);
pci_burst_data(rbase_a+XY1,4'h0,32'h20000c);
wait_for_pipe_a;
/* bbird_line(33, 2, 33, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h210002);
pci_burst_data(rbase_a+XY1,4'h0,32'h21000c);
wait_for_pipe_a;
/* bbird_line(34, 2, 34, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h220002);
pci_burst_data(rbase_a+XY1,4'h0,32'h22000c);
wait_for_pipe_a;
/* bbird_line(35, 2, 35, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h230002);
pci_burst_data(rbase_a+XY1,4'h0,32'h23000c);
wait_for_pipe_a;
/* bbird_line(36, 2, 36, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h240002);
pci_burst_data(rbase_a+XY1,4'h0,32'h24000c);
wait_for_pipe_a;
/* bbird_line(37, 2, 37, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h250002);
pci_burst_data(rbase_a+XY1,4'h0,32'h25000c);
wait_for_pipe_a;
/* bbird_line(38, 2, 38, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h260002);
pci_burst_data(rbase_a+XY1,4'h0,32'h26000c);
wait_for_pipe_a;
/* bbird_line(39, 2, 39, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h270002);
pci_burst_data(rbase_a+XY1,4'h0,32'h27000c);
wait_for_pipe_a;
/* bbird_line(40, 2, 40, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h280002);
pci_burst_data(rbase_a+XY1,4'h0,32'h28000c);
wait_for_pipe_a;
/* bbird_line(41, 2, 41, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h290002);
pci_burst_data(rbase_a+XY1,4'h0,32'h29000c);
wait_for_pipe_a;
/* bbird_line(42, 2, 42, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h2a0002);
pci_burst_data(rbase_a+XY1,4'h0,32'h2a000c);
wait_for_pipe_a;
/* bbird_line(43, 2, 43, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h2b0002);
pci_burst_data(rbase_a+XY1,4'h0,32'h2b000c);
wait_for_pipe_a;
/* bbird_line(44, 2, 44, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h2c0002);
pci_burst_data(rbase_a+XY1,4'h0,32'h2c000c);
wait_for_pipe_a;
/* bbird_line(45, 2, 45, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h2d0002);
pci_burst_data(rbase_a+XY1,4'h0,32'h2d000c);
wait_for_pipe_a;
/* bbird_line(46, 2, 46, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h2e0002);
pci_burst_data(rbase_a+XY1,4'h0,32'h2e000c);
wait_for_pipe_a;
/* bbird_line(47, 2, 47, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h2f0002);
pci_burst_data(rbase_a+XY1,4'h0,32'h2f000c);
wait_for_pipe_a;
/* bbird_line(48, 2, 48, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h300002);
pci_burst_data(rbase_a+XY1,4'h0,32'h30000c);
wait_for_pipe_a;
/* bbird_line(49, 2, 49, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h310002);
pci_burst_data(rbase_a+XY1,4'h0,32'h31000c);
wait_for_pipe_a;
/* bbird_line(50, 2, 50, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h320002);
pci_burst_data(rbase_a+XY1,4'h0,32'h32000c);
wait_for_pipe_a;
/* bbird_line(51, 2, 51, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h330002);
pci_burst_data(rbase_a+XY1,4'h0,32'h33000c);
wait_for_pipe_a;
/* bbird_line(52, 2, 52, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h340002);
pci_burst_data(rbase_a+XY1,4'h0,32'h34000c);
wait_for_pipe_a;
/* bbird_line(53, 2, 53, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h350002);
pci_burst_data(rbase_a+XY1,4'h0,32'h35000c);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x8410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c00);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_memxfer_setup(0, 0x200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h40, 32'h10, "junk", 32'h180, 2'h0);
