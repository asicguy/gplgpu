// 
// # Reverse direction bitblit test
$display("# Reverse direction bitblit test");
// memxfer_setup 0 0 0xFFFFFFFF
pci_burst_data(rbase_w + 32'h00000000, 4'h0, 32'h00000000);
pci_burst_data(rbase_w + 32'h00000024, 4'h0, 32'hffffffff);
// 
// # Set bitmap to 8 bits/pixel, 512x16, starting at address 0.
$display("# Set bitmap to 8 bits/pixel, 512x16, starting at address 0.");
// bitmap 8 512 16 0
pci_burst_data(rbase_a + 32'h00000048, 4'h0, 32'h0);
pci_burst_data(rbase_a + 32'h00000020, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000028, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000002c, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000040, 4'h0, 32'h00000200);
pci_burst_data(rbase_a + 32'h00000044, 4'h0, 32'h00000200);
pci_burst_data(rbase_a + 32'h00000080, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000084, 4'h0, 32'h02000010);
// clear_mem
VR.ram_fill32(32'h00000000, 128, 0);
VR.ram_fill32(32'h00000080, 128, 0);
VR.ram_fill32(32'h00000100, 128, 0);
VR.ram_fill32(32'h00000180, 128, 0);
VR.ram_fill32(32'h00000200, 128, 0);
VR.ram_fill32(32'h00000280, 128, 0);
VR.ram_fill32(32'h00000300, 128, 0);
VR.ram_fill32(32'h00000380, 128, 0);
VR.ram_fill32(32'h00000400, 128, 0);
VR.ram_fill32(32'h00000480, 128, 0);
VR.ram_fill32(32'h00000500, 128, 0);
VR.ram_fill32(32'h00000580, 128, 0);
VR.ram_fill32(32'h00000600, 128, 0);
VR.ram_fill32(32'h00000680, 128, 0);
VR.ram_fill32(32'h00000700, 128, 0);
VR.ram_fill32(32'h00000780, 128, 0);
// 
// cmd_raster_op 0xC	// Copy
pci_burst_data(rbase_a + 32'h00000054, 4'h0, 32'h0000000c);
// cmd_style 0 
pci_burst_data(rbase_a + 32'h00000058, 4'h0, 32'h00000000);
// cmd_clip 2	// Clip in
pci_burst_data(rbase_a + 32'h00000060, 4'h0, 32'h00000002);
// 
// write_mem 0x40000000 128	// 
// 0x141c1316 0x181b151e 0x1e101b1b 0x1f141314 0x1714161a 0x1910161f 0x16161617 0x121d191c 
pci_burst_data(0 + 32'h40000000, 4'h0, 32'h141c1316);
pci_burst_data(0 + 32'h40000004, 4'h0, 32'h181b151e);
pci_burst_data(0 + 32'h40000008, 4'h0, 32'h1e101b1b);
pci_burst_data(0 + 32'h4000000c, 4'h0, 32'h1f141314);
pci_burst_data(0 + 32'h40000010, 4'h0, 32'h1714161a);
pci_burst_data(0 + 32'h40000014, 4'h0, 32'h1910161f);
pci_burst_data(0 + 32'h40000018, 4'h0, 32'h16161617);
pci_burst_data(0 + 32'h4000001c, 4'h0, 32'h121d191c);
// 0x1a16191c 0x1912111e 0x1118121d 0x10101c15 0x12171512 0x131b181b 0x1a19121e 0x171d161b 
pci_burst_data(0 + 32'h40000020, 4'h0, 32'h1a16191c);
pci_burst_data(0 + 32'h40000024, 4'h0, 32'h1912111e);
pci_burst_data(0 + 32'h40000028, 4'h0, 32'h1118121d);
pci_burst_data(0 + 32'h4000002c, 4'h0, 32'h10101c15);
pci_burst_data(0 + 32'h40000030, 4'h0, 32'h12171512);
pci_burst_data(0 + 32'h40000034, 4'h0, 32'h131b181b);
pci_burst_data(0 + 32'h40000038, 4'h0, 32'h1a19121e);
pci_burst_data(0 + 32'h4000003c, 4'h0, 32'h171d161b);
// 0x1e121310 0x12181415 0x1c131017 0x1e1c131c 0x14101418 0x1a171c1c 0x1914101e 0x16101116 
pci_burst_data(0 + 32'h40000040, 4'h0, 32'h1e121310);
pci_burst_data(0 + 32'h40000044, 4'h0, 32'h12181415);
pci_burst_data(0 + 32'h40000048, 4'h0, 32'h1c131017);
pci_burst_data(0 + 32'h4000004c, 4'h0, 32'h1e1c131c);
pci_burst_data(0 + 32'h40000050, 4'h0, 32'h14101418);
pci_burst_data(0 + 32'h40000054, 4'h0, 32'h1a171c1c);
pci_burst_data(0 + 32'h40000058, 4'h0, 32'h1914101e);
pci_burst_data(0 + 32'h4000005c, 4'h0, 32'h16101116);
// 0x1a151215 0x1e1c1d17 0x191a1f1d 0x1b171712 0x171f181b 0x12111614 0x1c1b1516 0x1c131b17 
pci_burst_data(0 + 32'h40000060, 4'h0, 32'h1a151215);
pci_burst_data(0 + 32'h40000064, 4'h0, 32'h1e1c1d17);
pci_burst_data(0 + 32'h40000068, 4'h0, 32'h191a1f1d);
pci_burst_data(0 + 32'h4000006c, 4'h0, 32'h1b171712);
pci_burst_data(0 + 32'h40000070, 4'h0, 32'h171f181b);
pci_burst_data(0 + 32'h40000074, 4'h0, 32'h12111614);
pci_burst_data(0 + 32'h40000078, 4'h0, 32'h1c1b1516);
pci_burst_data(0 + 32'h4000007c, 4'h0, 32'h1c131b17);
// 0x1516181e 0x12131215 0x131b1d11 0x1f1e1214 0x1e161d1a 0x19101713 0x14161b1d 0x15101917 
pci_burst_data(0 + 32'h40000080, 4'h0, 32'h1516181e);
pci_burst_data(0 + 32'h40000084, 4'h0, 32'h12131215);
pci_burst_data(0 + 32'h40000088, 4'h0, 32'h131b1d11);
pci_burst_data(0 + 32'h4000008c, 4'h0, 32'h1f1e1214);
pci_burst_data(0 + 32'h40000090, 4'h0, 32'h1e161d1a);
pci_burst_data(0 + 32'h40000094, 4'h0, 32'h19101713);
pci_burst_data(0 + 32'h40000098, 4'h0, 32'h14161b1d);
pci_burst_data(0 + 32'h4000009c, 4'h0, 32'h15101917);
// 0x161a1611 0x19181d18 0x1f1c131a 0x101e1b15 0x1c1e1518 0x19151f1c 0x111d1b1a 0x15161d14 
pci_burst_data(0 + 32'h400000a0, 4'h0, 32'h161a1611);
pci_burst_data(0 + 32'h400000a4, 4'h0, 32'h19181d18);
pci_burst_data(0 + 32'h400000a8, 4'h0, 32'h1f1c131a);
pci_burst_data(0 + 32'h400000ac, 4'h0, 32'h101e1b15);
pci_burst_data(0 + 32'h400000b0, 4'h0, 32'h1c1e1518);
pci_burst_data(0 + 32'h400000b4, 4'h0, 32'h19151f1c);
pci_burst_data(0 + 32'h400000b8, 4'h0, 32'h111d1b1a);
pci_burst_data(0 + 32'h400000bc, 4'h0, 32'h15161d14);
// 0x1b1b1013 0x1814131d 0x1c171116 0x141c151c 0x17101a1a 0x14101619 0x16151e11 0x1f1b1c1b 
pci_burst_data(0 + 32'h400000c0, 4'h0, 32'h1b1b1013);
pci_burst_data(0 + 32'h400000c4, 4'h0, 32'h1814131d);
pci_burst_data(0 + 32'h400000c8, 4'h0, 32'h1c171116);
pci_burst_data(0 + 32'h400000cc, 4'h0, 32'h141c151c);
pci_burst_data(0 + 32'h400000d0, 4'h0, 32'h17101a1a);
pci_burst_data(0 + 32'h400000d4, 4'h0, 32'h14101619);
pci_burst_data(0 + 32'h400000d8, 4'h0, 32'h16151e11);
pci_burst_data(0 + 32'h400000dc, 4'h0, 32'h1f1b1c1b);
// 0x1a1a171c 0x11121f1a 0x1c1d1910 0x1910191e 0x1d101113 0x18111017 0x1a1e161e 0x1f191a12 
pci_burst_data(0 + 32'h400000e0, 4'h0, 32'h1a1a171c);
pci_burst_data(0 + 32'h400000e4, 4'h0, 32'h11121f1a);
pci_burst_data(0 + 32'h400000e8, 4'h0, 32'h1c1d1910);
pci_burst_data(0 + 32'h400000ec, 4'h0, 32'h1910191e);
pci_burst_data(0 + 32'h400000f0, 4'h0, 32'h1d101113);
pci_burst_data(0 + 32'h400000f4, 4'h0, 32'h18111017);
pci_burst_data(0 + 32'h400000f8, 4'h0, 32'h1a1e161e);
pci_burst_data(0 + 32'h400000fc, 4'h0, 32'h1f191a12);
// 0x1b191311 0x121c1b12 0x121e1914 0x161b1f12 0x17131b10 0x1a1f141c 0x1d141e1a 0x191c1d18 
pci_burst_data(0 + 32'h40000100, 4'h0, 32'h1b191311);
pci_burst_data(0 + 32'h40000104, 4'h0, 32'h121c1b12);
pci_burst_data(0 + 32'h40000108, 4'h0, 32'h121e1914);
pci_burst_data(0 + 32'h4000010c, 4'h0, 32'h161b1f12);
pci_burst_data(0 + 32'h40000110, 4'h0, 32'h17131b10);
pci_burst_data(0 + 32'h40000114, 4'h0, 32'h1a1f141c);
pci_burst_data(0 + 32'h40000118, 4'h0, 32'h1d141e1a);
pci_burst_data(0 + 32'h4000011c, 4'h0, 32'h191c1d18);
// 0x13141511 0x14161110 0x1d16141a 0x13131213 0x191a161d 0x14141a1a 0x10111818 0x17191d16 
pci_burst_data(0 + 32'h40000120, 4'h0, 32'h13141511);
pci_burst_data(0 + 32'h40000124, 4'h0, 32'h14161110);
pci_burst_data(0 + 32'h40000128, 4'h0, 32'h1d16141a);
pci_burst_data(0 + 32'h4000012c, 4'h0, 32'h13131213);
pci_burst_data(0 + 32'h40000130, 4'h0, 32'h191a161d);
pci_burst_data(0 + 32'h40000134, 4'h0, 32'h14141a1a);
pci_burst_data(0 + 32'h40000138, 4'h0, 32'h10111818);
pci_burst_data(0 + 32'h4000013c, 4'h0, 32'h17191d16);
// 0x121a1d12 0x1916101e 0x18161d15 0x1c1c191f 0x1916161f 0x181d1a10 0x18181f12 0x1f1f111c 
pci_burst_data(0 + 32'h40000140, 4'h0, 32'h121a1d12);
pci_burst_data(0 + 32'h40000144, 4'h0, 32'h1916101e);
pci_burst_data(0 + 32'h40000148, 4'h0, 32'h18161d15);
pci_burst_data(0 + 32'h4000014c, 4'h0, 32'h1c1c191f);
pci_burst_data(0 + 32'h40000150, 4'h0, 32'h1916161f);
pci_burst_data(0 + 32'h40000154, 4'h0, 32'h181d1a10);
pci_burst_data(0 + 32'h40000158, 4'h0, 32'h18181f12);
pci_burst_data(0 + 32'h4000015c, 4'h0, 32'h1f1f111c);
// 0x1d111a1f 0x1f16181a 0x14181c15 0x14101415 0x1b1d161a 0x13131b10 0x161b1c1a 0x1c151b1d 
pci_burst_data(0 + 32'h40000160, 4'h0, 32'h1d111a1f);
pci_burst_data(0 + 32'h40000164, 4'h0, 32'h1f16181a);
pci_burst_data(0 + 32'h40000168, 4'h0, 32'h14181c15);
pci_burst_data(0 + 32'h4000016c, 4'h0, 32'h14101415);
pci_burst_data(0 + 32'h40000170, 4'h0, 32'h1b1d161a);
pci_burst_data(0 + 32'h40000174, 4'h0, 32'h13131b10);
pci_burst_data(0 + 32'h40000178, 4'h0, 32'h161b1c1a);
pci_burst_data(0 + 32'h4000017c, 4'h0, 32'h1c151b1d);
// 0x1f1a1715 0x141f101f 0x1218171d 0x1517181b 0x1f10141f 0x1912141f 0x1d101e10 0x1e1a1519 
pci_burst_data(0 + 32'h40000180, 4'h0, 32'h1f1a1715);
pci_burst_data(0 + 32'h40000184, 4'h0, 32'h141f101f);
pci_burst_data(0 + 32'h40000188, 4'h0, 32'h1218171d);
pci_burst_data(0 + 32'h4000018c, 4'h0, 32'h1517181b);
pci_burst_data(0 + 32'h40000190, 4'h0, 32'h1f10141f);
pci_burst_data(0 + 32'h40000194, 4'h0, 32'h1912141f);
pci_burst_data(0 + 32'h40000198, 4'h0, 32'h1d101e10);
pci_burst_data(0 + 32'h4000019c, 4'h0, 32'h1e1a1519);
// 0x1b1d141c 0x111f1c14 0x1e141713 0x1f141b10 0x1f1e141f 0x18181118 0x1816181f 0x1a16101e 
pci_burst_data(0 + 32'h400001a0, 4'h0, 32'h1b1d141c);
pci_burst_data(0 + 32'h400001a4, 4'h0, 32'h111f1c14);
pci_burst_data(0 + 32'h400001a8, 4'h0, 32'h1e141713);
pci_burst_data(0 + 32'h400001ac, 4'h0, 32'h1f141b10);
pci_burst_data(0 + 32'h400001b0, 4'h0, 32'h1f1e141f);
pci_burst_data(0 + 32'h400001b4, 4'h0, 32'h18181118);
pci_burst_data(0 + 32'h400001b8, 4'h0, 32'h1816181f);
pci_burst_data(0 + 32'h400001bc, 4'h0, 32'h1a16101e);
// 0x18161314 0x131a1510 0x1d121e1d 0x181c1619 0x13171a1a 0x1a1b101b 0x16121118 0x15111811 
pci_burst_data(0 + 32'h400001c0, 4'h0, 32'h18161314);
pci_burst_data(0 + 32'h400001c4, 4'h0, 32'h131a1510);
pci_burst_data(0 + 32'h400001c8, 4'h0, 32'h1d121e1d);
pci_burst_data(0 + 32'h400001cc, 4'h0, 32'h181c1619);
pci_burst_data(0 + 32'h400001d0, 4'h0, 32'h13171a1a);
pci_burst_data(0 + 32'h400001d4, 4'h0, 32'h1a1b101b);
pci_burst_data(0 + 32'h400001d8, 4'h0, 32'h16121118);
pci_burst_data(0 + 32'h400001dc, 4'h0, 32'h15111811);
// 0x1c1e171c 0x191f181c 0x1f161116 0x12171217 0x18151f1d 0x1713101f 0x131e1512 0x1a191f1e 
pci_burst_data(0 + 32'h400001e0, 4'h0, 32'h1c1e171c);
pci_burst_data(0 + 32'h400001e4, 4'h0, 32'h191f181c);
pci_burst_data(0 + 32'h400001e8, 4'h0, 32'h1f161116);
pci_burst_data(0 + 32'h400001ec, 4'h0, 32'h12171217);
pci_burst_data(0 + 32'h400001f0, 4'h0, 32'h18151f1d);
pci_burst_data(0 + 32'h400001f4, 4'h0, 32'h1713101f);
pci_burst_data(0 + 32'h400001f8, 4'h0, 32'h131e1512);
pci_burst_data(0 + 32'h400001fc, 4'h0, 32'h1a191f1e);
// 
// bitblit   0  0  0  1  512 1
pci_burst_data(rbase_a + 32'h00000050, 4'h0, 32'h00000001);
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h02000001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00000001);
// bitblit   0  0  0  2  512 2
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h02000002);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00000002);
// bitblit   0  0  0  4  512 4
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h02000004);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00000004);
// bitblit   0  0  0  8  512 8
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h02000008);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00000008);
// 
$display("#define T2R_DIR_RL_TB         0x02            /* right-left, top-bottom */");
// #bitblit srcx srcy dstx dsty width height dir zoom
$display("#bitblit srcx srcy dstx dsty width height dir zoom");
// bitblit 490 1 491 1 490 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h01ea0001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h01ea0001);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h01eb0001);
// bitblit 490 2 492 2 490 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h01ea0001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h01ea0002);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h01ec0002);
// bitblit 490 3 493 3 490 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h01ea0001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h01ea0003);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h01ed0003);
// bitblit 490 4 494 4 490 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h01ea0001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h01ea0004);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h01ee0004);
// bitblit 490 5 495 5 490 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h01ea0001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h01ea0005);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h01ef0005);
// bitblit 490 6 496 6 490 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h01ea0001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h01ea0006);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h01f00006);
// bitblit 490 7 497 7 490 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h01ea0001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h01ea0007);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h01f10007);
// bitblit 490 8 498 8 490 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h01ea0001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h01ea0008);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h01f20008);
// bitblit 490 9 499 9 490 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h01ea0001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h01ea0009);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h01f30009);
// bitblit 490 10 500 10 490 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h01ea0001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h01ea000a);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h01f4000a);
// bitblit 490 11 501 11 490 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h01ea0001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h01ea000b);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h01f5000b);
// bitblit 490 12 502 12 490 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h01ea0001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h01ea000c);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h01f6000c);
// bitblit 490 13 503 13 490 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h01ea0001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h01ea000d);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h01f7000d);
// bitblit 490 14 504 14 490 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h01ea0001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h01ea000e);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h01f8000e);
// bitblit 490 15 505 15 490 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h01ea0001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h01ea000f);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h01f9000f);
// 
// 
// 
// 
// save_bmp junk 0 0 512 16
wait_for_pipe_a;
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h200, 32'h10, "junk", 32'h200, 32'h0);
// 
// end
