/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'h180);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0x180, 0x0); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'h180);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x180, 0x0, 0, 0, 127, 63); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h180);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h7f003f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 32, 0);
VR.ram_fill32(32'h60, 32, 0);
VR.ram_fill32(32'hc0, 32, 0);
VR.ram_fill32(32'h120, 32, 0);
VR.ram_fill32(32'h180, 32, 0);
VR.ram_fill32(32'h1e0, 32, 0);
VR.ram_fill32(32'h240, 32, 0);
VR.ram_fill32(32'h2a0, 32, 0);
VR.ram_fill32(32'h300, 32, 0);
VR.ram_fill32(32'h360, 32, 0);
VR.ram_fill32(32'h3c0, 32, 0);
VR.ram_fill32(32'h420, 32, 0);
VR.ram_fill32(32'h480, 32, 0);
VR.ram_fill32(32'h4e0, 32, 0);
VR.ram_fill32(32'h540, 32, 0);
VR.ram_fill32(32'h5a0, 32, 0);
VR.ram_fill32(32'h600, 32, 0);
VR.ram_fill32(32'h660, 32, 0);
VR.ram_fill32(32'h6c0, 32, 0);
VR.ram_fill32(32'h720, 32, 0);
VR.ram_fill32(32'h780, 32, 0);
VR.ram_fill32(32'h7e0, 32, 0);
VR.ram_fill32(32'h840, 32, 0);
VR.ram_fill32(32'h8a0, 32, 0);
VR.ram_fill32(32'h900, 32, 0);
VR.ram_fill32(32'h960, 32, 0);
VR.ram_fill32(32'h9c0, 32, 0);
VR.ram_fill32(32'ha20, 32, 0);
VR.ram_fill32(32'ha80, 32, 0);
VR.ram_fill32(32'hae0, 32, 0);
VR.ram_fill32(32'hb40, 32, 0);
VR.ram_fill32(32'hba0, 32, 0);
VR.ram_fill32(32'hc00, 32, 0);
VR.ram_fill32(32'hc60, 32, 0);
VR.ram_fill32(32'hcc0, 32, 0);
VR.ram_fill32(32'hd20, 32, 0);
VR.ram_fill32(32'hd80, 32, 0);
VR.ram_fill32(32'hde0, 32, 0);
VR.ram_fill32(32'he40, 32, 0);
VR.ram_fill32(32'hea0, 32, 0);
VR.ram_fill32(32'hf00, 32, 0);
VR.ram_fill32(32'hf60, 32, 0);
VR.ram_fill32(32'hfc0, 32, 0);
VR.ram_fill32(32'h1020, 32, 0);
VR.ram_fill32(32'h1080, 32, 0);
VR.ram_fill32(32'h10e0, 32, 0);
VR.ram_fill32(32'h1140, 32, 0);
VR.ram_fill32(32'h11a0, 32, 0);
VR.ram_fill32(32'h1200, 32, 0);
VR.ram_fill32(32'h1260, 32, 0);
VR.ram_fill32(32'h12c0, 32, 0);
VR.ram_fill32(32'h1320, 32, 0);
VR.ram_fill32(32'h1380, 32, 0);
VR.ram_fill32(32'h13e0, 32, 0);
VR.ram_fill32(32'h1440, 32, 0);
VR.ram_fill32(32'h14a0, 32, 0);
VR.ram_fill32(32'h1500, 32, 0);
VR.ram_fill32(32'h1560, 32, 0);
VR.ram_fill32(32'h15c0, 32, 0);
VR.ram_fill32(32'h1620, 32, 0);
VR.ram_fill32(32'h1680, 32, 0);
VR.ram_fill32(32'h16e0, 32, 0);
VR.ram_fill32(32'h1740, 32, 0);
VR.ram_fill32(32'h17a0, 32, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x180, 0x0, 0, 0, 127, 63); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h180);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h7f003f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x8400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
wait_for_pipe_a;
/* bbird_line_pat(0x93939393, 0x10); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h93939393);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h10);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0x15, 0x16, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h15);
pci_burst_data(rbase_a+BACK,4'h0,32'h16);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_rectangle(0x5, 0x0, 0x25, 0x6); */
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 5, 0, 33, 7, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h210007);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h50000);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0x18, 0x17, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h18);
pci_burst_data(rbase_a+BACK,4'h0,32'h17);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_rectangle(0x10, 0x4, 0x20, 0xa); */
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 16, 4, 17, 7, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h110007);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h100004);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0xc00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'hc00);
/* bbird_area_pattern(0x20, 0x20, 0x2080000); */
wait_for_pipe_a;
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h40000300+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'hc01);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h800001);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800fe54, 0x0, 0x20, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h0);
pci_burst_data(32'h10000004, 4'h0, 32'h3c000);
pci_burst_data(32'h10000008, 4'h0, 32'h1c3800);
pci_burst_data(32'h1000000c, 4'h0, 32'h600600);
pci_burst_data(32'h10000010, 4'h0, 32'h8c3100);
pci_burst_data(32'h10000014, 4'h0, 32'h1142880);
pci_burst_data(32'h10000018, 4'h0, 32'h1181880);
pci_burst_data(32'h1000001c, 4'h0, 32'h2018040);
pci_burst_data(32'h10000020, 4'h0, 32'h203c040);
pci_burst_data(32'h10000024, 4'h0, 32'h1100880);
pci_burst_data(32'h10000028, 4'h0, 32'h10c3080);
pci_burst_data(32'h1000002c, 4'h0, 32'h83c100);
pci_burst_data(32'h10000030, 4'h0, 32'h600600);
pci_burst_data(32'h10000034, 4'h0, 32'h1c3800);
pci_burst_data(32'h10000038, 4'h0, 32'h3c000);
pci_burst_data(32'h1000003c, 4'h0, 32'h0);
pci_burst_data(32'h10000040, 4'h0, 32'h0);
pci_burst_data(32'h10000044, 4'h0, 32'h3c000);
pci_burst_data(32'h10000048, 4'h0, 32'h1c3800);
pci_burst_data(32'h1000004c, 4'h0, 32'h600600);
pci_burst_data(32'h10000050, 4'h0, 32'h8c3100);
pci_burst_data(32'h10000054, 4'h0, 32'h1142880);
pci_burst_data(32'h10000058, 4'h0, 32'h1181880);
pci_burst_data(32'h1000005c, 4'h0, 32'h2018040);
pci_burst_data(32'h10000060, 4'h0, 32'h203c040);
pci_burst_data(32'h10000064, 4'h0, 32'h1100880);
pci_burst_data(32'h10000068, 4'h0, 32'h10c3080);
pci_burst_data(32'h1000006c, 4'h0, 32'h83c100);
pci_burst_data(32'h10000070, 4'h0, 32'h600600);
pci_burst_data(32'h10000074, 4'h0, 32'h1c3800);
pci_burst_data(32'h10000078, 4'h0, 32'h3c000);
pci_burst_data(32'h1000007c, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h200020);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x2480c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h2480c00);
wait_for_pipe_a;
/* bbird_bitblit(32, 32, 31, 3, 34, 17, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h220011);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h200020);
pci_burst_data(rbase_a+XY1,4'h0,32'h1f0003);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_memxfer_setup(0, 0x200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h40, 32'h20, "junk", 32'h180, 2'h0);
