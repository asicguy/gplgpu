/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'h280);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0x280, 0x0); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'h280);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x280, 0x0, 0, 0, 191, 31); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h280);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'hbf001f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 48, 0);
VR.ram_fill32(32'ha0, 48, 0);
VR.ram_fill32(32'h140, 48, 0);
VR.ram_fill32(32'h1e0, 48, 0);
VR.ram_fill32(32'h280, 48, 0);
VR.ram_fill32(32'h320, 48, 0);
VR.ram_fill32(32'h3c0, 48, 0);
VR.ram_fill32(32'h460, 48, 0);
VR.ram_fill32(32'h500, 48, 0);
VR.ram_fill32(32'h5a0, 48, 0);
VR.ram_fill32(32'h640, 48, 0);
VR.ram_fill32(32'h6e0, 48, 0);
VR.ram_fill32(32'h780, 48, 0);
VR.ram_fill32(32'h820, 48, 0);
VR.ram_fill32(32'h8c0, 48, 0);
VR.ram_fill32(32'h960, 48, 0);
VR.ram_fill32(32'ha00, 48, 0);
VR.ram_fill32(32'haa0, 48, 0);
VR.ram_fill32(32'hb40, 48, 0);
VR.ram_fill32(32'hbe0, 48, 0);
VR.ram_fill32(32'hc80, 48, 0);
VR.ram_fill32(32'hd20, 48, 0);
VR.ram_fill32(32'hdc0, 48, 0);
VR.ram_fill32(32'he60, 48, 0);
VR.ram_fill32(32'hf00, 48, 0);
VR.ram_fill32(32'hfa0, 48, 0);
VR.ram_fill32(32'h1040, 48, 0);
VR.ram_fill32(32'h10e0, 48, 0);
VR.ram_fill32(32'h1180, 48, 0);
VR.ram_fill32(32'h1220, 48, 0);
VR.ram_fill32(32'h12c0, 48, 0);
VR.ram_fill32(32'h1360, 48, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x280, 0x0, 0, 0, 191, 31); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h280);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'hbf001f);
/* bbird_memxfer_setup(0, 0x200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
/* bbird_memxfer_setup(1, 0x0, 0x0, 0x0, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW1_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_CTRL,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_WKEY,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_KYDAT,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_line_pat(0x16, 0x5); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h16);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h5);
wait_for_pipe_a;
/* bbird_colors(0x1, 0x9, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
pci_burst_data(rbase_a+BACK,4'h0,32'h9);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_rectangle(0x28, 0x8, 0x3b, 0xd); */
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 40, 8, 20, 6, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h140006);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h280008);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_write_pixel(0x0, 0x2, 0x33333333); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h33333333);
pci_burst_data(rbase_a+XY0,4'h0,32'h2);
pci_burst_data(rbase_a+XY1,4'h0,32'h2);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
wait_for_pipe_a;
/* bbird_write_pixel(0x2, 0x3, 0x33333333); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h33333333);
pci_burst_data(rbase_a+XY0,4'h0,32'h20003);
pci_burst_data(rbase_a+XY1,4'h0,32'h20003);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
wait_for_pipe_a;
/* bbird_colors(0x13, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h13);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
pci_burst_data(32'h40000004, 4'h0, 32'h01020300);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x420c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h420c00);
/* bbird_font_write("Hello world!"); { 0x5, 0x2 } */
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'h4e0c01);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+32'hF8,4'h0,32'h0);
/* Writing character 'H' */
/* bbird_font_cache(0, 32, 'H', 0x1); */
/* caching character 'H' */
pci_burst_data(32'ha0005000, 4'h0, 32'h0);
pci_burst_data(32'ha0005004, 4'h0, 32'h0);
pci_burst_data(32'ha0005008, 4'h0, 32'h3cc000);
pci_burst_data(32'ha000500c, 4'h0, 32'h3e6000);
pci_burst_data(32'ha0005010, 4'h0, 32'hc0033ffc);
pci_burst_data(32'ha0005014, 4'h0, 32'he0019ffe);
pci_burst_data(32'ha0005018, 4'h0, 32'h7000cfff);
pci_burst_data(32'ha000501c, 4'h0, 32'h3000e7ff);
pci_burst_data(32'ha0005020, 4'h0, 32'h30c0f303);
pci_burst_data(32'ha0005024, 4'h0, 32'h11e0f383);
pci_burst_data(32'ha0005028, 4'h0, 32'h3f0f3c0);
pci_burst_data(32'ha000502c, 4'h0, 32'h7f8f3c0);
pci_burst_data(32'ha0005030, 4'h0, 32'hfccf3c0);
pci_burst_data(32'ha0005034, 4'h0, 32'hf86f3c0);
pci_burst_data(32'ha0005038, 4'h0, 32'hf03f3c0);
pci_burst_data(32'ha000503c, 4'h0, 32'hf01f3c0);
pci_burst_data(32'ha0005040, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha0005044, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha0005048, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha000504c, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha0005050, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha0005054, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha0005058, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha000505c, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha0005060, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha0005064, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha0005068, 4'h0, 32'hcf00f3c0);
pci_burst_data(32'ha000506c, 4'h0, 32'hef00f3c0);
pci_burst_data(32'ha0005070, 4'h0, 32'hf780f3c0);
pci_burst_data(32'ha0005074, 4'h0, 32'hf3c079e0);
pci_burst_data(32'ha0005078, 4'h0, 32'h31e03cf0);
pci_burst_data(32'ha000507c, 4'h0, 32'h10f01ef8);
pci_burst_data(32'ha0005080, 4'h0, 32'h780ffc);
pci_burst_data(32'ha0005084, 4'h0, 32'h3c07fe);
pci_burst_data(32'ha0005088, 4'h0, 32'h1c0003);
pci_burst_data(32'ha000508c, 4'h0, 32'h180001);
pci_burst_data(32'ha0005090, 4'h0, 32'h300000);
pci_burst_data(32'ha0005094, 4'h0, 32'h200000);
pci_burst_data(32'ha0005098, 4'h0, 32'h0);
pci_burst_data(32'ha000509c, 4'h0, 32'h0);
pci_burst_data(32'ha00050a0, 4'h0, 32'h5000);
pci_burst_data(32'ha00050a4, 4'h0, 32'h1c28);
/* Writing character 'e' */
/* bbird_font_cache(176, 32, 'e', 0x1); */
/* caching character 'e' */
pci_burst_data(32'ha00050b0, 4'h0, 32'h0);
pci_burst_data(32'ha00050b4, 4'h0, 32'h0);
pci_burst_data(32'ha00050b8, 4'h0, 32'h0);
pci_burst_data(32'ha00050bc, 4'h0, 32'h0);
pci_burst_data(32'ha00050c0, 4'h0, 32'h0);
pci_burst_data(32'ha00050c4, 4'h0, 32'hf800700);
pci_burst_data(32'ha00050c8, 4'h0, 32'h3fe01fc0);
pci_burst_data(32'ha00050cc, 4'h0, 32'h7e387f30);
pci_burst_data(32'ha00050d0, 4'h0, 32'h3c3e7c3c);
pci_burst_data(32'ha00050d4, 4'h0, 32'hc3d1c3f);
pci_burst_data(32'ha00050d8, 4'h0, 32'h33c063c);
pci_burst_data(32'ha00050dc, 4'h0, 32'hfc01fc);
pci_burst_data(32'ha00050e0, 4'h0, 32'hfc00fc);
pci_burst_data(32'ha00050e4, 4'h0, 32'hc3fe81fc);
pci_burst_data(32'ha00050e8, 4'h0, 32'h3ff07ff9);
pci_burst_data(32'ha00050ec, 4'h0, 32'hfc01fe0);
pci_burst_data(32'ha00050f0, 4'h0, 32'h3000780);
pci_burst_data(32'ha00050f4, 4'h0, 32'h0);
pci_burst_data(32'ha00050f8, 4'h0, 32'h0);
pci_burst_data(32'ha00050fc, 4'h0, 32'h0);
pci_burst_data(32'ha0005100, 4'h0, 32'h50b0);
pci_burst_data(32'ha0005104, 4'h0, 32'h1028);
pci_burst_data(32'ha0000000, 4'h0, 32'ha0050a0);
pci_burst_data(32'ha0000004, 4'h0, 32'h80002);
pci_burst_data(32'ha0000008, 4'h0, 32'h5100);
pci_burst_data(32'ha000000c, 4'h0, 32'h260002);
/* Writing character 'l' */
/* bbird_font_cache(80, 33, 'l', 0x1); */
/* caching character 'l' */
pci_burst_data(32'ha00052d0, 4'h0, 32'hc0800000);
pci_burst_data(32'ha00052d4, 4'h0, 32'h3c3c3663);
pci_burst_data(32'ha00052d8, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha00052dc, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha00052e0, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha00052e4, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha00052e8, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha00052ec, 4'h0, 32'hf8fc3e3f);
pci_burst_data(32'ha00052f0, 4'h0, 32'h2070);
pci_burst_data(32'ha00052f4, 4'h0, 32'h0);
pci_burst_data(32'ha00052f8, 4'h0, 32'h52d0);
pci_burst_data(32'ha00052fc, 4'h0, 32'h828);
/* Writing character 'l' */
pci_burst_data(32'ha0000010, 4'h0, 32'ha0052f8);
pci_burst_data(32'ha0000014, 4'h0, 32'h380002);
pci_burst_data(32'ha0000018, 4'h0, 32'h52f8);
pci_burst_data(32'ha000001c, 4'h0, 32'h430002);
/* Writing character 'o' */
/* bbird_font_cache(128, 33, 'o', 0x1); */
/* caching character 'o' */
pci_burst_data(32'ha0005300, 4'h0, 32'h0);
pci_burst_data(32'ha0005304, 4'h0, 32'h0);
pci_burst_data(32'ha0005308, 4'h0, 32'h0);
pci_burst_data(32'ha000530c, 4'h0, 32'h0);
pci_burst_data(32'ha0005310, 4'h0, 32'h0);
pci_burst_data(32'ha0005314, 4'h0, 32'h7800300);
pci_burst_data(32'ha0005318, 4'h0, 32'h9fe00fc0);
pci_burst_data(32'ha000531c, 4'h0, 32'h7ff8dff0);
pci_burst_data(32'ha0005320, 4'h0, 32'h3e0e3f1c);
pci_burst_data(32'ha0005324, 4'h0, 32'h3c0f3c0e);
pci_burst_data(32'ha0005328, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha000532c, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha0005330, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha0005334, 4'h0, 32'h1c3e3c1f);
pci_burst_data(32'ha0005338, 4'h0, 32'hefc1c7e);
pci_burst_data(32'ha000533c, 4'h0, 32'h3f007f8);
pci_burst_data(32'ha0005340, 4'h0, 32'hc001e0);
pci_burst_data(32'ha0005344, 4'h0, 32'h0);
pci_burst_data(32'ha0005348, 4'h0, 32'h0);
pci_burst_data(32'ha000534c, 4'h0, 32'h0);
pci_burst_data(32'ha0005350, 4'h0, 32'h5300);
pci_burst_data(32'ha0005354, 4'h0, 32'he28);
/* Writing character ' ' */
/* bbird_font_cache(32, 34, ' ', 0x1); */
/* caching character ' ' */
/* Writing character 'w' */
/* bbird_font_cache(32, 34, 'w', 0x1); */
/* caching character 'w' */
pci_burst_data(32'ha0005520, 4'h0, 32'h0);
pci_burst_data(32'ha0005524, 4'h0, 32'h0);
pci_burst_data(32'ha0005528, 4'h0, 32'h0);
pci_burst_data(32'ha000552c, 4'h0, 32'h18000030);
pci_burst_data(32'ha0005530, 4'h0, 32'hc0000);
pci_burst_data(32'ha0005534, 4'h0, 32'he00);
pci_burst_data(32'ha0005538, 4'h0, 32'h7000007);
pci_burst_data(32'ha000553c, 4'h0, 32'h80f0000);
pci_burst_data(32'ha0005540, 4'h0, 32'h1c1c1f08);
pci_burst_data(32'ha0005544, 4'h0, 32'h7e3e3e3f);
pci_burst_data(32'ha0005548, 4'h0, 32'hfcfc3d7f);
pci_burst_data(32'ha000554c, 4'h0, 32'hbc7c7c3c);
pci_burst_data(32'ha0005550, 4'h0, 32'h3cfc3c3c);
pci_burst_data(32'ha0005554, 4'h0, 32'h3c3c7c3c);
pci_burst_data(32'ha0005558, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha000555c, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha0005560, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha0005564, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha0005568, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha000556c, 4'h0, 32'h3c3c7c3c);
pci_burst_data(32'ha0005570, 4'h0, 32'hfc3c3cfc);
pci_burst_data(32'ha0005574, 4'h0, 32'hfefc7c7f);
pci_burst_data(32'ha0005578, 4'h0, 32'hc7f0fcfc);
pci_burst_data(32'ha000557c, 4'h0, 32'hcf83e0df);
pci_burst_data(32'ha0005580, 4'h0, 32'h80c701c0);
pci_burst_data(32'ha0005584, 4'h0, 32'h4200);
pci_burst_data(32'ha0005588, 4'h0, 32'h0);
pci_burst_data(32'ha000558c, 4'h0, 32'h0);
pci_burst_data(32'ha0005590, 4'h0, 32'h0);
pci_burst_data(32'ha0005594, 4'h0, 32'h0);
pci_burst_data(32'ha0005598, 4'h0, 32'h5520);
pci_burst_data(32'ha000559c, 4'h0, 32'h1628);
pci_burst_data(32'ha0000020, 4'h0, 32'ha005350);
pci_burst_data(32'ha0000024, 4'h0, 32'h4d0002);
pci_burst_data(32'ha0000028, 4'h0, 32'h5598);
pci_burst_data(32'ha000002c, 4'h0, 32'h690002);
/* Writing character 'o' */
/* Writing character 'r' */
/* bbird_font_cache(160, 34, 'r', 0x1); */
/* caching character 'r' */
pci_burst_data(32'ha00055a0, 4'h0, 32'h0);
pci_burst_data(32'ha00055a4, 4'h0, 32'h0);
pci_burst_data(32'ha00055a8, 4'h0, 32'h0);
pci_burst_data(32'ha00055ac, 4'h0, 32'h0);
pci_burst_data(32'ha00055b0, 4'h0, 32'h0);
pci_burst_data(32'ha00055b4, 4'h0, 32'h0);
pci_burst_data(32'ha00055b8, 4'h0, 32'h0);
pci_burst_data(32'ha00055bc, 4'h0, 32'h30300000);
pci_burst_data(32'ha00055c0, 4'h0, 32'h787800);
pci_burst_data(32'ha00055c4, 4'h0, 32'hfe00fcfc);
pci_burst_data(32'ha00055c8, 4'h0, 32'hf3f701ff);
pci_burst_data(32'ha00055cc, 4'h0, 32'hc3e1f383);
pci_burst_data(32'ha00055d0, 4'h0, 32'hf0e3c0f0);
pci_burst_data(32'ha00055d4, 4'h0, 32'hc0f0e3c0);
pci_burst_data(32'ha00055d8, 4'h0, 32'he0c0f0e1);
pci_burst_data(32'ha00055dc, 4'h0, 32'hf0e000f0);
pci_burst_data(32'ha00055e0, 4'h0, 32'hf0e000);
pci_burst_data(32'ha00055e4, 4'h0, 32'h8000f0c0);
pci_burst_data(32'ha00055e8, 4'h0, 32'hf00000f0);
pci_burst_data(32'ha00055ec, 4'h0, 32'hf40000);
pci_burst_data(32'ha00055f0, 4'h0, 32'hc000fc80);
pci_burst_data(32'ha00055f4, 4'h0, 32'hf0e03cf8);
pci_burst_data(32'ha00055f8, 4'h0, 32'hfe0f01e);
pci_burst_data(32'ha00055fc, 4'h0, 32'hc07c0f8);
pci_burst_data(32'ha0005600, 4'h0, 32'h40380);
pci_burst_data(32'ha0005604, 4'h0, 32'h1);
pci_burst_data(32'ha0005608, 4'h0, 32'h0);
pci_burst_data(32'ha000560c, 4'h0, 32'h0);
pci_burst_data(32'ha0005610, 4'h0, 32'h0);
pci_burst_data(32'ha0005614, 4'h0, 32'h0);
pci_burst_data(32'ha0005618, 4'h0, 32'h55a0);
pci_burst_data(32'ha000561c, 4'h0, 32'h1228);
pci_burst_data(32'ha0000030, 4'h0, 32'ha005350);
pci_burst_data(32'ha0000034, 4'h0, 32'h800002);
pci_burst_data(32'ha0000038, 4'h0, 32'h5618);
pci_burst_data(32'ha000003c, 4'h0, 32'h8f0002);
/* Writing character 'l' */
/* Writing character 'd' */
/* bbird_font_cache(96, 35, 'd', 0x1); */
/* caching character 'd' */
pci_burst_data(32'ha00057e0, 4'h0, 32'h0);
pci_burst_data(32'ha00057e4, 4'h0, 32'h0);
pci_burst_data(32'ha00057e8, 4'h0, 32'h1e000c);
pci_burst_data(32'ha00057ec, 4'h0, 32'h7f003f);
pci_burst_data(32'ha00057f0, 4'h0, 32'h1fb00ff);
pci_burst_data(32'ha00057f4, 4'h0, 32'h7e003f0);
pci_burst_data(32'ha00057f8, 4'h0, 32'h7fe0cfc0);
pci_burst_data(32'ha00057fc, 4'h0, 32'h3e183f30);
pci_burst_data(32'ha0005800, 4'h0, 32'h3c0e3c0c);
pci_burst_data(32'ha0005804, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha0005808, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha000580c, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha0005810, 4'h0, 32'h3c3f3c1f);
pci_burst_data(32'ha0005814, 4'h0, 32'h3cff3c7f);
pci_burst_data(32'ha0005818, 4'h0, 32'hffc1ffe);
pci_burst_data(32'ha000581c, 4'h0, 32'h3f007f8);
pci_burst_data(32'ha0005820, 4'h0, 32'hc001e0);
pci_burst_data(32'ha0005824, 4'h0, 32'h0);
pci_burst_data(32'ha0005828, 4'h0, 32'h0);
pci_burst_data(32'ha000582c, 4'h0, 32'h0);
pci_burst_data(32'ha0005830, 4'h0, 32'h57e0);
pci_burst_data(32'ha0005834, 4'h0, 32'h1028);
pci_burst_data(32'ha0000040, 4'h0, 32'ha0052f8);
pci_burst_data(32'ha0000044, 4'h0, 32'ha30002);
pci_burst_data(32'ha0000048, 4'h0, 32'h5830);
pci_burst_data(32'ha000004c, 4'h0, 32'had0002);
/* Writing character '!' */
/* bbird_font_cache(192, 35, '!', 0x1); */
/* caching character '!' */
pci_burst_data(32'ha0005840, 4'h0, 32'h0);
pci_burst_data(32'ha0005844, 4'h0, 32'h0);
pci_burst_data(32'ha0005848, 4'h0, 32'h78783030);
pci_burst_data(32'ha000584c, 4'h0, 32'hfdfefcfc);
pci_burst_data(32'ha0005850, 4'h0, 32'hffffffff);
pci_burst_data(32'ha0005854, 4'h0, 32'h79fe7bff);
pci_burst_data(32'ha0005858, 4'h0, 32'h31fe31fe);
pci_burst_data(32'ha000585c, 4'h0, 32'hfc01fe);
pci_burst_data(32'ha0005860, 4'h0, 32'hfc00fc);
pci_burst_data(32'ha0005864, 4'h0, 32'h780078);
pci_burst_data(32'ha0005868, 4'h0, 32'h780078);
pci_burst_data(32'ha000586c, 4'h0, 32'h300030);
pci_burst_data(32'ha0005870, 4'h0, 32'h0);
pci_burst_data(32'ha0005874, 4'h0, 32'h780030);
pci_burst_data(32'ha0005878, 4'h0, 32'hfc00fc);
pci_burst_data(32'ha000587c, 4'h0, 32'h300078);
pci_burst_data(32'ha0005880, 4'h0, 32'h0);
pci_burst_data(32'ha0005884, 4'h0, 32'h0);
pci_burst_data(32'ha0005888, 4'h0, 32'h0);
pci_burst_data(32'ha000588c, 4'h0, 32'h0);
pci_burst_data(32'ha0005890, 4'h0, 32'h5840);
pci_burst_data(32'ha0005894, 4'h0, 32'ha28);
pci_burst_data(32'ha0000050, 4'h0, 32'h2005890);
pci_burst_data(32'ha0000054, 4'h0, 32'hc00002);
pci_burst_data(rbase_a+32'hFC,4'h0,32'h60);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x420c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h420c00);
rd(MEM_RD, 32'h40000000, 1);
wait_for_pipe_a;
/* bbird_write_pixel(0x2, 0x5, 0xcc); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'hcc);
pci_burst_data(rbase_a+XY0,4'h0,32'h20005);
pci_burst_data(rbase_a+XY1,4'h0,32'h20005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h420c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'hc0, 32'h20, "junk", 32'h280, 2'h0);
