wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h5bf80);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'h4080);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x5bf80, 0x4080, 0x0); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h5bf80);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'h4080);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x5bf80, 0x4080, 0x0, 0, 0, 63, 15); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h5bf80);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h4080);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h3f000f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h16fe0, 16, 0);
VR.ram_fill32(32'h18000, 16, 0);
VR.ram_fill32(32'h19020, 16, 0);
VR.ram_fill32(32'h1a040, 16, 0);
VR.ram_fill32(32'h1b060, 16, 0);
VR.ram_fill32(32'h1c080, 16, 0);
VR.ram_fill32(32'h1d0a0, 16, 0);
VR.ram_fill32(32'h1e0c0, 16, 0);
VR.ram_fill32(32'h1f0e0, 16, 0);
VR.ram_fill32(32'h20100, 16, 0);
VR.ram_fill32(32'h21120, 16, 0);
VR.ram_fill32(32'h22140, 16, 0);
VR.ram_fill32(32'h23160, 16, 0);
VR.ram_fill32(32'h24180, 16, 0);
VR.ram_fill32(32'h251a0, 16, 0);
VR.ram_fill32(32'h261c0, 16, 0);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x5bf80, 0x4080, 0x0, 0, 0, 63, 15); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h5bf80);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h4080);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h3f000f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x8400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
wait_for_pipe_a;
/* bbird_line_pat(0x6, 0x3); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h6);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h3);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line(0, 4, 5, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h4);
pci_burst_data(rbase_a+XY1,4'h0,32'h50000);
wait_for_pipe_a;
/* bbird_line(0, 5, 5, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h5);
pci_burst_data(rbase_a+XY1,4'h0,32'h50002);
wait_for_pipe_a;
/* bbird_line(0, 6, 5, 4); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h6);
pci_burst_data(rbase_a+XY1,4'h0,32'h50004);
wait_for_pipe_a;
/* bbird_line(0, 7, 5, 6); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h7);
pci_burst_data(rbase_a+XY1,4'h0,32'h50006);
wait_for_pipe_a;
/* bbird_line(0, 8, 5, 8); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h8);
pci_burst_data(rbase_a+XY1,4'h0,32'h50008);
wait_for_pipe_a;
/* bbird_line(0, 9, 5, 10); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h9);
pci_burst_data(rbase_a+XY1,4'h0,32'h5000a);
wait_for_pipe_a;
/* bbird_line(0, 10, 5, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'ha);
pci_burst_data(rbase_a+XY1,4'h0,32'h5000c);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_rectangle(0x38, 0x0, 0x3d, 0x5); */
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 56, 0, 6, 6, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h60006);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h380000);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0x11, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h11);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_rectangle(0x38, 0x5, 0x3d, 0x9); */
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 56, 5, 6, 5, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h60005);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h380005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_memxfer_setup(0, 0x200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h5bf80, 32'h40, 32'h10, "junk", 32'h4080, 2'h0);
