/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'h280);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0x280, 0x0); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'h280);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x280, 0x0, 0, 0, 63, 15); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h280);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h3f000f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 16, 0);
VR.ram_fill32(32'ha0, 16, 0);
VR.ram_fill32(32'h140, 16, 0);
VR.ram_fill32(32'h1e0, 16, 0);
VR.ram_fill32(32'h280, 16, 0);
VR.ram_fill32(32'h320, 16, 0);
VR.ram_fill32(32'h3c0, 16, 0);
VR.ram_fill32(32'h460, 16, 0);
VR.ram_fill32(32'h500, 16, 0);
VR.ram_fill32(32'h5a0, 16, 0);
VR.ram_fill32(32'h640, 16, 0);
VR.ram_fill32(32'h6e0, 16, 0);
VR.ram_fill32(32'h780, 16, 0);
VR.ram_fill32(32'h820, 16, 0);
VR.ram_fill32(32'h8c0, 16, 0);
VR.ram_fill32(32'h960, 16, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x280, 0x0, 0, 0, 63, 15); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h280);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h3f000f);
/* bbird_memxfer_setup(0, 0x200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x8400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
wait_for_pipe_a;
/* bbird_line_pat(0x16, 0x5); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h16);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h5);
wait_for_pipe_a;
/* bbird_colors(0x1, 0x9, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
pci_burst_data(rbase_a+BACK,4'h0,32'h9);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_rectangle(0x28, 0x8, 0x3b, 0xd); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 40, 8, 20, 6, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h140006);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h280008);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
wait_for_pipe_a;
/* bbird_write_pixel(0x0, 0x2, 0x33333333); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h33333333);
pci_burst_data(rbase_a+XY0,4'h0,32'h2);
pci_burst_data(rbase_a+XY1,4'h0,32'h2);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
wait_for_pipe_a;
/* bbird_write_pixel(0x2, 0x3, 0x33333333); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h33333333);
pci_burst_data(rbase_a+XY0,4'h0,32'h20003);
pci_burst_data(rbase_a+XY1,4'h0,32'h20003);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
pci_burst_data(32'h40000004, 4'h0, 32'h01020300);
wait_for_pipe_a;
/* bbird_write_pixel(0x8, 0x7, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h80007);
pci_burst_data(rbase_a+XY1,4'h0,32'h80007);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x9, 0x8, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h90008);
pci_burst_data(rbase_a+XY1,4'h0,32'h90008);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0xa, 0x9, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'ha0009);
pci_burst_data(rbase_a+XY1,4'h0,32'ha0009);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0xb, 0x5, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'hb0005);
pci_burst_data(rbase_a+XY1,4'h0,32'hb0005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x5, 0x6, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h50006);
pci_burst_data(rbase_a+XY1,4'h0,32'h50006);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x6, 0x7, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h60007);
pci_burst_data(rbase_a+XY1,4'h0,32'h60007);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x7, 0x8, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h70008);
pci_burst_data(rbase_a+XY1,4'h0,32'h70008);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x8, 0x9, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h80009);
pci_burst_data(rbase_a+XY1,4'h0,32'h80009);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x9, 0x5, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h90005);
pci_burst_data(rbase_a+XY1,4'h0,32'h90005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0xa, 0x6, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'ha0006);
pci_burst_data(rbase_a+XY1,4'h0,32'ha0006);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0xb, 0x7, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'hb0007);
pci_burst_data(rbase_a+XY1,4'h0,32'hb0007);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x5, 0x8, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h50008);
pci_burst_data(rbase_a+XY1,4'h0,32'h50008);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x6, 0x9, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h60009);
pci_burst_data(rbase_a+XY1,4'h0,32'h60009);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x7, 0x5, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h70005);
pci_burst_data(rbase_a+XY1,4'h0,32'h70005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x8, 0x6, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h80006);
pci_burst_data(rbase_a+XY1,4'h0,32'h80006);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x9, 0x7, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h90007);
pci_burst_data(rbase_a+XY1,4'h0,32'h90007);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0xc00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'hc00);
/* bbird_area_pattern(0x0, 0x74, 0x2000000); */
wait_for_pipe_a;
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h40000300+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'hc01);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h200001);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800fe0c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h301);
pci_burst_data(32'h10000004, 4'h0, 32'h20301);
pci_burst_data(32'h10000008, 4'h0, 32'h20301);
pci_burst_data(32'h1000000c, 4'h0, 32'h20301);
pci_burst_data(32'h10000010, 4'h0, 32'h20301);
pci_burst_data(32'h10000014, 4'h0, 32'h20301);
pci_burst_data(32'h10000018, 4'h0, 32'h20301);
pci_burst_data(32'h1000001c, 4'h0, 32'h20301);
pci_burst_data(rbase_a+XY1,4'h0,32'h74);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800fe2c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1000203);
pci_burst_data(32'h10000004, 4'h0, 32'h1000203);
pci_burst_data(32'h10000008, 4'h0, 32'h1000203);
pci_burst_data(32'h1000000c, 4'h0, 32'h1000203);
pci_burst_data(32'h10000010, 4'h0, 32'h1000203);
pci_burst_data(32'h10000014, 4'h0, 32'h1000203);
pci_burst_data(32'h10000018, 4'h0, 32'h1000203);
pci_burst_data(32'h1000001c, 4'h0, 32'h1000203);
pci_burst_data(rbase_a+XY1,4'h0,32'h75);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800fe4c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h0);
pci_burst_data(32'h10000004, 4'h0, 32'h0);
pci_burst_data(32'h10000008, 4'h0, 32'h0);
pci_burst_data(32'h1000000c, 4'h0, 32'h0);
pci_burst_data(32'h10000010, 4'h0, 32'h0);
pci_burst_data(32'h10000014, 4'h0, 32'h0);
pci_burst_data(32'h10000018, 4'h0, 32'h0);
pci_burst_data(32'h1000001c, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h76);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800fe6c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1000101);
pci_burst_data(32'h10000004, 4'h0, 32'h1010101);
pci_burst_data(32'h10000008, 4'h0, 32'h1010101);
pci_burst_data(32'h1000000c, 4'h0, 32'h1010101);
pci_burst_data(32'h10000010, 4'h0, 32'h1010101);
pci_burst_data(32'h10000014, 4'h0, 32'h1010101);
pci_burst_data(32'h10000018, 4'h0, 32'h1010101);
pci_burst_data(32'h1000001c, 4'h0, 32'h1010101);
pci_burst_data(rbase_a+XY1,4'h0,32'h77);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800fe8c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3000303);
pci_burst_data(32'h10000004, 4'h0, 32'h3030303);
pci_burst_data(32'h10000008, 4'h0, 32'h3030303);
pci_burst_data(32'h1000000c, 4'h0, 32'h3030303);
pci_burst_data(32'h10000010, 4'h0, 32'h3030303);
pci_burst_data(32'h10000014, 4'h0, 32'h3030303);
pci_burst_data(32'h10000018, 4'h0, 32'h3030303);
pci_burst_data(32'h1000001c, 4'h0, 32'h3030303);
pci_burst_data(rbase_a+XY1,4'h0,32'h78);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800feac, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h2000202);
pci_burst_data(32'h10000004, 4'h0, 32'h2020202);
pci_burst_data(32'h10000008, 4'h0, 32'h2020202);
pci_burst_data(32'h1000000c, 4'h0, 32'h2020202);
pci_burst_data(32'h10000010, 4'h0, 32'h2020202);
pci_burst_data(32'h10000014, 4'h0, 32'h2020202);
pci_burst_data(32'h10000018, 4'h0, 32'h2020202);
pci_burst_data(32'h1000001c, 4'h0, 32'h2020202);
pci_burst_data(rbase_a+XY1,4'h0,32'h79);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800fecc, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3000002);
pci_burst_data(32'h10000004, 4'h0, 32'h3010002);
pci_burst_data(32'h10000008, 4'h0, 32'h3010002);
pci_burst_data(32'h1000000c, 4'h0, 32'h3010002);
pci_burst_data(32'h10000010, 4'h0, 32'h3010002);
pci_burst_data(32'h10000014, 4'h0, 32'h3010002);
pci_burst_data(32'h10000018, 4'h0, 32'h3010002);
pci_burst_data(32'h1000001c, 4'h0, 32'h3010002);
pci_burst_data(rbase_a+XY1,4'h0,32'h7a);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800feec, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h2000100);
pci_burst_data(32'h10000004, 4'h0, 32'h2030100);
pci_burst_data(32'h10000008, 4'h0, 32'h2030100);
pci_burst_data(32'h1000000c, 4'h0, 32'h2030100);
pci_burst_data(32'h10000010, 4'h0, 32'h2030100);
pci_burst_data(32'h10000014, 4'h0, 32'h2030100);
pci_burst_data(32'h10000018, 4'h0, 32'h2030100);
pci_burst_data(32'h1000001c, 4'h0, 32'h2030100);
pci_burst_data(rbase_a+XY1,4'h0,32'h7b);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ff0c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h301);
pci_burst_data(32'h10000004, 4'h0, 32'h20301);
pci_burst_data(32'h10000008, 4'h0, 32'h20301);
pci_burst_data(32'h1000000c, 4'h0, 32'h20301);
pci_burst_data(32'h10000010, 4'h0, 32'h20301);
pci_burst_data(32'h10000014, 4'h0, 32'h20301);
pci_burst_data(32'h10000018, 4'h0, 32'h20301);
pci_burst_data(32'h1000001c, 4'h0, 32'h20301);
pci_burst_data(rbase_a+XY1,4'h0,32'h7c);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ff2c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1000203);
pci_burst_data(32'h10000004, 4'h0, 32'h1000203);
pci_burst_data(32'h10000008, 4'h0, 32'h1000203);
pci_burst_data(32'h1000000c, 4'h0, 32'h1000203);
pci_burst_data(32'h10000010, 4'h0, 32'h1000203);
pci_burst_data(32'h10000014, 4'h0, 32'h1000203);
pci_burst_data(32'h10000018, 4'h0, 32'h1000203);
pci_burst_data(32'h1000001c, 4'h0, 32'h1000203);
pci_burst_data(rbase_a+XY1,4'h0,32'h7d);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ff4c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3000002);
pci_burst_data(32'h10000004, 4'h0, 32'h3010002);
pci_burst_data(32'h10000008, 4'h0, 32'h3010002);
pci_burst_data(32'h1000000c, 4'h0, 32'h3010002);
pci_burst_data(32'h10000010, 4'h0, 32'h3010002);
pci_burst_data(32'h10000014, 4'h0, 32'h3010002);
pci_burst_data(32'h10000018, 4'h0, 32'h3010002);
pci_burst_data(32'h1000001c, 4'h0, 32'h3010002);
pci_burst_data(rbase_a+XY1,4'h0,32'h7e);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ff6c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h2000100);
pci_burst_data(32'h10000004, 4'h0, 32'h2030100);
pci_burst_data(32'h10000008, 4'h0, 32'h2030100);
pci_burst_data(32'h1000000c, 4'h0, 32'h2030100);
pci_burst_data(32'h10000010, 4'h0, 32'h2030100);
pci_burst_data(32'h10000014, 4'h0, 32'h2030100);
pci_burst_data(32'h10000018, 4'h0, 32'h2030100);
pci_burst_data(32'h1000001c, 4'h0, 32'h2030100);
pci_burst_data(rbase_a+XY1,4'h0,32'h7f);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ff8c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h301);
pci_burst_data(32'h10000004, 4'h0, 32'h20301);
pci_burst_data(32'h10000008, 4'h0, 32'h20301);
pci_burst_data(32'h1000000c, 4'h0, 32'h20301);
pci_burst_data(32'h10000010, 4'h0, 32'h20301);
pci_burst_data(32'h10000014, 4'h0, 32'h20301);
pci_burst_data(32'h10000018, 4'h0, 32'h20301);
pci_burst_data(32'h1000001c, 4'h0, 32'h20301);
pci_burst_data(rbase_a+XY1,4'h0,32'h80);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ffac, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1000203);
pci_burst_data(32'h10000004, 4'h0, 32'h1000203);
pci_burst_data(32'h10000008, 4'h0, 32'h1000203);
pci_burst_data(32'h1000000c, 4'h0, 32'h1000203);
pci_burst_data(32'h10000010, 4'h0, 32'h1000203);
pci_burst_data(32'h10000014, 4'h0, 32'h1000203);
pci_burst_data(32'h10000018, 4'h0, 32'h1000203);
pci_burst_data(32'h1000001c, 4'h0, 32'h1000203);
pci_burst_data(rbase_a+XY1,4'h0,32'h81);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ffcc, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3000002);
pci_burst_data(32'h10000004, 4'h0, 32'h3010002);
pci_burst_data(32'h10000008, 4'h0, 32'h3010002);
pci_burst_data(32'h1000000c, 4'h0, 32'h3010002);
pci_burst_data(32'h10000010, 4'h0, 32'h3010002);
pci_burst_data(32'h10000014, 4'h0, 32'h3010002);
pci_burst_data(32'h10000018, 4'h0, 32'h3010002);
pci_burst_data(32'h1000001c, 4'h0, 32'h3010002);
pci_burst_data(rbase_a+XY1,4'h0,32'h82);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ffec, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h2000100);
pci_burst_data(32'h10000004, 4'h0, 32'h2030100);
pci_burst_data(32'h10000008, 4'h0, 32'h2030100);
pci_burst_data(32'h1000000c, 4'h0, 32'h2030100);
pci_burst_data(32'h10000010, 4'h0, 32'h2030100);
pci_burst_data(32'h10000014, 4'h0, 32'h2030100);
pci_burst_data(32'h10000018, 4'h0, 32'h2030100);
pci_burst_data(32'h1000001c, 4'h0, 32'h2030100);
pci_burst_data(rbase_a+XY1,4'h0,32'h83);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801000c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h301);
pci_burst_data(32'h10000004, 4'h0, 32'h20301);
pci_burst_data(32'h10000008, 4'h0, 32'h20301);
pci_burst_data(32'h1000000c, 4'h0, 32'h20301);
pci_burst_data(32'h10000010, 4'h0, 32'h20301);
pci_burst_data(32'h10000014, 4'h0, 32'h20301);
pci_burst_data(32'h10000018, 4'h0, 32'h20301);
pci_burst_data(32'h1000001c, 4'h0, 32'h20301);
pci_burst_data(rbase_a+XY1,4'h0,32'h84);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801002c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1000203);
pci_burst_data(32'h10000004, 4'h0, 32'h1000203);
pci_burst_data(32'h10000008, 4'h0, 32'h1000203);
pci_burst_data(32'h1000000c, 4'h0, 32'h1000203);
pci_burst_data(32'h10000010, 4'h0, 32'h1000203);
pci_burst_data(32'h10000014, 4'h0, 32'h1000203);
pci_burst_data(32'h10000018, 4'h0, 32'h1000203);
pci_burst_data(32'h1000001c, 4'h0, 32'h1000203);
pci_burst_data(rbase_a+XY1,4'h0,32'h85);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801004c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3000002);
pci_burst_data(32'h10000004, 4'h0, 32'h3010002);
pci_burst_data(32'h10000008, 4'h0, 32'h3010002);
pci_burst_data(32'h1000000c, 4'h0, 32'h3010002);
pci_burst_data(32'h10000010, 4'h0, 32'h3010002);
pci_burst_data(32'h10000014, 4'h0, 32'h3010002);
pci_burst_data(32'h10000018, 4'h0, 32'h3010002);
pci_burst_data(32'h1000001c, 4'h0, 32'h3010002);
pci_burst_data(rbase_a+XY1,4'h0,32'h86);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801006c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h2000100);
pci_burst_data(32'h10000004, 4'h0, 32'h2030100);
pci_burst_data(32'h10000008, 4'h0, 32'h2030100);
pci_burst_data(32'h1000000c, 4'h0, 32'h2030100);
pci_burst_data(32'h10000010, 4'h0, 32'h2030100);
pci_burst_data(32'h10000014, 4'h0, 32'h2030100);
pci_burst_data(32'h10000018, 4'h0, 32'h2030100);
pci_burst_data(32'h1000001c, 4'h0, 32'h2030100);
pci_burst_data(rbase_a+XY1,4'h0,32'h87);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801008c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h301);
pci_burst_data(32'h10000004, 4'h0, 32'h20301);
pci_burst_data(32'h10000008, 4'h0, 32'h20301);
pci_burst_data(32'h1000000c, 4'h0, 32'h20301);
pci_burst_data(32'h10000010, 4'h0, 32'h20301);
pci_burst_data(32'h10000014, 4'h0, 32'h20301);
pci_burst_data(32'h10000018, 4'h0, 32'h20301);
pci_burst_data(32'h1000001c, 4'h0, 32'h20301);
pci_burst_data(rbase_a+XY1,4'h0,32'h88);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80100ac, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1000203);
pci_burst_data(32'h10000004, 4'h0, 32'h1000203);
pci_burst_data(32'h10000008, 4'h0, 32'h1000203);
pci_burst_data(32'h1000000c, 4'h0, 32'h1000203);
pci_burst_data(32'h10000010, 4'h0, 32'h1000203);
pci_burst_data(32'h10000014, 4'h0, 32'h1000203);
pci_burst_data(32'h10000018, 4'h0, 32'h1000203);
pci_burst_data(32'h1000001c, 4'h0, 32'h1000203);
pci_burst_data(rbase_a+XY1,4'h0,32'h89);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80100cc, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3000002);
pci_burst_data(32'h10000004, 4'h0, 32'h3010002);
pci_burst_data(32'h10000008, 4'h0, 32'h3010002);
pci_burst_data(32'h1000000c, 4'h0, 32'h3010002);
pci_burst_data(32'h10000010, 4'h0, 32'h3010002);
pci_burst_data(32'h10000014, 4'h0, 32'h3010002);
pci_burst_data(32'h10000018, 4'h0, 32'h3010002);
pci_burst_data(32'h1000001c, 4'h0, 32'h3010002);
pci_burst_data(rbase_a+XY1,4'h0,32'h8a);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80100ec, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h2000100);
pci_burst_data(32'h10000004, 4'h0, 32'h2030100);
pci_burst_data(32'h10000008, 4'h0, 32'h2030100);
pci_burst_data(32'h1000000c, 4'h0, 32'h2030100);
pci_burst_data(32'h10000010, 4'h0, 32'h2030100);
pci_burst_data(32'h10000014, 4'h0, 32'h2030100);
pci_burst_data(32'h10000018, 4'h0, 32'h2030100);
pci_burst_data(32'h1000001c, 4'h0, 32'h2030100);
pci_burst_data(rbase_a+XY1,4'h0,32'h8b);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801010c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h301);
pci_burst_data(32'h10000004, 4'h0, 32'h20301);
pci_burst_data(32'h10000008, 4'h0, 32'h20301);
pci_burst_data(32'h1000000c, 4'h0, 32'h20301);
pci_burst_data(32'h10000010, 4'h0, 32'h20301);
pci_burst_data(32'h10000014, 4'h0, 32'h20301);
pci_burst_data(32'h10000018, 4'h0, 32'h20301);
pci_burst_data(32'h1000001c, 4'h0, 32'h20301);
pci_burst_data(rbase_a+XY1,4'h0,32'h8c);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801012c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1000203);
pci_burst_data(32'h10000004, 4'h0, 32'h1000203);
pci_burst_data(32'h10000008, 4'h0, 32'h1000203);
pci_burst_data(32'h1000000c, 4'h0, 32'h1000203);
pci_burst_data(32'h10000010, 4'h0, 32'h1000203);
pci_burst_data(32'h10000014, 4'h0, 32'h1000203);
pci_burst_data(32'h10000018, 4'h0, 32'h1000203);
pci_burst_data(32'h1000001c, 4'h0, 32'h1000203);
pci_burst_data(rbase_a+XY1,4'h0,32'h8d);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801014c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3000002);
pci_burst_data(32'h10000004, 4'h0, 32'h3010002);
pci_burst_data(32'h10000008, 4'h0, 32'h3010002);
pci_burst_data(32'h1000000c, 4'h0, 32'h3010002);
pci_burst_data(32'h10000010, 4'h0, 32'h3010002);
pci_burst_data(32'h10000014, 4'h0, 32'h3010002);
pci_burst_data(32'h10000018, 4'h0, 32'h3010002);
pci_burst_data(32'h1000001c, 4'h0, 32'h3010002);
pci_burst_data(rbase_a+XY1,4'h0,32'h8e);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801016c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h2000100);
pci_burst_data(32'h10000004, 4'h0, 32'h2030100);
pci_burst_data(32'h10000008, 4'h0, 32'h2030100);
pci_burst_data(32'h1000000c, 4'h0, 32'h2030100);
pci_burst_data(32'h10000010, 4'h0, 32'h2030100);
pci_burst_data(32'h10000014, 4'h0, 32'h2030100);
pci_burst_data(32'h10000018, 4'h0, 32'h2030100);
pci_burst_data(32'h1000001c, 4'h0, 32'h2030100);
pci_burst_data(rbase_a+XY1,4'h0,32'h8f);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801018c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h301);
pci_burst_data(32'h10000004, 4'h0, 32'h20301);
pci_burst_data(32'h10000008, 4'h0, 32'h20301);
pci_burst_data(32'h1000000c, 4'h0, 32'h20301);
pci_burst_data(32'h10000010, 4'h0, 32'h20301);
pci_burst_data(32'h10000014, 4'h0, 32'h20301);
pci_burst_data(32'h10000018, 4'h0, 32'h20301);
pci_burst_data(32'h1000001c, 4'h0, 32'h20301);
pci_burst_data(rbase_a+XY1,4'h0,32'h90);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80101ac, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1000203);
pci_burst_data(32'h10000004, 4'h0, 32'h1000203);
pci_burst_data(32'h10000008, 4'h0, 32'h1000203);
pci_burst_data(32'h1000000c, 4'h0, 32'h1000203);
pci_burst_data(32'h10000010, 4'h0, 32'h1000203);
pci_burst_data(32'h10000014, 4'h0, 32'h1000203);
pci_burst_data(32'h10000018, 4'h0, 32'h1000203);
pci_burst_data(32'h1000001c, 4'h0, 32'h1000203);
pci_burst_data(rbase_a+XY1,4'h0,32'h91);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80101cc, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3000002);
pci_burst_data(32'h10000004, 4'h0, 32'h3010002);
pci_burst_data(32'h10000008, 4'h0, 32'h3010002);
pci_burst_data(32'h1000000c, 4'h0, 32'h3010002);
pci_burst_data(32'h10000010, 4'h0, 32'h3010002);
pci_burst_data(32'h10000014, 4'h0, 32'h3010002);
pci_burst_data(32'h10000018, 4'h0, 32'h3010002);
pci_burst_data(32'h1000001c, 4'h0, 32'h3010002);
pci_burst_data(rbase_a+XY1,4'h0,32'h92);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80101ec, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h2000100);
pci_burst_data(32'h10000004, 4'h0, 32'h2030100);
pci_burst_data(32'h10000008, 4'h0, 32'h2030100);
pci_burst_data(32'h1000000c, 4'h0, 32'h2030100);
pci_burst_data(32'h10000010, 4'h0, 32'h2030100);
pci_burst_data(32'h10000014, 4'h0, 32'h2030100);
pci_burst_data(32'h10000018, 4'h0, 32'h2030100);
pci_burst_data(32'h1000001c, 4'h0, 32'h2030100);
pci_burst_data(rbase_a+XY1,4'h0,32'h93);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x2420c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h2420c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 116, 0, 0, 63, 13, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h3f000d);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h74);
pci_burst_data(rbase_a+XY1,4'h0,32'h0);
rd(MEM_RD, 32'h40000000, 1);
wait_for_pipe_a;
/* bbird_write_pixel(0x2, 0x5, 0xcc); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'hcc);
pci_burst_data(rbase_a+XY0,4'h0,32'h20005);
pci_burst_data(rbase_a+XY1,4'h0,32'h20005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h2420c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h40, 32'h10, "junk", 32'h280, 2'h0);
