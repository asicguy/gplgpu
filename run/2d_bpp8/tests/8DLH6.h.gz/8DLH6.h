/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'h280);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0x280, 0x0); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'h280);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x280, 0x0, 0, 0, 95, 31); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h280);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h5f001f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 24, 0);
VR.ram_fill32(32'ha0, 24, 0);
VR.ram_fill32(32'h140, 24, 0);
VR.ram_fill32(32'h1e0, 24, 0);
VR.ram_fill32(32'h280, 24, 0);
VR.ram_fill32(32'h320, 24, 0);
VR.ram_fill32(32'h3c0, 24, 0);
VR.ram_fill32(32'h460, 24, 0);
VR.ram_fill32(32'h500, 24, 0);
VR.ram_fill32(32'h5a0, 24, 0);
VR.ram_fill32(32'h640, 24, 0);
VR.ram_fill32(32'h6e0, 24, 0);
VR.ram_fill32(32'h780, 24, 0);
VR.ram_fill32(32'h820, 24, 0);
VR.ram_fill32(32'h8c0, 24, 0);
VR.ram_fill32(32'h960, 24, 0);
VR.ram_fill32(32'ha00, 24, 0);
VR.ram_fill32(32'haa0, 24, 0);
VR.ram_fill32(32'hb40, 24, 0);
VR.ram_fill32(32'hbe0, 24, 0);
VR.ram_fill32(32'hc80, 24, 0);
VR.ram_fill32(32'hd20, 24, 0);
VR.ram_fill32(32'hdc0, 24, 0);
VR.ram_fill32(32'he60, 24, 0);
VR.ram_fill32(32'hf00, 24, 0);
VR.ram_fill32(32'hfa0, 24, 0);
VR.ram_fill32(32'h1040, 24, 0);
VR.ram_fill32(32'h10e0, 24, 0);
VR.ram_fill32(32'h1180, 24, 0);
VR.ram_fill32(32'h1220, 24, 0);
VR.ram_fill32(32'h12c0, 24, 0);
VR.ram_fill32(32'h1360, 24, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x280, 0x0, 0, 0, 95, 31); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h280);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h5f001f);
/* bbird_memxfer_setup(0, 0x200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
/* bbird_memxfer_setup(1, 0x0, 0x0, 0x0, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW1_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_CTRL,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_WKEY,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_KYDAT,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_line_pat(0x16, 0x5); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h16);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h5);
wait_for_pipe_a;
/* bbird_colors(0x1, 0x9, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
pci_burst_data(rbase_a+BACK,4'h0,32'h9);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_rectangle(0x28, 0x8, 0x3b, 0xd); */
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 40, 8, 20, 6, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h140006);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h280008);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_write_pixel(0x0, 0x2, 0x33333333); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h33333333);
pci_burst_data(rbase_a+XY0,4'h0,32'h2);
pci_burst_data(rbase_a+XY1,4'h0,32'h2);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
wait_for_pipe_a;
/* bbird_write_pixel(0x2, 0x3, 0x33333333); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h33333333);
pci_burst_data(rbase_a+XY0,4'h0,32'h20003);
pci_burst_data(rbase_a+XY1,4'h0,32'h20003);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
wait_for_pipe_a;
/* bbird_colors(0x13, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h13);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
pci_burst_data(32'h40000004, 4'h0, 32'h01020300);
/* bbird_font_write("Hello world!"); { 0x5, 0x2 } */
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 5, 2, 67, 15, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h43000f);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h50002);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h13);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'h4c0c01);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+32'hF8,4'h0,32'h0);
/* Writing character 'H' */
/* bbird_font_cache(0, 32, 'H', 0x1); */
/* caching character 'H' */
pci_burst_data(32'ha0005000, 4'h0, 32'he3e30000);
pci_burst_data(32'ha0005004, 4'h0, 32'he3ffe3e3);
pci_burst_data(32'ha0005008, 4'h0, 32'he3e3e3e3);
pci_burst_data(32'ha000500c, 4'h0, 32'h0);
pci_burst_data(32'ha0005010, 4'h0, 32'h40005000);
pci_burst_data(32'ha0005014, 4'h0, 32'h70f);
/* Writing character 'e' */
/* bbird_font_cache(32, 32, 'e', 0x1); */
/* caching character 'e' */
pci_burst_data(32'ha0005020, 4'h0, 32'hc0800000);
pci_burst_data(32'ha0005024, 4'h0, 32'hf3f3dec0);
pci_burst_data(32'ha0005028, 4'h0, 32'hfec3c3ff);
pci_burst_data(32'ha000502c, 4'h0, 32'h0);
pci_burst_data(32'ha0005030, 4'h0, 32'h40005020);
pci_burst_data(32'ha0005034, 4'h0, 32'h60f);
pci_burst_data(32'ha0000000, 4'h0, 32'ha005010);
pci_burst_data(32'ha0000004, 4'h0, 32'h50002);
pci_burst_data(32'ha0000008, 4'h0, 32'h5030);
pci_burst_data(32'ha000000c, 4'h0, 32'hd0002);
/* Writing character 'l' */
/* bbird_font_cache(64, 32, 'l', 0x1); */
/* caching character 'l' */
pci_burst_data(32'ha0005040, 4'h0, 32'h3030000);
pci_burst_data(32'ha0005044, 4'h0, 32'h6f6fbf03);
pci_burst_data(32'ha0005048, 4'h0, 32'h6f6f6f6f);
pci_burst_data(32'ha000504c, 4'h0, 32'h0);
pci_burst_data(32'ha0005050, 4'h0, 32'h40005040);
pci_burst_data(32'ha0005054, 4'h0, 32'h20f);
/* Writing character 'l' */
pci_burst_data(32'ha0000010, 4'h0, 32'ha005050);
pci_burst_data(32'ha0000014, 4'h0, 32'h140002);
pci_burst_data(32'ha0000018, 4'h0, 32'h5050);
pci_burst_data(32'ha000001c, 4'h0, 32'h170002);
/* Writing character 'o' */
/* bbird_font_cache(96, 32, 'o', 0x1); */
/* caching character 'o' */
pci_burst_data(32'ha0005060, 4'h0, 32'h0);
pci_burst_data(32'ha0005064, 4'h0, 32'hf3f3de00);
pci_burst_data(32'ha0005068, 4'h0, 32'hdef3f3f3);
pci_burst_data(32'ha000506c, 4'h0, 32'hc0c0c0);
pci_burst_data(32'ha0005070, 4'h0, 32'h40005060);
pci_burst_data(32'ha0005074, 4'h0, 32'h60f);
/* Writing character ' ' */
/* bbird_font_cache(32, 33, ' ', 0x1); */
/* caching character ' ' */
/* Writing character 'w' */
/* bbird_font_cache(32, 33, 'w', 0x1); */
/* caching character 'w' */
pci_burst_data(32'ha00052a0, 4'h0, 32'h0);
pci_burst_data(32'ha00052a4, 4'h0, 32'h63e3e300);
pci_burst_data(32'ha00052a8, 4'h0, 32'hf7ff6b63);
pci_burst_data(32'ha00052ac, 4'h0, 32'h0);
pci_burst_data(32'ha00052b0, 4'h0, 32'h400052a0);
pci_burst_data(32'ha00052b4, 4'h0, 32'h70f);
pci_burst_data(32'ha0000020, 4'h0, 32'ha005070);
pci_burst_data(32'ha0000024, 4'h0, 32'h1a0002);
pci_burst_data(32'ha0000028, 4'h0, 32'h52b0);
pci_burst_data(32'ha000002c, 4'h0, 32'h250002);
/* Writing character 'o' */
/* Writing character 'r' */
/* bbird_font_cache(64, 33, 'r', 0x1); */
/* caching character 'r' */
pci_burst_data(32'ha00052c0, 4'h0, 32'h0);
pci_burst_data(32'ha00052c4, 4'h0, 32'he37bcf00);
pci_burst_data(32'ha00052c8, 4'h0, 32'he30383c3);
pci_burst_data(32'ha00052cc, 4'h0, 32'h0);
pci_burst_data(32'ha00052d0, 4'h0, 32'h400052c0);
pci_burst_data(32'ha00052d4, 4'h0, 32'h50f);
pci_burst_data(32'ha0000030, 4'h0, 32'ha005070);
pci_burst_data(32'ha0000034, 4'h0, 32'h2d0002);
pci_burst_data(32'ha0000038, 4'h0, 32'h52d0);
pci_burst_data(32'ha000003c, 4'h0, 32'h340002);
/* Writing character 'l' */
/* Writing character 'd' */
/* bbird_font_cache(96, 33, 'd', 0x1); */
/* caching character 'd' */
pci_burst_data(32'ha00052e0, 4'h0, 32'h30300000);
pci_burst_data(32'ha00052e4, 4'h0, 32'hf3f3be30);
pci_burst_data(32'ha00052e8, 4'h0, 32'hbef3f3f3);
pci_burst_data(32'ha00052ec, 4'h0, 32'h0);
pci_burst_data(32'ha00052f0, 4'h0, 32'h400052e0);
pci_burst_data(32'ha00052f4, 4'h0, 32'h60f);
pci_burst_data(32'ha0000040, 4'h0, 32'ha005050);
pci_burst_data(32'ha0000044, 4'h0, 32'h3a0002);
pci_burst_data(32'ha0000048, 4'h0, 32'h52f0);
pci_burst_data(32'ha000004c, 4'h0, 32'h3d0002);
/* Writing character '!' */
/* bbird_font_cache(32, 34, '!', 0x1); */
/* caching character '!' */
pci_burst_data(32'ha0005520, 4'h0, 32'h4b6f0300);
pci_burst_data(32'ha0005524, 4'h0, 32'h38303a7);
pci_burst_data(32'ha0005528, 4'h0, 32'h3030000);
pci_burst_data(32'ha000552c, 4'h0, 32'h0);
pci_burst_data(32'ha0005530, 4'h0, 32'h40005520);
pci_burst_data(32'ha0005534, 4'h0, 32'h20f);
pci_burst_data(32'ha0000050, 4'h0, 32'h2005530);
pci_burst_data(32'ha0000054, 4'h0, 32'h450002);
pci_burst_data(rbase_a+32'hFC,4'h0,32'h60);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
rd(MEM_RD, 32'h40000000, 1);
wait_for_pipe_a;
/* bbird_write_pixel(0x2, 0x5, 0xcc); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'hcc);
pci_burst_data(rbase_a+XY0,4'h0,32'h20005);
pci_burst_data(rbase_a+XY1,4'h0,32'h20005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h60, 32'h20, "junk", 32'h280, 2'h0);
