/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'h180);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0x180, 0x0); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'h180);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x180, 0x0, 0, 0, 63, 15); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h180);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h3f000f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 16, 0);
VR.ram_fill32(32'h60, 16, 0);
VR.ram_fill32(32'hc0, 16, 0);
VR.ram_fill32(32'h120, 16, 0);
VR.ram_fill32(32'h180, 16, 0);
VR.ram_fill32(32'h1e0, 16, 0);
VR.ram_fill32(32'h240, 16, 0);
VR.ram_fill32(32'h2a0, 16, 0);
VR.ram_fill32(32'h300, 16, 0);
VR.ram_fill32(32'h360, 16, 0);
VR.ram_fill32(32'h3c0, 16, 0);
VR.ram_fill32(32'h420, 16, 0);
VR.ram_fill32(32'h480, 16, 0);
VR.ram_fill32(32'h4e0, 16, 0);
VR.ram_fill32(32'h540, 16, 0);
VR.ram_fill32(32'h5a0, 16, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x180, 0x0, 0, 0, 63, 15); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h180);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h3f000f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x8400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
wait_for_pipe_a;
/* bbird_line_pat(0x93939393, 0x10); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h93939393);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h10);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line(1, 2, 1, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h10002);
pci_burst_data(rbase_a+XY1,4'h0,32'h1000c);
wait_for_pipe_a;
/* bbird_line(2, 1, 2, 11); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h20001);
pci_burst_data(rbase_a+XY1,4'h0,32'h2000b);
wait_for_pipe_a;
/* bbird_line(3, 0, 3, 10); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h30000);
pci_burst_data(rbase_a+XY1,4'h0,32'h3000a);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_rectangle(0x38, 0x0, 0x3a, 0x3); */
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 56, 0, 3, 4, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h30004);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h380000);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0x11, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h11);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_rectangle(0x38, 0x4, 0x3a, 0x7); */
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 56, 4, 3, 4, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h30004);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h380004);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0xc00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'hc00);
/* bbird_area_pattern(0x10, 0xe, 0x2000000); */
wait_for_pipe_a;
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h40000300+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'hc01);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h200001);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80100bc, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h301);
pci_burst_data(32'h10000004, 4'h0, 32'h20301);
pci_burst_data(32'h10000008, 4'h0, 32'h20301);
pci_burst_data(32'h1000000c, 4'h0, 32'h20301);
pci_burst_data(32'h10000010, 4'h0, 32'h20301);
pci_burst_data(32'h10000014, 4'h0, 32'h20301);
pci_burst_data(32'h10000018, 4'h0, 32'h20301);
pci_burst_data(32'h1000001c, 4'h0, 32'h20301);
pci_burst_data(rbase_a+XY1,4'h0,32'h10000e);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80100dc, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1000203);
pci_burst_data(32'h10000004, 4'h0, 32'h1000203);
pci_burst_data(32'h10000008, 4'h0, 32'h1000203);
pci_burst_data(32'h1000000c, 4'h0, 32'h1000203);
pci_burst_data(32'h10000010, 4'h0, 32'h1000203);
pci_burst_data(32'h10000014, 4'h0, 32'h1000203);
pci_burst_data(32'h10000018, 4'h0, 32'h1000203);
pci_burst_data(32'h1000001c, 4'h0, 32'h1000203);
pci_burst_data(rbase_a+XY1,4'h0,32'h10000f);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80100fc, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h0);
pci_burst_data(32'h10000004, 4'h0, 32'h0);
pci_burst_data(32'h10000008, 4'h0, 32'h0);
pci_burst_data(32'h1000000c, 4'h0, 32'h0);
pci_burst_data(32'h10000010, 4'h0, 32'h0);
pci_burst_data(32'h10000014, 4'h0, 32'h0);
pci_burst_data(32'h10000018, 4'h0, 32'h0);
pci_burst_data(32'h1000001c, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h100010);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801011c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1000101);
pci_burst_data(32'h10000004, 4'h0, 32'h1010101);
pci_burst_data(32'h10000008, 4'h0, 32'h1010101);
pci_burst_data(32'h1000000c, 4'h0, 32'h1010101);
pci_burst_data(32'h10000010, 4'h0, 32'h1010101);
pci_burst_data(32'h10000014, 4'h0, 32'h1010101);
pci_burst_data(32'h10000018, 4'h0, 32'h1010101);
pci_burst_data(32'h1000001c, 4'h0, 32'h1010101);
pci_burst_data(rbase_a+XY1,4'h0,32'h100011);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801013c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3000303);
pci_burst_data(32'h10000004, 4'h0, 32'h3030303);
pci_burst_data(32'h10000008, 4'h0, 32'h3030303);
pci_burst_data(32'h1000000c, 4'h0, 32'h3030303);
pci_burst_data(32'h10000010, 4'h0, 32'h3030303);
pci_burst_data(32'h10000014, 4'h0, 32'h3030303);
pci_burst_data(32'h10000018, 4'h0, 32'h3030303);
pci_burst_data(32'h1000001c, 4'h0, 32'h3030303);
pci_burst_data(rbase_a+XY1,4'h0,32'h100012);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801015c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h2000202);
pci_burst_data(32'h10000004, 4'h0, 32'h2020202);
pci_burst_data(32'h10000008, 4'h0, 32'h2020202);
pci_burst_data(32'h1000000c, 4'h0, 32'h2020202);
pci_burst_data(32'h10000010, 4'h0, 32'h2020202);
pci_burst_data(32'h10000014, 4'h0, 32'h2020202);
pci_burst_data(32'h10000018, 4'h0, 32'h2020202);
pci_burst_data(32'h1000001c, 4'h0, 32'h2020202);
pci_burst_data(rbase_a+XY1,4'h0,32'h100013);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801017c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3000002);
pci_burst_data(32'h10000004, 4'h0, 32'h3010002);
pci_burst_data(32'h10000008, 4'h0, 32'h3010002);
pci_burst_data(32'h1000000c, 4'h0, 32'h3010002);
pci_burst_data(32'h10000010, 4'h0, 32'h3010002);
pci_burst_data(32'h10000014, 4'h0, 32'h3010002);
pci_burst_data(32'h10000018, 4'h0, 32'h3010002);
pci_burst_data(32'h1000001c, 4'h0, 32'h3010002);
pci_burst_data(rbase_a+XY1,4'h0,32'h100014);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801019c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h2000100);
pci_burst_data(32'h10000004, 4'h0, 32'h2030100);
pci_burst_data(32'h10000008, 4'h0, 32'h2030100);
pci_burst_data(32'h1000000c, 4'h0, 32'h2030100);
pci_burst_data(32'h10000010, 4'h0, 32'h2030100);
pci_burst_data(32'h10000014, 4'h0, 32'h2030100);
pci_burst_data(32'h10000018, 4'h0, 32'h2030100);
pci_burst_data(32'h1000001c, 4'h0, 32'h2030100);
pci_burst_data(rbase_a+XY1,4'h0,32'h100015);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80101bc, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h301);
pci_burst_data(32'h10000004, 4'h0, 32'h20301);
pci_burst_data(32'h10000008, 4'h0, 32'h20301);
pci_burst_data(32'h1000000c, 4'h0, 32'h20301);
pci_burst_data(32'h10000010, 4'h0, 32'h20301);
pci_burst_data(32'h10000014, 4'h0, 32'h20301);
pci_burst_data(32'h10000018, 4'h0, 32'h20301);
pci_burst_data(32'h1000001c, 4'h0, 32'h20301);
pci_burst_data(rbase_a+XY1,4'h0,32'h100016);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80101dc, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1000203);
pci_burst_data(32'h10000004, 4'h0, 32'h1000203);
pci_burst_data(32'h10000008, 4'h0, 32'h1000203);
pci_burst_data(32'h1000000c, 4'h0, 32'h1000203);
pci_burst_data(32'h10000010, 4'h0, 32'h1000203);
pci_burst_data(32'h10000014, 4'h0, 32'h1000203);
pci_burst_data(32'h10000018, 4'h0, 32'h1000203);
pci_burst_data(32'h1000001c, 4'h0, 32'h1000203);
pci_burst_data(rbase_a+XY1,4'h0,32'h100017);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80101fc, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3000002);
pci_burst_data(32'h10000004, 4'h0, 32'h3010002);
pci_burst_data(32'h10000008, 4'h0, 32'h3010002);
pci_burst_data(32'h1000000c, 4'h0, 32'h3010002);
pci_burst_data(32'h10000010, 4'h0, 32'h3010002);
pci_burst_data(32'h10000014, 4'h0, 32'h3010002);
pci_burst_data(32'h10000018, 4'h0, 32'h3010002);
pci_burst_data(32'h1000001c, 4'h0, 32'h3010002);
pci_burst_data(rbase_a+XY1,4'h0,32'h100018);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801021c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h2000100);
pci_burst_data(32'h10000004, 4'h0, 32'h2030100);
pci_burst_data(32'h10000008, 4'h0, 32'h2030100);
pci_burst_data(32'h1000000c, 4'h0, 32'h2030100);
pci_burst_data(32'h10000010, 4'h0, 32'h2030100);
pci_burst_data(32'h10000014, 4'h0, 32'h2030100);
pci_burst_data(32'h10000018, 4'h0, 32'h2030100);
pci_burst_data(32'h1000001c, 4'h0, 32'h2030100);
pci_burst_data(rbase_a+XY1,4'h0,32'h100019);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801023c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h301);
pci_burst_data(32'h10000004, 4'h0, 32'h20301);
pci_burst_data(32'h10000008, 4'h0, 32'h20301);
pci_burst_data(32'h1000000c, 4'h0, 32'h20301);
pci_burst_data(32'h10000010, 4'h0, 32'h20301);
pci_burst_data(32'h10000014, 4'h0, 32'h20301);
pci_burst_data(32'h10000018, 4'h0, 32'h20301);
pci_burst_data(32'h1000001c, 4'h0, 32'h20301);
pci_burst_data(rbase_a+XY1,4'h0,32'h10001a);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801025c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1000203);
pci_burst_data(32'h10000004, 4'h0, 32'h1000203);
pci_burst_data(32'h10000008, 4'h0, 32'h1000203);
pci_burst_data(32'h1000000c, 4'h0, 32'h1000203);
pci_burst_data(32'h10000010, 4'h0, 32'h1000203);
pci_burst_data(32'h10000014, 4'h0, 32'h1000203);
pci_burst_data(32'h10000018, 4'h0, 32'h1000203);
pci_burst_data(32'h1000001c, 4'h0, 32'h1000203);
pci_burst_data(rbase_a+XY1,4'h0,32'h10001b);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801027c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3000002);
pci_burst_data(32'h10000004, 4'h0, 32'h3010002);
pci_burst_data(32'h10000008, 4'h0, 32'h3010002);
pci_burst_data(32'h1000000c, 4'h0, 32'h3010002);
pci_burst_data(32'h10000010, 4'h0, 32'h3010002);
pci_burst_data(32'h10000014, 4'h0, 32'h3010002);
pci_burst_data(32'h10000018, 4'h0, 32'h3010002);
pci_burst_data(32'h1000001c, 4'h0, 32'h3010002);
pci_burst_data(rbase_a+XY1,4'h0,32'h10001c);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801029c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h2000100);
pci_burst_data(32'h10000004, 4'h0, 32'h2030100);
pci_burst_data(32'h10000008, 4'h0, 32'h2030100);
pci_burst_data(32'h1000000c, 4'h0, 32'h2030100);
pci_burst_data(32'h10000010, 4'h0, 32'h2030100);
pci_burst_data(32'h10000014, 4'h0, 32'h2030100);
pci_burst_data(32'h10000018, 4'h0, 32'h2030100);
pci_burst_data(32'h1000001c, 4'h0, 32'h2030100);
pci_burst_data(rbase_a+XY1,4'h0,32'h10001d);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80102bc, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h301);
pci_burst_data(32'h10000004, 4'h0, 32'h20301);
pci_burst_data(32'h10000008, 4'h0, 32'h20301);
pci_burst_data(32'h1000000c, 4'h0, 32'h20301);
pci_burst_data(32'h10000010, 4'h0, 32'h20301);
pci_burst_data(32'h10000014, 4'h0, 32'h20301);
pci_burst_data(32'h10000018, 4'h0, 32'h20301);
pci_burst_data(32'h1000001c, 4'h0, 32'h20301);
pci_burst_data(rbase_a+XY1,4'h0,32'h10001e);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80102dc, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1000203);
pci_burst_data(32'h10000004, 4'h0, 32'h1000203);
pci_burst_data(32'h10000008, 4'h0, 32'h1000203);
pci_burst_data(32'h1000000c, 4'h0, 32'h1000203);
pci_burst_data(32'h10000010, 4'h0, 32'h1000203);
pci_burst_data(32'h10000014, 4'h0, 32'h1000203);
pci_burst_data(32'h10000018, 4'h0, 32'h1000203);
pci_burst_data(32'h1000001c, 4'h0, 32'h1000203);
pci_burst_data(rbase_a+XY1,4'h0,32'h10001f);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80102fc, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3000002);
pci_burst_data(32'h10000004, 4'h0, 32'h3010002);
pci_burst_data(32'h10000008, 4'h0, 32'h3010002);
pci_burst_data(32'h1000000c, 4'h0, 32'h3010002);
pci_burst_data(32'h10000010, 4'h0, 32'h3010002);
pci_burst_data(32'h10000014, 4'h0, 32'h3010002);
pci_burst_data(32'h10000018, 4'h0, 32'h3010002);
pci_burst_data(32'h1000001c, 4'h0, 32'h3010002);
pci_burst_data(rbase_a+XY1,4'h0,32'h100020);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801031c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h2000100);
pci_burst_data(32'h10000004, 4'h0, 32'h2030100);
pci_burst_data(32'h10000008, 4'h0, 32'h2030100);
pci_burst_data(32'h1000000c, 4'h0, 32'h2030100);
pci_burst_data(32'h10000010, 4'h0, 32'h2030100);
pci_burst_data(32'h10000014, 4'h0, 32'h2030100);
pci_burst_data(32'h10000018, 4'h0, 32'h2030100);
pci_burst_data(32'h1000001c, 4'h0, 32'h2030100);
pci_burst_data(rbase_a+XY1,4'h0,32'h100021);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801033c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h301);
pci_burst_data(32'h10000004, 4'h0, 32'h20301);
pci_burst_data(32'h10000008, 4'h0, 32'h20301);
pci_burst_data(32'h1000000c, 4'h0, 32'h20301);
pci_burst_data(32'h10000010, 4'h0, 32'h20301);
pci_burst_data(32'h10000014, 4'h0, 32'h20301);
pci_burst_data(32'h10000018, 4'h0, 32'h20301);
pci_burst_data(32'h1000001c, 4'h0, 32'h20301);
pci_burst_data(rbase_a+XY1,4'h0,32'h100022);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801035c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1000203);
pci_burst_data(32'h10000004, 4'h0, 32'h1000203);
pci_burst_data(32'h10000008, 4'h0, 32'h1000203);
pci_burst_data(32'h1000000c, 4'h0, 32'h1000203);
pci_burst_data(32'h10000010, 4'h0, 32'h1000203);
pci_burst_data(32'h10000014, 4'h0, 32'h1000203);
pci_burst_data(32'h10000018, 4'h0, 32'h1000203);
pci_burst_data(32'h1000001c, 4'h0, 32'h1000203);
pci_burst_data(rbase_a+XY1,4'h0,32'h100023);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801037c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3000002);
pci_burst_data(32'h10000004, 4'h0, 32'h3010002);
pci_burst_data(32'h10000008, 4'h0, 32'h3010002);
pci_burst_data(32'h1000000c, 4'h0, 32'h3010002);
pci_burst_data(32'h10000010, 4'h0, 32'h3010002);
pci_burst_data(32'h10000014, 4'h0, 32'h3010002);
pci_burst_data(32'h10000018, 4'h0, 32'h3010002);
pci_burst_data(32'h1000001c, 4'h0, 32'h3010002);
pci_burst_data(rbase_a+XY1,4'h0,32'h100024);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801039c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h2000100);
pci_burst_data(32'h10000004, 4'h0, 32'h2030100);
pci_burst_data(32'h10000008, 4'h0, 32'h2030100);
pci_burst_data(32'h1000000c, 4'h0, 32'h2030100);
pci_burst_data(32'h10000010, 4'h0, 32'h2030100);
pci_burst_data(32'h10000014, 4'h0, 32'h2030100);
pci_burst_data(32'h10000018, 4'h0, 32'h2030100);
pci_burst_data(32'h1000001c, 4'h0, 32'h2030100);
pci_burst_data(rbase_a+XY1,4'h0,32'h100025);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80103bc, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h301);
pci_burst_data(32'h10000004, 4'h0, 32'h20301);
pci_burst_data(32'h10000008, 4'h0, 32'h20301);
pci_burst_data(32'h1000000c, 4'h0, 32'h20301);
pci_burst_data(32'h10000010, 4'h0, 32'h20301);
pci_burst_data(32'h10000014, 4'h0, 32'h20301);
pci_burst_data(32'h10000018, 4'h0, 32'h20301);
pci_burst_data(32'h1000001c, 4'h0, 32'h20301);
pci_burst_data(rbase_a+XY1,4'h0,32'h100026);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80103dc, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1000203);
pci_burst_data(32'h10000004, 4'h0, 32'h1000203);
pci_burst_data(32'h10000008, 4'h0, 32'h1000203);
pci_burst_data(32'h1000000c, 4'h0, 32'h1000203);
pci_burst_data(32'h10000010, 4'h0, 32'h1000203);
pci_burst_data(32'h10000014, 4'h0, 32'h1000203);
pci_burst_data(32'h10000018, 4'h0, 32'h1000203);
pci_burst_data(32'h1000001c, 4'h0, 32'h1000203);
pci_burst_data(rbase_a+XY1,4'h0,32'h100027);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x80103fc, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3000002);
pci_burst_data(32'h10000004, 4'h0, 32'h3010002);
pci_burst_data(32'h10000008, 4'h0, 32'h3010002);
pci_burst_data(32'h1000000c, 4'h0, 32'h3010002);
pci_burst_data(32'h10000010, 4'h0, 32'h3010002);
pci_burst_data(32'h10000014, 4'h0, 32'h3010002);
pci_burst_data(32'h10000018, 4'h0, 32'h3010002);
pci_burst_data(32'h1000001c, 4'h0, 32'h3010002);
pci_burst_data(rbase_a+XY1,4'h0,32'h100028);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801041c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h2000100);
pci_burst_data(32'h10000004, 4'h0, 32'h2030100);
pci_burst_data(32'h10000008, 4'h0, 32'h2030100);
pci_burst_data(32'h1000000c, 4'h0, 32'h2030100);
pci_burst_data(32'h10000010, 4'h0, 32'h2030100);
pci_burst_data(32'h10000014, 4'h0, 32'h2030100);
pci_burst_data(32'h10000018, 4'h0, 32'h2030100);
pci_burst_data(32'h1000001c, 4'h0, 32'h2030100);
pci_burst_data(rbase_a+XY1,4'h0,32'h100029);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801043c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h301);
pci_burst_data(32'h10000004, 4'h0, 32'h20301);
pci_burst_data(32'h10000008, 4'h0, 32'h20301);
pci_burst_data(32'h1000000c, 4'h0, 32'h20301);
pci_burst_data(32'h10000010, 4'h0, 32'h20301);
pci_burst_data(32'h10000014, 4'h0, 32'h20301);
pci_burst_data(32'h10000018, 4'h0, 32'h20301);
pci_burst_data(32'h1000001c, 4'h0, 32'h20301);
pci_burst_data(rbase_a+XY1,4'h0,32'h10002a);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801045c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1000203);
pci_burst_data(32'h10000004, 4'h0, 32'h1000203);
pci_burst_data(32'h10000008, 4'h0, 32'h1000203);
pci_burst_data(32'h1000000c, 4'h0, 32'h1000203);
pci_burst_data(32'h10000010, 4'h0, 32'h1000203);
pci_burst_data(32'h10000014, 4'h0, 32'h1000203);
pci_burst_data(32'h10000018, 4'h0, 32'h1000203);
pci_burst_data(32'h1000001c, 4'h0, 32'h1000203);
pci_burst_data(rbase_a+XY1,4'h0,32'h10002b);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801047c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h3000002);
pci_burst_data(32'h10000004, 4'h0, 32'h3010002);
pci_burst_data(32'h10000008, 4'h0, 32'h3010002);
pci_burst_data(32'h1000000c, 4'h0, 32'h3010002);
pci_burst_data(32'h10000010, 4'h0, 32'h3010002);
pci_burst_data(32'h10000014, 4'h0, 32'h3010002);
pci_burst_data(32'h10000018, 4'h0, 32'h3010002);
pci_burst_data(32'h1000001c, 4'h0, 32'h3010002);
pci_burst_data(rbase_a+XY1,4'h0,32'h10002c);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x801049c, 0x20, 0x8, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h2000100);
pci_burst_data(32'h10000004, 4'h0, 32'h2030100);
pci_burst_data(32'h10000008, 4'h0, 32'h2030100);
pci_burst_data(32'h1000000c, 4'h0, 32'h2030100);
pci_burst_data(32'h10000010, 4'h0, 32'h2030100);
pci_burst_data(32'h10000014, 4'h0, 32'h2030100);
pci_burst_data(32'h10000018, 4'h0, 32'h2030100);
pci_burst_data(32'h1000001c, 4'h0, 32'h2030100);
pci_burst_data(rbase_a+XY1,4'h0,32'h10002d);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x2400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h2400c00);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_memxfer_setup(0, 0x200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h40, 32'h10, "junk", 32'h180, 2'h0);
