/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h5bf80);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'h4080);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
/* bbird_src_bitmap(0x5bf80, 0x4080, 0x0); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h5bf80);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'h4080);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
/* bbird_dst_bitmap(0x5bf80, 0x4080, 0x0, 0, 0, 63, 15); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h5bf80);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h4080);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h3f000f);
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h16fe0, 16, 0);
VR.ram_fill32(32'h18000, 16, 0);
VR.ram_fill32(32'h19020, 16, 0);
VR.ram_fill32(32'h1a040, 16, 0);
VR.ram_fill32(32'h1b060, 16, 0);
VR.ram_fill32(32'h1c080, 16, 0);
VR.ram_fill32(32'h1d0a0, 16, 0);
VR.ram_fill32(32'h1e0c0, 16, 0);
VR.ram_fill32(32'h1f0e0, 16, 0);
VR.ram_fill32(32'h20100, 16, 0);
VR.ram_fill32(32'h21120, 16, 0);
VR.ram_fill32(32'h22140, 16, 0);
VR.ram_fill32(32'h23160, 16, 0);
VR.ram_fill32(32'h24180, 16, 0);
VR.ram_fill32(32'h251a0, 16, 0);
VR.ram_fill32(32'h261c0, 16, 0);
/* bbird_dst_bitmap(0x5bf80, 0x4080, 0x0, 0, 0, 63, 15); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h5bf80);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h4080);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h3f000f);
/* bbird_flags(0xffffffff, 0x0, 0x8400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
/* bbird_line_pat(0x6, 0x3); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h6);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h3);
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
/* bbird_line(0, 4, 5, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h4);
pci_burst_data(rbase_a+XY1,4'h0,32'h50000);
/* bbird_line(0, 5, 5, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h5);
pci_burst_data(rbase_a+XY1,4'h0,32'h50002);
/* bbird_line(0, 6, 5, 4); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h6);
pci_burst_data(rbase_a+XY1,4'h0,32'h50004);
/* bbird_line(0, 7, 5, 6); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h7);
pci_burst_data(rbase_a+XY1,4'h0,32'h50006);
/* bbird_line(0, 8, 5, 8); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h8);
pci_burst_data(rbase_a+XY1,4'h0,32'h50008);
/* bbird_line(0, 9, 5, 10); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h9);
pci_burst_data(rbase_a+XY1,4'h0,32'h5000a);
/* bbird_line(0, 10, 5, 12); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'ha);
pci_burst_data(rbase_a+XY1,4'h0,32'h5000c);
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
/* bbird_rectangle(0x38, 0x0, 0x3d, 0x5); */
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
/* bbird_bitblit(0, 0, 56, 0, 6, 6, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h60006);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h380000);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
/* bbird_colors(0x11, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h11);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
/* bbird_rectangle(0x38, 0x5, 0x3d, 0x9); */
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
/* bbird_bitblit(0, 0, 56, 5, 6, 5, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h60005);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h380005);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
/* bbird_line(6, 12, 6, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h6000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h60002);
/* bbird_line(7, 12, 7, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h7000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h70002);
/* bbird_line(8, 12, 8, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h8000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h80002);
/* bbird_line(9, 12, 9, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h9000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h90002);
/* bbird_line(10, 12, 10, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'ha000c);
pci_burst_data(rbase_a+XY1,4'h0,32'ha0002);
/* bbird_line(11, 12, 11, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'hb000c);
pci_burst_data(rbase_a+XY1,4'h0,32'hb0002);
/* bbird_line(12, 12, 12, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'hc000c);
pci_burst_data(rbase_a+XY1,4'h0,32'hc0002);
/* bbird_line(13, 12, 13, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'hd000c);
pci_burst_data(rbase_a+XY1,4'h0,32'hd0002);
/* bbird_line(14, 12, 14, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'he000c);
pci_burst_data(rbase_a+XY1,4'h0,32'he0002);
/* bbird_line(15, 12, 15, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'hf000c);
pci_burst_data(rbase_a+XY1,4'h0,32'hf0002);
/* bbird_line(16, 12, 16, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h10000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h100002);
/* bbird_line(17, 12, 17, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h11000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h110002);
/* bbird_line(18, 12, 18, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h12000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h120002);
/* bbird_line(19, 12, 19, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h13000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h130002);
/* bbird_line(20, 12, 20, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h14000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h140002);
/* bbird_line(21, 12, 21, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h15000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h150002);
/* bbird_line(22, 12, 22, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h16000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h160002);
/* bbird_line(23, 12, 23, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h17000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h170002);
/* bbird_line(24, 12, 24, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h18000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h180002);
/* bbird_line(25, 12, 25, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h19000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h190002);
/* bbird_line(26, 12, 26, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h1a000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h1a0002);
/* bbird_line(27, 12, 27, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h1b000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h1b0002);
/* bbird_line(28, 12, 28, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h1c000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h1c0002);
/* bbird_line(29, 12, 29, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h1d000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h1d0002);
/* bbird_line(30, 12, 30, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h1e000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h1e0002);
/* bbird_line(31, 12, 31, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h1f000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h1f0002);
/* bbird_line(32, 12, 32, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h20000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h200002);
/* bbird_line(33, 12, 33, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h21000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h210002);
/* bbird_line(34, 12, 34, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h22000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h220002);
/* bbird_line(35, 12, 35, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h23000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h230002);
/* bbird_line(36, 12, 36, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h24000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h240002);
/* bbird_line(37, 12, 37, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h25000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h250002);
/* bbird_line(38, 12, 38, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h26000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h260002);
/* bbird_line(39, 12, 39, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h27000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h270002);
/* bbird_line(40, 12, 40, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h28000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h280002);
/* bbird_line(41, 12, 41, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h29000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h290002);
/* bbird_line(42, 12, 42, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h2a000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h2a0002);
/* bbird_line(43, 12, 43, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h2b000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h2b0002);
/* bbird_line(44, 12, 44, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h2c000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h2c0002);
/* bbird_line(45, 12, 45, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h2d000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h2d0002);
/* bbird_line(46, 12, 46, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h2e000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h2e0002);
/* bbird_line(47, 12, 47, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h2f000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h2f0002);
/* bbird_line(48, 12, 48, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h30000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h300002);
/* bbird_line(49, 12, 49, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h31000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h310002);
/* bbird_line(50, 12, 50, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h32000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h320002);
/* bbird_line(51, 12, 51, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h33000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h330002);
/* bbird_line(52, 12, 52, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h34000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h340002);
/* bbird_line(53, 12, 53, 2); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h35000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h350002);
/* bbird_flags(0xffffffff, 0x0, 0x8400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h5bf80, 32'h40, 32'h10, "junk", 32'h4080, 2'h0);
