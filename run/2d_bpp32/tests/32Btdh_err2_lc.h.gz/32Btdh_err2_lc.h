///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2014 Francis Bruno, All Rights Reserved
// 
//  This program is free software; you can redistribute it and/or modify it 
//  under the terms of the GNU General Public License as published by the Free 
//  Software Foundation; either version 3 of the License, or (at your option) 
//  any later version.
//
//  This program is distributed in the hope that it will be useful, but 
//  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
//  or FITNESS FOR A PARTICULAR PURPOSE. 
//  See the GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License along with
//  this program; if not, see <http://www.gnu.org/licenses>.
//
//  This code is available under licenses for commercial use. Please contact
//  Francis Bruno for more information.
//
//  http://www.gplgpu.com
//  http://www.asicsolutions.com
//
//  Title       :  
//  File        :  
//  Author      :  Frank Bruno
//  Created     :  14-May-2011
//  RCS File    :  $Source:$
//  Status      :  $Id:$
//
///////////////////////////////////////////////////////////////////////////////
//
//  Description : 
//  2D test suite - 32 Bpp
//
//////////////////////////////////////////////////////////////////////////////
//
//  Modules Instantiated:
//
///////////////////////////////////////////////////////////////////////////////
//
//  Modification History:
//
//  $Log:$
//
//
///////////////////////////////////////////////////////////////////////////////
/* VERILOG logging on. */
/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'h600);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0x600, 0x2000000); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'h600);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x600, 0x2000000, 0, 0, 287, 159); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h600);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h11f009f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 288, 0);
VR.ram_fill32(32'h180, 288, 0);
VR.ram_fill32(32'h300, 288, 0);
VR.ram_fill32(32'h480, 288, 0);
VR.ram_fill32(32'h600, 288, 0);
VR.ram_fill32(32'h780, 288, 0);
VR.ram_fill32(32'h900, 288, 0);
VR.ram_fill32(32'ha80, 288, 0);
VR.ram_fill32(32'hc00, 288, 0);
VR.ram_fill32(32'hd80, 288, 0);
VR.ram_fill32(32'hf00, 288, 0);
VR.ram_fill32(32'h1080, 288, 0);
VR.ram_fill32(32'h1200, 288, 0);
VR.ram_fill32(32'h1380, 288, 0);
VR.ram_fill32(32'h1500, 288, 0);
VR.ram_fill32(32'h1680, 288, 0);
VR.ram_fill32(32'h1800, 288, 0);
VR.ram_fill32(32'h1980, 288, 0);
VR.ram_fill32(32'h1b00, 288, 0);
VR.ram_fill32(32'h1c80, 288, 0);
VR.ram_fill32(32'h1e00, 288, 0);
VR.ram_fill32(32'h1f80, 288, 0);
VR.ram_fill32(32'h2100, 288, 0);
VR.ram_fill32(32'h2280, 288, 0);
VR.ram_fill32(32'h2400, 288, 0);
VR.ram_fill32(32'h2580, 288, 0);
VR.ram_fill32(32'h2700, 288, 0);
VR.ram_fill32(32'h2880, 288, 0);
VR.ram_fill32(32'h2a00, 288, 0);
VR.ram_fill32(32'h2b80, 288, 0);
VR.ram_fill32(32'h2d00, 288, 0);
VR.ram_fill32(32'h2e80, 288, 0);
VR.ram_fill32(32'h3000, 288, 0);
VR.ram_fill32(32'h3180, 288, 0);
VR.ram_fill32(32'h3300, 288, 0);
VR.ram_fill32(32'h3480, 288, 0);
VR.ram_fill32(32'h3600, 288, 0);
VR.ram_fill32(32'h3780, 288, 0);
VR.ram_fill32(32'h3900, 288, 0);
VR.ram_fill32(32'h3a80, 288, 0);
VR.ram_fill32(32'h3c00, 288, 0);
VR.ram_fill32(32'h3d80, 288, 0);
VR.ram_fill32(32'h3f00, 288, 0);
VR.ram_fill32(32'h4080, 288, 0);
VR.ram_fill32(32'h4200, 288, 0);
VR.ram_fill32(32'h4380, 288, 0);
VR.ram_fill32(32'h4500, 288, 0);
VR.ram_fill32(32'h4680, 288, 0);
VR.ram_fill32(32'h4800, 288, 0);
VR.ram_fill32(32'h4980, 288, 0);
VR.ram_fill32(32'h4b00, 288, 0);
VR.ram_fill32(32'h4c80, 288, 0);
VR.ram_fill32(32'h4e00, 288, 0);
VR.ram_fill32(32'h4f80, 288, 0);
VR.ram_fill32(32'h5100, 288, 0);
VR.ram_fill32(32'h5280, 288, 0);
VR.ram_fill32(32'h5400, 288, 0);
VR.ram_fill32(32'h5580, 288, 0);
VR.ram_fill32(32'h5700, 288, 0);
VR.ram_fill32(32'h5880, 288, 0);
VR.ram_fill32(32'h5a00, 288, 0);
VR.ram_fill32(32'h5b80, 288, 0);
VR.ram_fill32(32'h5d00, 288, 0);
VR.ram_fill32(32'h5e80, 288, 0);
VR.ram_fill32(32'h6000, 288, 0);
VR.ram_fill32(32'h6180, 288, 0);
VR.ram_fill32(32'h6300, 288, 0);
VR.ram_fill32(32'h6480, 288, 0);
VR.ram_fill32(32'h6600, 288, 0);
VR.ram_fill32(32'h6780, 288, 0);
VR.ram_fill32(32'h6900, 288, 0);
VR.ram_fill32(32'h6a80, 288, 0);
VR.ram_fill32(32'h6c00, 288, 0);
VR.ram_fill32(32'h6d80, 288, 0);
VR.ram_fill32(32'h6f00, 288, 0);
VR.ram_fill32(32'h7080, 288, 0);
VR.ram_fill32(32'h7200, 288, 0);
VR.ram_fill32(32'h7380, 288, 0);
VR.ram_fill32(32'h7500, 288, 0);
VR.ram_fill32(32'h7680, 288, 0);
VR.ram_fill32(32'h7800, 288, 0);
VR.ram_fill32(32'h7980, 288, 0);
VR.ram_fill32(32'h7b00, 288, 0);
VR.ram_fill32(32'h7c80, 288, 0);
VR.ram_fill32(32'h7e00, 288, 0);
VR.ram_fill32(32'h7f80, 288, 0);
VR.ram_fill32(32'h8100, 288, 0);
VR.ram_fill32(32'h8280, 288, 0);
VR.ram_fill32(32'h8400, 288, 0);
VR.ram_fill32(32'h8580, 288, 0);
VR.ram_fill32(32'h8700, 288, 0);
VR.ram_fill32(32'h8880, 288, 0);
VR.ram_fill32(32'h8a00, 288, 0);
VR.ram_fill32(32'h8b80, 288, 0);
VR.ram_fill32(32'h8d00, 288, 0);
VR.ram_fill32(32'h8e80, 288, 0);
VR.ram_fill32(32'h9000, 288, 0);
VR.ram_fill32(32'h9180, 288, 0);
VR.ram_fill32(32'h9300, 288, 0);
VR.ram_fill32(32'h9480, 288, 0);
VR.ram_fill32(32'h9600, 288, 0);
VR.ram_fill32(32'h9780, 288, 0);
VR.ram_fill32(32'h9900, 288, 0);
VR.ram_fill32(32'h9a80, 288, 0);
VR.ram_fill32(32'h9c00, 288, 0);
VR.ram_fill32(32'h9d80, 288, 0);
VR.ram_fill32(32'h9f00, 288, 0);
VR.ram_fill32(32'ha080, 288, 0);
VR.ram_fill32(32'ha200, 288, 0);
VR.ram_fill32(32'ha380, 288, 0);
VR.ram_fill32(32'ha500, 288, 0);
VR.ram_fill32(32'ha680, 288, 0);
VR.ram_fill32(32'ha800, 288, 0);
VR.ram_fill32(32'ha980, 288, 0);
VR.ram_fill32(32'hab00, 288, 0);
VR.ram_fill32(32'hac80, 288, 0);
VR.ram_fill32(32'hae00, 288, 0);
VR.ram_fill32(32'haf80, 288, 0);
VR.ram_fill32(32'hb100, 288, 0);
VR.ram_fill32(32'hb280, 288, 0);
VR.ram_fill32(32'hb400, 288, 0);
VR.ram_fill32(32'hb580, 288, 0);
VR.ram_fill32(32'hb700, 288, 0);
VR.ram_fill32(32'hb880, 288, 0);
VR.ram_fill32(32'hba00, 288, 0);
VR.ram_fill32(32'hbb80, 288, 0);
VR.ram_fill32(32'hbd00, 288, 0);
VR.ram_fill32(32'hbe80, 288, 0);
VR.ram_fill32(32'hc000, 288, 0);
VR.ram_fill32(32'hc180, 288, 0);
VR.ram_fill32(32'hc300, 288, 0);
VR.ram_fill32(32'hc480, 288, 0);
VR.ram_fill32(32'hc600, 288, 0);
VR.ram_fill32(32'hc780, 288, 0);
VR.ram_fill32(32'hc900, 288, 0);
VR.ram_fill32(32'hca80, 288, 0);
VR.ram_fill32(32'hcc00, 288, 0);
VR.ram_fill32(32'hcd80, 288, 0);
VR.ram_fill32(32'hcf00, 288, 0);
VR.ram_fill32(32'hd080, 288, 0);
VR.ram_fill32(32'hd200, 288, 0);
VR.ram_fill32(32'hd380, 288, 0);
VR.ram_fill32(32'hd500, 288, 0);
VR.ram_fill32(32'hd680, 288, 0);
VR.ram_fill32(32'hd800, 288, 0);
VR.ram_fill32(32'hd980, 288, 0);
VR.ram_fill32(32'hdb00, 288, 0);
VR.ram_fill32(32'hdc80, 288, 0);
VR.ram_fill32(32'hde00, 288, 0);
VR.ram_fill32(32'hdf80, 288, 0);
VR.ram_fill32(32'he100, 288, 0);
VR.ram_fill32(32'he280, 288, 0);
VR.ram_fill32(32'he400, 288, 0);
VR.ram_fill32(32'he580, 288, 0);
VR.ram_fill32(32'he700, 288, 0);
VR.ram_fill32(32'he880, 288, 0);
VR.ram_fill32(32'hea00, 288, 0);
VR.ram_fill32(32'heb80, 288, 0);
VR.ram_fill32(32'hed00, 288, 0);
VR.ram_fill32(32'hee80, 288, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x600, 0x2000000, 0, 0, 287, 159); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h600);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h11f009f);
/* bbird_memxfer_setup(0, 0x8200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h8200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
/* bbird_memxfer_setup(1, 0x0, 0x0, 0x0, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW1_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_CTRL,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_WKEY,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_KYDAT,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_line_pat(0x16, 0x5); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h16);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h5);
wait_for_pipe_a;
/* bbird_colors(0x13, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h13);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x420c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h420c00);
/* bbird_font_write("WBEGKMQ"); { 0x3, 0x6 } */
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h42000300+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'h4e0c01);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* Writing character 'W' */
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0x4); */
pci_burst_data(32'h10000000, 4'h0, 32'h0);
pci_burst_data(32'h10000004, 4'h0, 32'h0);
pci_burst_data(32'h10000008, 4'h0, 32'h0);
pci_burst_data(32'h1000000c, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h3d0002);
pci_burst_data(rbase_a+XY1,4'h0,32'h50006);
wait_for_pipe_a;
pci_burst_data(rbase_a+XY2,4'h0,32'h3d0008);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0x10); */
pci_burst_data(32'h10000040, 4'h0, 32'hf);
pci_burst_data(32'h10000044, 4'h0, 32'hfe000000);
pci_burst_data(32'h10000048, 4'h0, 32'hf);
pci_burst_data(32'h1000004c, 4'h0, 32'hfe000000);
pci_burst_data(32'h10000050, 4'h0, 32'hf);
pci_burst_data(32'h10000054, 4'h0, 32'hfe000000);
pci_burst_data(32'h10000058, 4'h0, 32'hf);
pci_burst_data(32'h1000005c, 4'h0, 32'hfe000000);
pci_burst_data(32'h10000060, 4'h0, 32'h1e);
pci_burst_data(32'h10000064, 4'h0, 32'hcf000000);
pci_burst_data(32'h10000068, 4'h0, 32'h1e);
pci_burst_data(32'h1000006c, 4'h0, 32'hcf000000);
pci_burst_data(32'h10000070, 4'h0, 32'h1e);
pci_burst_data(32'h10000074, 4'h0, 32'h8f000000);
pci_burst_data(32'h10000078, 4'h0, 32'h1e);
pci_burst_data(32'h1000007c, 4'h0, 32'h8f000000);
pci_burst_data(rbase_a+XY1,4'h0,32'h50008);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0x10); */
pci_burst_data(32'h10000000, 4'h0, 32'h3c);
pci_burst_data(32'h10000004, 4'h0, 32'h7800000);
pci_burst_data(32'h10000008, 4'h0, 32'h3c);
pci_burst_data(32'h1000000c, 4'h0, 32'h7800000);
pci_burst_data(32'h10000010, 4'h0, 32'h3c);
pci_burst_data(32'h10000014, 4'h0, 32'h7800000);
pci_burst_data(32'h10000018, 4'h0, 32'h3c);
pci_burst_data(32'h1000001c, 4'h0, 32'h7800000);
pci_burst_data(32'h10000020, 4'h0, 32'h78);
pci_burst_data(32'h10000024, 4'h0, 32'h3c00000);
pci_burst_data(32'h10000028, 4'h0, 32'h78);
pci_burst_data(32'h1000002c, 4'h0, 32'h3c00000);
pci_burst_data(32'h10000030, 4'h0, 32'h78);
pci_burst_data(32'h10000034, 4'h0, 32'h3c00000);
pci_burst_data(32'h10000038, 4'h0, 32'he0000078);
pci_burst_data(32'h1000003c, 4'h0, 32'h3c00000);
pci_burst_data(rbase_a+XY1,4'h0,32'h50010);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0x10); */
pci_burst_data(32'h10000040, 4'h0, 32'he00000f0);
pci_burst_data(32'h10000044, 4'h0, 32'h1e00000);
pci_burst_data(32'h10000048, 4'h0, 32'hf00000f0);
pci_burst_data(32'h1000004c, 4'h0, 32'h1e00001);
pci_burst_data(32'h10000050, 4'h0, 32'hf00000f0);
pci_burst_data(32'h10000054, 4'h0, 32'h1e00001);
pci_burst_data(32'h10000058, 4'h0, 32'hf00000f0);
pci_burst_data(32'h1000005c, 4'h0, 32'h1e00001);
pci_burst_data(32'h10000060, 4'h0, 32'hf80001e0);
pci_burst_data(32'h10000064, 4'h0, 32'hf00003);
pci_burst_data(32'h10000068, 4'h0, 32'hf80001e0);
pci_burst_data(32'h1000006c, 4'h0, 32'hf00003);
pci_burst_data(32'h10000070, 4'h0, 32'hf80001e0);
pci_burst_data(32'h10000074, 4'h0, 32'hf00003);
pci_burst_data(32'h10000078, 4'h0, 32'hbc0001e0);
pci_burst_data(32'h1000007c, 4'h0, 32'hf00007);
pci_burst_data(rbase_a+XY1,4'h0,32'h50018);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0x10); */
pci_burst_data(32'h10000000, 4'h0, 32'hbc0003c0);
pci_burst_data(32'h10000004, 4'h0, 32'h780007);
pci_burst_data(32'h10000008, 4'h0, 32'hbc0003c0);
pci_burst_data(32'h1000000c, 4'h0, 32'h780007);
pci_burst_data(32'h10000010, 4'h0, 32'h1e0003c0);
pci_burst_data(32'h10000014, 4'h0, 32'h78000f);
pci_burst_data(32'h10000018, 4'h0, 32'h1e0003c0);
pci_burst_data(32'h1000001c, 4'h0, 32'h78000f);
pci_burst_data(32'h10000020, 4'h0, 32'h1e000780);
pci_burst_data(32'h10000024, 4'h0, 32'h3c000f);
pci_burst_data(32'h10000028, 4'h0, 32'hf000780);
pci_burst_data(32'h1000002c, 4'h0, 32'h3c001e);
pci_burst_data(32'h10000030, 4'h0, 32'hf000780);
pci_burst_data(32'h10000034, 4'h0, 32'h3c001e);
pci_burst_data(32'h10000038, 4'h0, 32'hf000780);
pci_burst_data(32'h1000003c, 4'h0, 32'h3c001e);
pci_burst_data(rbase_a+XY1,4'h0,32'h50020);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0x10); */
pci_burst_data(32'h10000040, 4'h0, 32'hf000f00);
pci_burst_data(32'h10000044, 4'h0, 32'h1e001e);
pci_burst_data(32'h10000048, 4'h0, 32'h7800f00);
pci_burst_data(32'h1000004c, 4'h0, 32'h1e003c);
pci_burst_data(32'h10000050, 4'h0, 32'h7800f00);
pci_burst_data(32'h10000054, 4'h0, 32'h1e003c);
pci_burst_data(32'h10000058, 4'h0, 32'h7800f00);
pci_burst_data(32'h1000005c, 4'h0, 32'hf003c);
pci_burst_data(32'h10000060, 4'h0, 32'h7801e00);
pci_burst_data(32'h10000064, 4'h0, 32'hf003c);
pci_burst_data(32'h10000068, 4'h0, 32'h3c01e00);
pci_burst_data(32'h1000006c, 4'h0, 32'hf0078);
pci_burst_data(32'h10000070, 4'h0, 32'h3c01e00);
pci_burst_data(32'h10000074, 4'h0, 32'h78078);
pci_burst_data(32'h10000078, 4'h0, 32'h3c03c00);
pci_burst_data(32'h1000007c, 4'h0, 32'h78078);
pci_burst_data(rbase_a+XY1,4'h0,32'h50028);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0x10); */
pci_burst_data(32'h10000000, 4'h0, 32'h3c03c00);
pci_burst_data(32'h10000004, 4'h0, 32'h78078);
pci_burst_data(32'h10000008, 4'h0, 32'h1e03c00);
pci_burst_data(32'h1000000c, 4'h0, 32'h3c0f0);
pci_burst_data(32'h10000010, 4'h0, 32'h1e07800);
pci_burst_data(32'h10000014, 4'h0, 32'h3c0f0);
pci_burst_data(32'h10000018, 4'h0, 32'h1e07800);
pci_burst_data(32'h1000001c, 4'h0, 32'h3c0f0);
pci_burst_data(32'h10000020, 4'h0, 32'h1e07800);
pci_burst_data(32'h10000024, 4'h0, 32'h1e0f0);
pci_burst_data(32'h10000028, 4'h0, 32'hf0f000);
pci_burst_data(32'h1000002c, 4'h0, 32'h1e1e0);
pci_burst_data(32'h10000030, 4'h0, 32'hf0f000);
pci_burst_data(32'h10000034, 4'h0, 32'h1e1e0);
pci_burst_data(32'h10000038, 4'h0, 32'hf0f000);
pci_burst_data(32'h1000003c, 4'h0, 32'h1e1e0);
pci_burst_data(rbase_a+XY1,4'h0,32'h50030);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0x10); */
pci_burst_data(32'h10000040, 4'h0, 32'hf1e000);
pci_burst_data(32'h10000044, 4'h0, 32'hf1e0);
pci_burst_data(32'h10000048, 4'h0, 32'h79e000);
pci_burst_data(32'h1000004c, 4'h0, 32'hf3c0);
pci_burst_data(32'h10000050, 4'h0, 32'h79e000);
pci_burst_data(32'h10000054, 4'h0, 32'hf3c0);
pci_burst_data(32'h10000058, 4'h0, 32'h7fc000);
pci_burst_data(32'h1000005c, 4'h0, 32'h7fc0);
pci_burst_data(32'h10000060, 4'h0, 32'h3fc000);
pci_burst_data(32'h10000064, 4'h0, 32'h80007f80);
pci_burst_data(32'h10000068, 4'h0, 32'h3fc000);
pci_burst_data(32'h1000006c, 4'h0, 32'h80007f80);
pci_burst_data(32'h10000070, 4'h0, 32'h3f8000);
pci_burst_data(32'h10000074, 4'h0, 32'hc0003f80);
pci_burst_data(32'h10000078, 4'h0, 32'h1f8000);
pci_burst_data(32'h1000007c, 4'h0, 32'hc0003f00);
pci_burst_data(rbase_a+XY1,4'h0,32'h50038);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0x10); */
pci_burst_data(32'h10000000, 4'h0, 32'h1f8000);
pci_burst_data(32'h10000004, 4'h0, 32'he0003f00);
pci_burst_data(32'h10000008, 4'h0, 32'h1f0000);
pci_burst_data(32'h1000000c, 4'h0, 32'he0001f00);
pci_burst_data(32'h10000010, 4'h0, 32'hf0000);
pci_burst_data(32'h10000014, 4'h0, 32'he0001e00);
pci_burst_data(32'h10000018, 4'h0, 32'hf0000);
pci_burst_data(32'h1000001c, 4'h0, 32'he0001e00);
pci_burst_data(32'h10000020, 4'h0, 32'h0);
pci_burst_data(32'h10000024, 4'h0, 32'h0);
pci_burst_data(32'h10000028, 4'h0, 32'h0);
pci_burst_data(32'h1000002c, 4'h0, 32'h0);
pci_burst_data(32'h10000030, 4'h0, 32'h0);
pci_burst_data(32'h10000034, 4'h0, 32'h0);
pci_burst_data(32'h10000038, 4'h0, 32'h0);
pci_burst_data(32'h1000003c, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h50040);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0x10); */
pci_burst_data(32'h10000040, 4'h0, 32'h0);
pci_burst_data(32'h10000044, 4'h0, 32'h0);
pci_burst_data(32'h10000048, 4'h0, 32'h0);
pci_burst_data(32'h1000004c, 4'h0, 32'h0);
pci_burst_data(32'h10000050, 4'h0, 32'h0);
pci_burst_data(32'h10000054, 4'h0, 32'h0);
pci_burst_data(32'h10000058, 4'h0, 32'h0);
pci_burst_data(32'h1000005c, 4'h0, 32'h0);
pci_burst_data(32'h10000060, 4'h0, 32'h0);
pci_burst_data(32'h10000064, 4'h0, 32'h0);
pci_burst_data(32'h10000068, 4'h0, 32'h0);
pci_burst_data(32'h1000006c, 4'h0, 32'h0);
pci_burst_data(32'h10000070, 4'h0, 32'h0);
pci_burst_data(32'h10000074, 4'h0, 32'h0);
pci_burst_data(32'h10000078, 4'h0, 32'h0);
pci_burst_data(32'h1000007c, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h50048);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0x10); */
pci_burst_data(32'h10000000, 4'h0, 32'h0);
pci_burst_data(32'h10000004, 4'h0, 32'h0);
pci_burst_data(32'h10000008, 4'h0, 32'h0);
pci_burst_data(32'h1000000c, 4'h0, 32'h0);
pci_burst_data(32'h10000010, 4'h0, 32'h0);
pci_burst_data(32'h10000014, 4'h0, 32'h0);
pci_burst_data(32'h10000018, 4'h0, 32'h0);
pci_burst_data(32'h1000001c, 4'h0, 32'h0);
pci_burst_data(32'h10000020, 4'h0, 32'h0);
pci_burst_data(32'h10000024, 4'h0, 32'h0);
pci_burst_data(32'h10000028, 4'h0, 32'h0);
pci_burst_data(32'h1000002c, 4'h0, 32'h0);
pci_burst_data(32'h10000030, 4'h0, 32'h0);
pci_burst_data(32'h10000034, 4'h0, 32'h0);
pci_burst_data(32'h10000038, 4'h0, 32'h0);
pci_burst_data(32'h1000003c, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h50050);
/* Writing character 'B' */
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xd); */
pci_burst_data(32'h10000040, 4'h0, 32'h0);
pci_burst_data(32'h10000044, 4'h0, 32'h0);
pci_burst_data(32'h10000048, 4'h0, 32'hffff0000);
pci_burst_data(32'h1000004c, 4'h0, 32'hff00003f);
pci_burst_data(32'h10000050, 4'h0, 32'hffff);
pci_burst_data(32'h10000054, 4'h0, 32'h3ffffff);
pci_burst_data(32'h10000058, 4'h0, 32'hffffff00);
pci_burst_data(32'h1000005c, 4'h0, 32'hf0007);
pci_burst_data(32'h10000060, 4'h0, 32'hf000fe0);
pci_burst_data(32'h10000064, 4'h0, 32'h800f8000);
pci_burst_data(32'h10000068, 4'h0, 32'h1f00000f);
pci_burst_data(32'h1000006c, 4'h0, 32'hfc0);
pci_burst_data(32'h10000070, 4'h0, 32'he01e);
pci_burst_data(rbase_a+XY2,4'h0,32'h22000a);
pci_burst_data(rbase_a+XY1,4'h0,32'h450006);
wait_for_pipe_a;
pci_burst_data(rbase_a+XY2,4'h0,32'h22000c);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xf); */
pci_burst_data(32'h10000000, 4'h0, 32'h3e00000f);
pci_burst_data(32'h10000004, 4'h0, 32'hff0);
pci_burst_data(32'h10000008, 4'h0, 32'hff03c);
pci_burst_data(32'h1000000c, 4'h0, 32'hff83c00);
pci_burst_data(32'h10000010, 4'h0, 32'h783c0000);
pci_burst_data(32'h10000014, 4'h0, 32'h3c00000f);
pci_burst_data(32'h10000018, 4'h0, 32'hf7c);
pci_burst_data(32'h1000001c, 4'h0, 32'hf3c3c);
pci_burst_data(32'h10000020, 4'h0, 32'hf3c3c00);
pci_burst_data(32'h10000024, 4'h0, 32'h3c3c0000);
pci_burst_data(32'h10000028, 4'h0, 32'h3c00000f);
pci_burst_data(32'h1000002c, 4'h0, 32'hf3c);
pci_burst_data(32'h10000030, 4'h0, 32'hf3c3c);
pci_burst_data(32'h10000034, 4'h0, 32'hf3c3c00);
pci_burst_data(32'h10000038, 4'h0, 32'h3c3e0000);
pci_burst_data(rbase_a+XY1,4'h0,32'h450010);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xf); */
pci_burst_data(32'h10000040, 4'h0, 32'h1e00000f);
pci_burst_data(32'h10000044, 4'h0, 32'hf3c);
pci_burst_data(32'h10000048, 4'h0, 32'hf3c1f);
pci_burst_data(32'h1000004c, 4'h0, 32'hf3c0f80);
pci_burst_data(32'h10000050, 4'h0, 32'h3c0fe000);
pci_burst_data(32'h10000054, 4'h0, 32'h7ffffff);
pci_burst_data(32'h10000058, 4'h0, 32'hffffff3c);
pci_burst_data(32'h1000005c, 4'h0, 32'hffff3c03);
pci_burst_data(32'h10000060, 4'h0, 32'hff3c03ff);
pci_burst_data(32'h10000064, 4'h0, 32'h3c07ffff);
pci_burst_data(32'h10000068, 4'h0, 32'hfe0000f);
pci_burst_data(32'h1000006c, 4'h0, 32'h80000f3c);
pci_burst_data(32'h10000070, 4'h0, 32'hf3c1f);
pci_burst_data(32'h10000074, 4'h0, 32'hf3c3f00);
pci_burst_data(32'h10000078, 4'h0, 32'h3c7e0000);
pci_burst_data(rbase_a+XY1,4'h0,32'h45001c);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xf); */
pci_burst_data(32'h10000000, 4'h0, 32'hfc00000f);
pci_burst_data(32'h10000004, 4'h0, 32'hf3c);
pci_burst_data(32'h10000008, 4'h0, 32'hf3cf8);
pci_burst_data(32'h1000000c, 4'h0, 32'hf3df000);
pci_burst_data(32'h10000010, 4'h0, 32'h3de00000);
pci_burst_data(32'h10000014, 4'h0, 32'he000000f);
pci_burst_data(32'h10000018, 4'h0, 32'hf3f);
pci_burst_data(32'h1000001c, 4'h0, 32'hf3fc0);
pci_burst_data(32'h10000020, 4'h0, 32'hf3fc000);
pci_burst_data(32'h10000024, 4'h0, 32'h3fc00000);
pci_burst_data(32'h10000028, 4'h0, 32'hc000000f);
pci_burst_data(32'h1000002c, 4'h0, 32'hf3f);
pci_burst_data(32'h10000030, 4'h0, 32'hf3fc0);
pci_burst_data(32'h10000034, 4'h0, 32'hf3fc000);
pci_burst_data(32'h10000038, 4'h0, 32'h3fc00000);
pci_burst_data(rbase_a+XY1,4'h0,32'h450028);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xf); */
pci_burst_data(32'h10000040, 4'h0, 32'hc000000f);
pci_burst_data(32'h10000044, 4'h0, 32'hf3f);
pci_burst_data(32'h10000048, 4'h0, 32'hf3fc0);
pci_burst_data(32'h1000004c, 4'h0, 32'hf3fc000);
pci_burst_data(32'h10000050, 4'h0, 32'h7fc00000);
pci_burst_data(32'h10000054, 4'h0, 32'hc000000f);
pci_burst_data(32'h10000058, 4'h0, 32'hf7b);
pci_burst_data(32'h1000005c, 4'h0, 32'hffbe0);
pci_burst_data(32'h10000060, 4'h0, 32'hff1e000);
pci_burst_data(32'h10000064, 4'h0, 32'hf1f00000);
pci_burst_data(32'h10000068, 4'h0, 32'hf800000f);
pci_burst_data(32'h1000006c, 4'h0, 32'hfe0);
pci_burst_data(32'h10000070, 4'h0, 32'hfc0fc);
pci_burst_data(32'h10000074, 4'h0, 32'hf807e00);
pci_burst_data(32'h10000078, 4'h0, 32'h3f8000);
pci_burst_data(rbase_a+XY1,4'h0,32'h450034);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xf); */
pci_burst_data(32'h10000000, 4'h0, 32'h1fffffff);
pci_burst_data(32'h10000004, 4'h0, 32'hffffff00);
pci_burst_data(32'h10000008, 4'h0, 32'hffff000f);
pci_burst_data(32'h1000000c, 4'h0, 32'hff0003ff);
pci_burst_data(32'h10000010, 4'h0, 32'hffff);
pci_burst_data(32'h10000014, 4'h0, 32'h0);
pci_burst_data(32'h10000018, 4'h0, 32'h0);
pci_burst_data(32'h1000001c, 4'h0, 32'h0);
pci_burst_data(32'h10000020, 4'h0, 32'h0);
pci_burst_data(32'h10000024, 4'h0, 32'h0);
pci_burst_data(32'h10000028, 4'h0, 32'h0);
pci_burst_data(32'h1000002c, 4'h0, 32'h0);
pci_burst_data(32'h10000030, 4'h0, 32'h0);
pci_burst_data(32'h10000034, 4'h0, 32'h0);
pci_burst_data(32'h10000038, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h450040);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xf); */
pci_burst_data(32'h10000040, 4'h0, 32'h0);
pci_burst_data(32'h10000044, 4'h0, 32'h0);
pci_burst_data(32'h10000048, 4'h0, 32'h0);
pci_burst_data(32'h1000004c, 4'h0, 32'h0);
pci_burst_data(32'h10000050, 4'h0, 32'h0);
pci_burst_data(32'h10000054, 4'h0, 32'h0);
pci_burst_data(32'h10000058, 4'h0, 32'h0);
pci_burst_data(32'h1000005c, 4'h0, 32'h0);
pci_burst_data(32'h10000060, 4'h0, 32'h0);
pci_burst_data(32'h10000064, 4'h0, 32'h0);
pci_burst_data(32'h10000068, 4'h0, 32'h0);
pci_burst_data(32'h1000006c, 4'h0, 32'h0);
pci_burst_data(32'h10000070, 4'h0, 32'h0);
pci_burst_data(32'h10000074, 4'h0, 32'h0);
pci_burst_data(32'h10000078, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h45004c);
/* Writing character 'E' */
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0x2); */
pci_burst_data(32'h10000000, 4'h0, 32'h0);
pci_burst_data(32'h10000004, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h1c0002);
pci_burst_data(rbase_a+XY1,4'h0,32'h6b0006);
wait_for_pipe_a;
pci_burst_data(rbase_a+XY2,4'h0,32'h1c0010);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0x10); */
pci_burst_data(32'h10000040, 4'h0, 32'hffffffff);
pci_burst_data(32'h10000044, 4'h0, 32'hffffffff);
pci_burst_data(32'h10000048, 4'h0, 32'hffffffff);
pci_burst_data(32'h1000004c, 4'h0, 32'hffffffff);
pci_burst_data(32'h10000050, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000054, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000058, 4'h0, 32'hf000000f);
pci_burst_data(32'h1000005c, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000060, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000064, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000068, 4'h0, 32'hf000000f);
pci_burst_data(32'h1000006c, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000070, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000074, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000078, 4'h0, 32'hf000000f);
pci_burst_data(32'h1000007c, 4'h0, 32'hf000000f);
pci_burst_data(rbase_a+XY1,4'h0,32'h6b0008);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0x10); */
pci_burst_data(32'h10000000, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000004, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000008, 4'h0, 32'hf000000f);
pci_burst_data(32'h1000000c, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000010, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000014, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000018, 4'h0, 32'hf000000f);
pci_burst_data(32'h1000001c, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000020, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000024, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000028, 4'h0, 32'hf0ffffff);
pci_burst_data(32'h1000002c, 4'h0, 32'hf0ffffff);
pci_burst_data(32'h10000030, 4'h0, 32'hf0ffffff);
pci_burst_data(32'h10000034, 4'h0, 32'hf0ffffff);
pci_burst_data(32'h10000038, 4'h0, 32'hf000000f);
pci_burst_data(32'h1000003c, 4'h0, 32'hf000000f);
pci_burst_data(rbase_a+XY1,4'h0,32'h6b0018);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0x10); */
pci_burst_data(32'h10000040, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000044, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000048, 4'h0, 32'hf000000f);
pci_burst_data(32'h1000004c, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000050, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000054, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000058, 4'h0, 32'hf000000f);
pci_burst_data(32'h1000005c, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000060, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000064, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000068, 4'h0, 32'hf000000f);
pci_burst_data(32'h1000006c, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000070, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000074, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000078, 4'h0, 32'hf000000f);
pci_burst_data(32'h1000007c, 4'h0, 32'hf000000f);
pci_burst_data(rbase_a+XY1,4'h0,32'h6b0028);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0x10); */
pci_burst_data(32'h10000000, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000004, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000008, 4'h0, 32'hf000000f);
pci_burst_data(32'h1000000c, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000010, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000014, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000018, 4'h0, 32'hf000000f);
pci_burst_data(32'h1000001c, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000020, 4'h0, 32'hffffffff);
pci_burst_data(32'h10000024, 4'h0, 32'hffffffff);
pci_burst_data(32'h10000028, 4'h0, 32'hffffffff);
pci_burst_data(32'h1000002c, 4'h0, 32'hffffffff);
pci_burst_data(32'h10000030, 4'h0, 32'h0);
pci_burst_data(32'h10000034, 4'h0, 32'h0);
pci_burst_data(32'h10000038, 4'h0, 32'h0);
pci_burst_data(32'h1000003c, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h6b0038);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0x10); */
pci_burst_data(32'h10000040, 4'h0, 32'h0);
pci_burst_data(32'h10000044, 4'h0, 32'h0);
pci_burst_data(32'h10000048, 4'h0, 32'h0);
pci_burst_data(32'h1000004c, 4'h0, 32'h0);
pci_burst_data(32'h10000050, 4'h0, 32'h0);
pci_burst_data(32'h10000054, 4'h0, 32'h0);
pci_burst_data(32'h10000058, 4'h0, 32'h0);
pci_burst_data(32'h1000005c, 4'h0, 32'h0);
pci_burst_data(32'h10000060, 4'h0, 32'h0);
pci_burst_data(32'h10000064, 4'h0, 32'h0);
pci_burst_data(32'h10000068, 4'h0, 32'h0);
pci_burst_data(32'h1000006c, 4'h0, 32'h0);
pci_burst_data(32'h10000070, 4'h0, 32'h0);
pci_burst_data(32'h10000074, 4'h0, 32'h0);
pci_burst_data(32'h10000078, 4'h0, 32'h0);
pci_burst_data(32'h1000007c, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h6b0048);
/* Writing character 'G' */
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xd); */
pci_burst_data(32'h10000000, 4'h0, 32'h0);
pci_burst_data(32'h10000004, 4'h0, 32'h0);
pci_burst_data(32'h10000008, 4'h0, 32'hf0000000);
pci_burst_data(32'h1000000c, 4'h0, 32'hfff);
pci_burst_data(32'h10000010, 4'h0, 32'h3ffffc);
pci_burst_data(32'h10000014, 4'h0, 32'hffffff00);
pci_burst_data(32'h10000018, 4'h0, 32'hffff8000);
pci_burst_data(32'h1000001c, 4'h0, 32'h1fc001ff);
pci_burst_data(32'h10000020, 4'h0, 32'he003f800);
pci_burst_data(32'h10000024, 4'h0, 32'h3e00007);
pci_burst_data(32'h10000028, 4'h0, 32'hc00003f0);
pci_burst_data(32'h1000002c, 4'h0, 32'h1f807);
pci_burst_data(32'h10000030, 4'h0, 32'h780);
pci_burst_data(rbase_a+XY2,4'h0,32'h28000a);
pci_burst_data(rbase_a+XY1,4'h0,32'h8b0006);
wait_for_pipe_a;
pci_burst_data(rbase_a+XY2,4'h0,32'h28000c);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xf); */
pci_burst_data(32'h10000040, 4'h0, 32'h800000fc);
pci_burst_data(32'h10000044, 4'h0, 32'h7c0f);
pci_burst_data(32'h10000048, 4'h0, 32'h3e0f00);
pci_burst_data(32'h1000004c, 4'h0, 32'h1e0f0000);
pci_burst_data(32'h10000050, 4'h0, 32'hf000000);
pci_burst_data(32'h10000054, 4'h0, 32'h1f);
pci_burst_data(32'h10000058, 4'h0, 32'hf00);
pci_burst_data(32'h1000005c, 4'h0, 32'hf0000);
pci_burst_data(32'h10000060, 4'h0, 32'hf000000);
pci_burst_data(32'h10000064, 4'h0, 32'h0);
pci_burst_data(32'h10000068, 4'h0, 32'hf);
pci_burst_data(32'h1000006c, 4'h0, 32'hf00);
pci_burst_data(32'h10000070, 4'h0, 32'hf0000);
pci_burst_data(32'h10000074, 4'h0, 32'hf000000);
pci_burst_data(32'h10000078, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h8b0010);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xf); */
pci_burst_data(32'h10000000, 4'h0, 32'hf);
pci_burst_data(32'h10000004, 4'h0, 32'hf00);
pci_burst_data(32'h10000008, 4'h0, 32'hf0000);
pci_burst_data(32'h1000000c, 4'h0, 32'hf000000);
pci_burst_data(32'h10000010, 4'h0, 32'h0);
pci_burst_data(32'h10000014, 4'h0, 32'hf);
pci_burst_data(32'h10000018, 4'h0, 32'hf00);
pci_burst_data(32'h1000001c, 4'h0, 32'hf0000);
pci_burst_data(32'h10000020, 4'h0, 32'hf000000);
pci_burst_data(32'h10000024, 4'h0, 32'h0);
pci_burst_data(32'h10000028, 4'h0, 32'hfff0000f);
pci_burst_data(32'h1000002c, 4'h0, 32'hf0000fff);
pci_burst_data(32'h10000030, 4'h0, 32'hfffff);
pci_burst_data(32'h10000034, 4'h0, 32'hffffff0);
pci_burst_data(32'h10000038, 4'h0, 32'hfffff000);
pci_burst_data(rbase_a+XY1,4'h0,32'h8b001c);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xf); */
pci_burst_data(32'h10000040, 4'h0, 32'hf);
pci_burst_data(32'h10000044, 4'h0, 32'hff0);
pci_burst_data(32'h10000048, 4'h0, 32'hff000);
pci_burst_data(32'h1000004c, 4'h0, 32'hff00000);
pci_burst_data(32'h10000050, 4'h0, 32'hf0000000);
pci_burst_data(32'h10000054, 4'h0, 32'hf);
pci_burst_data(32'h10000058, 4'h0, 32'hff0);
pci_burst_data(32'h1000005c, 4'h0, 32'hff000);
pci_burst_data(32'h10000060, 4'h0, 32'hff00000);
pci_burst_data(32'h10000064, 4'h0, 32'hf0000000);
pci_burst_data(32'h10000068, 4'h0, 32'hf);
pci_burst_data(32'h1000006c, 4'h0, 32'hff0);
pci_burst_data(32'h10000070, 4'h0, 32'hff000);
pci_burst_data(32'h10000074, 4'h0, 32'hff00000);
pci_burst_data(32'h10000078, 4'h0, 32'hf0000000);
pci_burst_data(rbase_a+XY1,4'h0,32'h8b0028);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xf); */
pci_burst_data(32'h10000000, 4'h0, 32'hf);
pci_burst_data(32'h10000004, 4'h0, 32'hff0);
pci_burst_data(32'h10000008, 4'h0, 32'hff000);
pci_burst_data(32'h1000000c, 4'h0, 32'h1ff00000);
pci_burst_data(32'h10000010, 4'h0, 32'hf8000000);
pci_burst_data(32'h10000014, 4'h0, 32'h1e);
pci_burst_data(32'h10000018, 4'h0, 32'h3e78);
pci_burst_data(32'h1000001c, 4'h0, 32'h7c7c00);
pci_burst_data(32'h10000020, 4'h0, 32'hfc3e0000);
pci_burst_data(32'h10000024, 4'h0, 32'h3f000000);
pci_burst_data(32'h10000028, 4'h0, 32'h800001f8);
pci_burst_data(32'h1000002c, 4'h0, 32'h3f01f);
pci_burst_data(32'h10000030, 4'h0, 32'h7e00fc0);
pci_burst_data(32'h10000034, 4'h0, 32'hc007e000);
pci_burst_data(32'h10000038, 4'h0, 32'h3f8001f);
pci_burst_data(rbase_a+XY1,4'h0,32'h8b0034);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xf); */
pci_burst_data(32'h10000040, 4'h0, 32'hffffff80);
pci_burst_data(32'h10000044, 4'h0, 32'hffff0001);
pci_burst_data(32'h10000048, 4'h0, 32'hfc0000ff);
pci_burst_data(32'h1000004c, 4'h0, 32'h3fff);
pci_burst_data(32'h10000050, 4'h0, 32'hffff0);
pci_burst_data(32'h10000054, 4'h0, 32'h0);
pci_burst_data(32'h10000058, 4'h0, 32'h0);
pci_burst_data(32'h1000005c, 4'h0, 32'h0);
pci_burst_data(32'h10000060, 4'h0, 32'h0);
pci_burst_data(32'h10000064, 4'h0, 32'h0);
pci_burst_data(32'h10000068, 4'h0, 32'h0);
pci_burst_data(32'h1000006c, 4'h0, 32'h0);
pci_burst_data(32'h10000070, 4'h0, 32'h0);
pci_burst_data(32'h10000074, 4'h0, 32'h0);
pci_burst_data(32'h10000078, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h8b0040);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xf); */
pci_burst_data(32'h10000000, 4'h0, 32'h0);
pci_burst_data(32'h10000004, 4'h0, 32'h0);
pci_burst_data(32'h10000008, 4'h0, 32'h0);
pci_burst_data(32'h1000000c, 4'h0, 32'h0);
pci_burst_data(32'h10000010, 4'h0, 32'h0);
pci_burst_data(32'h10000014, 4'h0, 32'h0);
pci_burst_data(32'h10000018, 4'h0, 32'h0);
pci_burst_data(32'h1000001c, 4'h0, 32'h0);
pci_burst_data(32'h10000020, 4'h0, 32'h0);
pci_burst_data(32'h10000024, 4'h0, 32'h0);
pci_burst_data(32'h10000028, 4'h0, 32'h0);
pci_burst_data(32'h1000002c, 4'h0, 32'h0);
pci_burst_data(32'h10000030, 4'h0, 32'h0);
pci_burst_data(32'h10000034, 4'h0, 32'h0);
pci_burst_data(32'h10000038, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h8b004c);
/* Writing character 'K' */
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xd); */
pci_burst_data(32'h10000040, 4'h0, 32'h0);
pci_burst_data(32'h10000044, 4'h0, 32'h0);
pci_burst_data(32'h10000048, 4'h0, 32'hf0000);
pci_burst_data(32'h1000004c, 4'h0, 32'hffc0000);
pci_burst_data(32'h10000050, 4'h0, 32'hfe000000);
pci_burst_data(32'h10000054, 4'h0, 32'hf);
pci_burst_data(32'h10000058, 4'h0, 32'hfff);
pci_burst_data(32'h1000005c, 4'h0, 32'hfff80);
pci_burst_data(32'h10000060, 4'h0, 32'hff7c000);
pci_burst_data(32'h10000064, 4'h0, 32'hf3e00000);
pci_burst_data(32'h10000068, 4'h0, 32'hf000000f);
pci_burst_data(32'h1000006c, 4'h0, 32'hff1);
pci_burst_data(32'h10000070, 4'h0, 32'hf0f8);
pci_burst_data(rbase_a+XY2,4'h0,32'h24000a);
pci_burst_data(rbase_a+XY1,4'h0,32'hb70006);
wait_for_pipe_a;
pci_burst_data(rbase_a+XY2,4'h0,32'h24000c);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xf); */
pci_burst_data(32'h10000000, 4'h0, 32'h7c00000f);
pci_burst_data(32'h10000004, 4'h0, 32'hff0);
pci_burst_data(32'h10000008, 4'h0, 32'hff03e);
pci_burst_data(32'h1000000c, 4'h0, 32'hff01f00);
pci_burst_data(32'h10000010, 4'h0, 32'hf00f8000);
pci_burst_data(32'h10000014, 4'h0, 32'h7c0000f);
pci_burst_data(32'h10000018, 4'h0, 32'he0000ff0);
pci_burst_data(32'h1000001c, 4'h0, 32'hff003);
pci_burst_data(32'h10000020, 4'h0, 32'hff001f0);
pci_burst_data(32'h10000024, 4'h0, 32'hf000f800);
pci_burst_data(32'h10000028, 4'h0, 32'h7c000f);
pci_burst_data(32'h1000002c, 4'h0, 32'h3e000ff0);
pci_burst_data(32'h10000030, 4'h0, 32'hff000);
pci_burst_data(32'h10000034, 4'h0, 32'hff0001f);
pci_burst_data(32'h10000038, 4'h0, 32'hf0000f80);
pci_burst_data(rbase_a+XY1,4'h0,32'hb70010);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xf); */
pci_burst_data(32'h10000040, 4'h0, 32'h7c00f);
pci_burst_data(32'h10000044, 4'h0, 32'h3e00ff0);
pci_burst_data(32'h10000048, 4'h0, 32'hf00ff000);
pci_burst_data(32'h1000004c, 4'h0, 32'hff00001);
pci_burst_data(32'h10000050, 4'h0, 32'hf00000f8);
pci_burst_data(32'h10000054, 4'h0, 32'h7c0f);
pci_burst_data(32'h10000058, 4'h0, 32'h3e0ff0);
pci_burst_data(32'h1000005c, 4'h0, 32'h1f0ff000);
pci_burst_data(32'h10000060, 4'h0, 32'h8ff00000);
pci_burst_data(32'h10000064, 4'h0, 32'hf000000f);
pci_burst_data(32'h10000068, 4'h0, 32'h7cf);
pci_burst_data(32'h1000006c, 4'h0, 32'h3eff0);
pci_burst_data(32'h10000070, 4'h0, 32'h1fff000);
pci_burst_data(32'h10000074, 4'h0, 32'hfff00000);
pci_burst_data(32'h10000078, 4'h0, 32'hf0000001);
pci_burst_data(rbase_a+XY1,4'h0,32'hb7001c);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xf); */
pci_burst_data(32'h10000000, 4'h0, 32'h3ef);
pci_burst_data(32'h10000004, 4'h0, 32'h7cff0);
pci_burst_data(32'h10000008, 4'h0, 32'hf8ff000);
pci_burst_data(32'h1000000c, 4'h0, 32'hff00000);
pci_burst_data(32'h10000010, 4'h0, 32'hf000001f);
pci_burst_data(32'h10000014, 4'h0, 32'h3e0f);
pci_burst_data(32'h10000018, 4'h0, 32'h7c0ff0);
pci_burst_data(32'h1000001c, 4'h0, 32'hf80ff000);
pci_burst_data(32'h10000020, 4'h0, 32'hff00000);
pci_burst_data(32'h10000024, 4'h0, 32'hf00001f0);
pci_burst_data(32'h10000028, 4'h0, 32'h3e00f);
pci_burst_data(32'h1000002c, 4'h0, 32'h7c00ff0);
pci_burst_data(32'h10000030, 4'h0, 32'h800ff000);
pci_burst_data(32'h10000034, 4'h0, 32'hff0000f);
pci_burst_data(32'h10000038, 4'h0, 32'hf0001f00);
pci_burst_data(rbase_a+XY1,4'h0,32'hb70028);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xf); */
pci_burst_data(32'h10000040, 4'h0, 32'h3e000f);
pci_burst_data(32'h10000044, 4'h0, 32'h7c000ff0);
pci_burst_data(32'h10000048, 4'h0, 32'hff000);
pci_burst_data(32'h1000004c, 4'h0, 32'hff000f8);
pci_burst_data(32'h10000050, 4'h0, 32'hf001f000);
pci_burst_data(32'h10000054, 4'h0, 32'h3e0000f);
pci_burst_data(32'h10000058, 4'h0, 32'hc0000ff0);
pci_burst_data(32'h1000005c, 4'h0, 32'hff007);
pci_burst_data(32'h10000060, 4'h0, 32'hff00f80);
pci_burst_data(32'h10000064, 4'h0, 32'hf01f0000);
pci_burst_data(32'h10000068, 4'h0, 32'h3e00000f);
pci_burst_data(32'h1000006c, 4'h0, 32'hff0);
pci_burst_data(32'h10000070, 4'h0, 32'hff07c);
pci_burst_data(32'h10000074, 4'h0, 32'hff0f800);
pci_burst_data(32'h10000078, 4'h0, 32'hf1f00000);
pci_burst_data(rbase_a+XY1,4'h0,32'hb70034);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xf); */
pci_burst_data(32'h10000000, 4'h0, 32'he000000f);
pci_burst_data(32'h10000004, 4'h0, 32'hff3);
pci_burst_data(32'h10000008, 4'h0, 32'hff7c0);
pci_burst_data(32'h1000000c, 4'h0, 32'hfff8000);
pci_burst_data(32'h10000010, 4'h0, 32'hff000000);
pci_burst_data(32'h10000014, 4'h0, 32'h0);
pci_burst_data(32'h10000018, 4'h0, 32'h0);
pci_burst_data(32'h1000001c, 4'h0, 32'h0);
pci_burst_data(32'h10000020, 4'h0, 32'h0);
pci_burst_data(32'h10000024, 4'h0, 32'h0);
pci_burst_data(32'h10000028, 4'h0, 32'h0);
pci_burst_data(32'h1000002c, 4'h0, 32'h0);
pci_burst_data(32'h10000030, 4'h0, 32'h0);
pci_burst_data(32'h10000034, 4'h0, 32'h0);
pci_burst_data(32'h10000038, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'hb70040);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xf); */
pci_burst_data(32'h10000040, 4'h0, 32'h0);
pci_burst_data(32'h10000044, 4'h0, 32'h0);
pci_burst_data(32'h10000048, 4'h0, 32'h0);
pci_burst_data(32'h1000004c, 4'h0, 32'h0);
pci_burst_data(32'h10000050, 4'h0, 32'h0);
pci_burst_data(32'h10000054, 4'h0, 32'h0);
pci_burst_data(32'h10000058, 4'h0, 32'h0);
pci_burst_data(32'h1000005c, 4'h0, 32'h0);
pci_burst_data(32'h10000060, 4'h0, 32'h0);
pci_burst_data(32'h10000064, 4'h0, 32'h0);
pci_burst_data(32'h10000068, 4'h0, 32'h0);
pci_burst_data(32'h1000006c, 4'h0, 32'h0);
pci_burst_data(32'h10000070, 4'h0, 32'h0);
pci_burst_data(32'h10000074, 4'h0, 32'h0);
pci_burst_data(32'h10000078, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'hb7004c);
/* Writing character 'M' */
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0x3); */
pci_burst_data(32'h10000000, 4'h0, 32'h0);
pci_burst_data(32'h10000004, 4'h0, 32'h0);
pci_burst_data(32'h10000008, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h2c0002);
pci_burst_data(rbase_a+XY1,4'h0,32'hdf0006);
wait_for_pipe_a;
pci_burst_data(rbase_a+XY2,4'h0,32'h2c000a);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xf); */
pci_burst_data(32'h10000040, 4'h0, 32'h7);
pci_burst_data(32'h10000044, 4'h0, 32'hffe00);
pci_burst_data(32'h10000048, 4'h0, 32'hff000000);
pci_burst_data(32'h1000004c, 4'h0, 32'h1f);
pci_burst_data(32'h10000050, 4'h0, 32'h3fff80);
pci_burst_data(32'h10000054, 4'h0, 32'hffc00000);
pci_burst_data(32'h10000058, 4'h0, 32'h7f);
pci_burst_data(32'h1000005c, 4'h0, 32'hffffe0);
pci_burst_data(32'h10000060, 4'h0, 32'hfff00000);
pci_burst_data(32'h10000064, 4'h0, 32'h1ff);
pci_burst_data(32'h10000068, 4'h0, 32'h3effff8);
pci_burst_data(32'h1000006c, 4'h0, 32'hff7c0000);
pci_burst_data(32'h10000070, 4'h0, 32'h7cf);
pci_burst_data(32'h10000074, 4'h0, 32'hf8fff3e);
pci_burst_data(32'h10000078, 4'h0, 32'hff1f0000);
pci_burst_data(rbase_a+XY1,4'h0,32'hdf0008);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xf); */
pci_burst_data(32'h10000000, 4'h0, 32'h80001f0f);
pci_burst_data(32'h10000004, 4'h0, 32'h3e0fff0f);
pci_burst_data(32'h10000008, 4'h0, 32'hff07c000);
pci_burst_data(32'h1000000c, 4'h0, 32'he0007c0f);
pci_burst_data(32'h10000010, 4'h0, 32'hf80fff03);
pci_burst_data(32'h10000014, 4'h0, 32'hff01f000);
pci_burst_data(32'h10000018, 4'h0, 32'hf801f00f);
pci_burst_data(32'h1000001c, 4'h0, 32'he00fff00);
pci_burst_data(32'h10000020, 4'h0, 32'hff007c03);
pci_burst_data(32'h10000024, 4'h0, 32'h3e07c00f);
pci_burst_data(32'h10000028, 4'h0, 32'h800fff00);
pci_burst_data(32'h1000002c, 4'h0, 32'hff001f0f);
pci_burst_data(32'h10000030, 4'h0, 32'hf9f000f);
pci_burst_data(32'h10000034, 4'h0, 32'hfff00);
pci_burst_data(32'h10000038, 4'h0, 32'hff0007fe);
pci_burst_data(rbase_a+XY1,4'h0,32'hdf0012);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xf); */
pci_burst_data(32'h10000040, 4'h0, 32'h3fc000f);
pci_burst_data(32'h10000044, 4'h0, 32'hfff00);
pci_burst_data(32'h10000048, 4'h0, 32'hff0001f8);
pci_burst_data(32'h1000004c, 4'h0, 32'hf0000f);
pci_burst_data(32'h10000050, 4'h0, 32'hfff00);
pci_burst_data(32'h10000054, 4'h0, 32'hff000060);
pci_burst_data(32'h10000058, 4'h0, 32'hf);
pci_burst_data(32'h1000005c, 4'h0, 32'hfff00);
pci_burst_data(32'h10000060, 4'h0, 32'hff000000);
pci_burst_data(32'h10000064, 4'h0, 32'hf);
pci_burst_data(32'h10000068, 4'h0, 32'hfff00);
pci_burst_data(32'h1000006c, 4'h0, 32'hff000000);
pci_burst_data(32'h10000070, 4'h0, 32'hf);
pci_burst_data(32'h10000074, 4'h0, 32'hfff00);
pci_burst_data(32'h10000078, 4'h0, 32'hff000000);
pci_burst_data(rbase_a+XY1,4'h0,32'hdf001c);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xf); */
pci_burst_data(32'h10000000, 4'h0, 32'hf);
pci_burst_data(32'h10000004, 4'h0, 32'hfff00);
pci_burst_data(32'h10000008, 4'h0, 32'hff000000);
pci_burst_data(32'h1000000c, 4'h0, 32'hf);
pci_burst_data(32'h10000010, 4'h0, 32'hfff00);
pci_burst_data(32'h10000014, 4'h0, 32'hff000000);
pci_burst_data(32'h10000018, 4'h0, 32'hf);
pci_burst_data(32'h1000001c, 4'h0, 32'hfff00);
pci_burst_data(32'h10000020, 4'h0, 32'hff000000);
pci_burst_data(32'h10000024, 4'h0, 32'hf);
pci_burst_data(32'h10000028, 4'h0, 32'hfff00);
pci_burst_data(32'h1000002c, 4'h0, 32'hff000000);
pci_burst_data(32'h10000030, 4'h0, 32'hf);
pci_burst_data(32'h10000034, 4'h0, 32'hfff00);
pci_burst_data(32'h10000038, 4'h0, 32'hff000000);
pci_burst_data(rbase_a+XY1,4'h0,32'hdf0026);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xf); */
pci_burst_data(32'h10000040, 4'h0, 32'hf);
pci_burst_data(32'h10000044, 4'h0, 32'hfff00);
pci_burst_data(32'h10000048, 4'h0, 32'hff000000);
pci_burst_data(32'h1000004c, 4'h0, 32'hf);
pci_burst_data(32'h10000050, 4'h0, 32'hfff00);
pci_burst_data(32'h10000054, 4'h0, 32'hff000000);
pci_burst_data(32'h10000058, 4'h0, 32'hf);
pci_burst_data(32'h1000005c, 4'h0, 32'hfff00);
pci_burst_data(32'h10000060, 4'h0, 32'hff000000);
pci_burst_data(32'h10000064, 4'h0, 32'hf);
pci_burst_data(32'h10000068, 4'h0, 32'hfff00);
pci_burst_data(32'h1000006c, 4'h0, 32'hff000000);
pci_burst_data(32'h10000070, 4'h0, 32'hf);
pci_burst_data(32'h10000074, 4'h0, 32'hfff00);
pci_burst_data(32'h10000078, 4'h0, 32'hff000000);
pci_burst_data(rbase_a+XY1,4'h0,32'hdf0030);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xf); */
pci_burst_data(32'h10000000, 4'h0, 32'hf);
pci_burst_data(32'h10000004, 4'h0, 32'hfff00);
pci_burst_data(32'h10000008, 4'h0, 32'hff000000);
pci_burst_data(32'h1000000c, 4'h0, 32'hf);
pci_burst_data(32'h10000010, 4'h0, 32'hfff00);
pci_burst_data(32'h10000014, 4'h0, 32'hff000000);
pci_burst_data(32'h10000018, 4'h0, 32'hf);
pci_burst_data(32'h1000001c, 4'h0, 32'hfff00);
pci_burst_data(32'h10000020, 4'h0, 32'hff000000);
pci_burst_data(32'h10000024, 4'h0, 32'hf);
pci_burst_data(32'h10000028, 4'h0, 32'hfff00);
pci_burst_data(32'h1000002c, 4'h0, 32'hff000000);
pci_burst_data(32'h10000030, 4'h0, 32'hf);
pci_burst_data(32'h10000034, 4'h0, 32'hfff00);
pci_burst_data(32'h10000038, 4'h0, 32'hff000000);
pci_burst_data(rbase_a+XY1,4'h0,32'hdf003a);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xf); */
pci_burst_data(32'h10000040, 4'h0, 32'h0);
pci_burst_data(32'h10000044, 4'h0, 32'h0);
pci_burst_data(32'h10000048, 4'h0, 32'h0);
pci_burst_data(32'h1000004c, 4'h0, 32'h0);
pci_burst_data(32'h10000050, 4'h0, 32'h0);
pci_burst_data(32'h10000054, 4'h0, 32'h0);
pci_burst_data(32'h10000058, 4'h0, 32'h0);
pci_burst_data(32'h1000005c, 4'h0, 32'h0);
pci_burst_data(32'h10000060, 4'h0, 32'h0);
pci_burst_data(32'h10000064, 4'h0, 32'h0);
pci_burst_data(32'h10000068, 4'h0, 32'h0);
pci_burst_data(32'h1000006c, 4'h0, 32'h0);
pci_burst_data(32'h10000070, 4'h0, 32'h0);
pci_burst_data(32'h10000074, 4'h0, 32'h0);
pci_burst_data(32'h10000078, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'hdf0044);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xf); */
pci_burst_data(32'h10000000, 4'h0, 32'h0);
pci_burst_data(32'h10000004, 4'h0, 32'h0);
pci_burst_data(32'h10000008, 4'h0, 32'h0);
pci_burst_data(32'h1000000c, 4'h0, 32'h0);
pci_burst_data(32'h10000010, 4'h0, 32'h0);
pci_burst_data(32'h10000014, 4'h0, 32'h0);
pci_burst_data(32'h10000018, 4'h0, 32'h0);
pci_burst_data(32'h1000001c, 4'h0, 32'h0);
pci_burst_data(32'h10000020, 4'h0, 32'h0);
pci_burst_data(32'h10000024, 4'h0, 32'h0);
pci_burst_data(32'h10000028, 4'h0, 32'h0);
pci_burst_data(32'h1000002c, 4'h0, 32'h0);
pci_burst_data(32'h10000030, 4'h0, 32'h0);
pci_burst_data(32'h10000034, 4'h0, 32'h0);
pci_burst_data(32'h10000038, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'hdf004e);
/* Writing character 'Q' */
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0x3); */
pci_burst_data(32'h10000040, 4'h0, 32'h0);
pci_burst_data(32'h10000044, 4'h0, 32'h0);
pci_burst_data(32'h10000048, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h2c0002);
pci_burst_data(rbase_a+XY1,4'h0,32'h10f0006);
wait_for_pipe_a;
pci_burst_data(rbase_a+XY2,4'h0,32'h2c000a);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xf); */
pci_burst_data(32'h10000000, 4'h0, 32'hffff000);
pci_burst_data(32'h10000004, 4'h0, 32'hfc00f000);
pci_burst_data(32'h10000008, 4'h0, 32'hf0003fff);
pci_burst_data(32'h1000000c, 4'h0, 32'hffffff00);
pci_burst_data(32'h10000010, 4'h0, 32'hff80f000);
pci_burst_data(32'h10000014, 4'h0, 32'hf001ffff);
pci_burst_data(32'h10000018, 4'h0, 32'hf8001fc0);
pci_burst_data(32'h1000001c, 4'h0, 32'h7e0f003);
pci_burst_data(32'h10000020, 4'h0, 32'hf007e000);
pci_burst_data(32'h10000024, 4'h0, 32'hc00003f0);
pci_burst_data(32'h10000028, 4'h0, 32'h1f8f00f);
pci_burst_data(32'h1000002c, 4'h0, 32'hf01f8000);
pci_burst_data(32'h10000030, 4'h0, 32'hfc);
pci_burst_data(32'h10000034, 4'h0, 32'h7cf03f);
pci_burst_data(32'h10000038, 4'h0, 32'hf03e0000);
pci_burst_data(rbase_a+XY1,4'h0,32'h10f0008);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xf); */
pci_burst_data(32'h10000040, 4'h0, 32'h3e);
pci_burst_data(32'h10000044, 4'h0, 32'h1ef07c);
pci_burst_data(32'h10000048, 4'h0, 32'hf0780000);
pci_burst_data(32'h1000004c, 4'h0, 32'h1f);
pci_burst_data(32'h10000050, 4'h0, 32'hff0f8);
pci_burst_data(32'h10000054, 4'h0, 32'hf0f00000);
pci_burst_data(32'h10000058, 4'h0, 32'hf);
pci_burst_data(32'h1000005c, 4'h0, 32'hff0f0);
pci_burst_data(32'h10000060, 4'h0, 32'hf0f00000);
pci_burst_data(32'h10000064, 4'h0, 32'hf);
pci_burst_data(32'h10000068, 4'h0, 32'hff0f0);
pci_burst_data(32'h1000006c, 4'h0, 32'hf0f00000);
pci_burst_data(32'h10000070, 4'h0, 32'hf);
pci_burst_data(32'h10000074, 4'h0, 32'hff0f0);
pci_burst_data(32'h10000078, 4'h0, 32'hf0f00000);
pci_burst_data(rbase_a+XY1,4'h0,32'h10f0012);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xf); */
pci_burst_data(32'h10000000, 4'h0, 32'hf);
pci_burst_data(32'h10000004, 4'h0, 32'hff0f0);
pci_burst_data(32'h10000008, 4'h0, 32'hf0f00000);
pci_burst_data(32'h1000000c, 4'h0, 32'hf);
pci_burst_data(32'h10000010, 4'h0, 32'hff0f0);
pci_burst_data(32'h10000014, 4'h0, 32'hf0f00000);
pci_burst_data(32'h10000018, 4'h0, 32'hf);
pci_burst_data(32'h1000001c, 4'h0, 32'hff0f0);
pci_burst_data(32'h10000020, 4'h0, 32'hf0f00000);
pci_burst_data(32'h10000024, 4'h0, 32'hf);
pci_burst_data(32'h10000028, 4'h0, 32'hff0f0);
pci_burst_data(32'h1000002c, 4'h0, 32'hf0f00000);
pci_burst_data(32'h10000030, 4'h0, 32'hf);
pci_burst_data(32'h10000034, 4'h0, 32'hff0f0);
pci_burst_data(32'h10000038, 4'h0, 32'hf0f00000);
pci_burst_data(rbase_a+XY1,4'h0,32'h10f001c);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xf); */
pci_burst_data(32'h10000040, 4'h0, 32'hf);
pci_burst_data(32'h10000044, 4'h0, 32'hff0f0);
pci_burst_data(32'h10000048, 4'h0, 32'hf0f00000);
pci_burst_data(32'h1000004c, 4'h0, 32'hf);
pci_burst_data(32'h10000050, 4'h0, 32'hff0f0);
pci_burst_data(32'h10000054, 4'h0, 32'hf0f00000);
pci_burst_data(32'h10000058, 4'h0, 32'hf);
pci_burst_data(32'h1000005c, 4'h0, 32'hff0f0);
pci_burst_data(32'h10000060, 4'h0, 32'hf0f00000);
pci_burst_data(32'h10000064, 4'h0, 32'hf);
pci_burst_data(32'h10000068, 4'h0, 32'hff0f0);
pci_burst_data(32'h1000006c, 4'h0, 32'hf0f00000);
pci_burst_data(32'h10000070, 4'h0, 32'hf);
pci_burst_data(32'h10000074, 4'h0, 32'hff0f0);
pci_burst_data(32'h10000078, 4'h0, 32'hf0f00000);
pci_burst_data(rbase_a+XY1,4'h0,32'h10f0026);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xf); */
pci_burst_data(32'h10000000, 4'h0, 32'hf00000f);
pci_burst_data(32'h10000004, 4'h0, 32'hff0f0);
pci_burst_data(32'h10000008, 4'h0, 32'hf0f01f00);
pci_burst_data(32'h1000000c, 4'h0, 32'h3e00000f);
pci_burst_data(32'h10000010, 4'h0, 32'hff0f0);
pci_burst_data(32'h10000014, 4'h0, 32'hf0f07c00);
pci_burst_data(32'h10000018, 4'h0, 32'hf800000f);
pci_burst_data(32'h1000001c, 4'h0, 32'hff0f0);
pci_burst_data(32'h10000020, 4'h0, 32'hf0f1f000);
pci_burst_data(32'h10000024, 4'h0, 32'he000000f);
pci_burst_data(32'h10000028, 4'h0, 32'h1ff0fb);
pci_burst_data(32'h1000002c, 4'h0, 32'hf0ffc000);
pci_burst_data(32'h10000030, 4'h0, 32'h8000001e);
pci_burst_data(32'h10000034, 4'h0, 32'h3ef07f);
pci_burst_data(32'h10000038, 4'h0, 32'hf07f0000);
pci_burst_data(rbase_a+XY1,4'h0,32'h10f0030);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xf); */
pci_burst_data(32'h10000040, 4'h0, 32'h7c);
pci_burst_data(32'h10000044, 4'h0, 32'hfcf03e);
pci_burst_data(32'h10000048, 4'h0, 32'hf07f0000);
pci_burst_data(32'h1000004c, 4'h0, 32'h800001f8);
pci_burst_data(32'h10000050, 4'h0, 32'h3f0f0ff);
pci_burst_data(32'h10000054, 4'h0, 32'hf1ffc000);
pci_burst_data(32'h10000058, 4'h0, 32'he00007e0);
pci_burst_data(32'h1000005c, 4'h0, 32'h1fc0f3e7);
pci_burst_data(32'h10000060, 4'h0, 32'hf7c3f800);
pci_burst_data(32'h10000064, 4'h0, 32'hffffff80);
pci_burst_data(32'h10000068, 4'h0, 32'hff00ff81);
pci_burst_data(32'h1000006c, 4'h0, 32'hff00ffff);
pci_burst_data(32'h10000070, 4'h0, 32'h3ffffc00);
pci_burst_data(32'h10000074, 4'h0, 32'hf000fe00);
pci_burst_data(32'h10000078, 4'h0, 32'hfc000fff);
pci_burst_data(rbase_a+XY1,4'h0,32'h10f003a);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* bbird_set_cache(hostbitmap, 0x0, 0xf); */
pci_burst_data(32'h10000000, 4'h0, 32'h0);
pci_burst_data(32'h10000004, 4'h0, 32'h0);
pci_burst_data(32'h10000008, 4'h0, 32'h0);
pci_burst_data(32'h1000000c, 4'h0, 32'h0);
pci_burst_data(32'h10000010, 4'h0, 32'h0);
pci_burst_data(32'h10000014, 4'h0, 32'h0);
pci_burst_data(32'h10000018, 4'h0, 32'h0);
pci_burst_data(32'h1000001c, 4'h0, 32'h0);
pci_burst_data(32'h10000020, 4'h0, 32'h0);
pci_burst_data(32'h10000024, 4'h0, 32'h0);
pci_burst_data(32'h10000028, 4'h0, 32'h0);
pci_burst_data(32'h1000002c, 4'h0, 32'h0);
pci_burst_data(32'h10000030, 4'h0, 32'h0);
pci_burst_data(32'h10000034, 4'h0, 32'h0);
pci_burst_data(32'h10000038, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10f0044);
/* bbird_engine_wait(BBIRD_WAIT_PREVIOUS); */
wait_for_prev_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h400000);
/* bbird_set_cache(hostbitmap, 0x10, 0xf); */
pci_burst_data(32'h10000040, 4'h0, 32'h0);
pci_burst_data(32'h10000044, 4'h0, 32'h0);
pci_burst_data(32'h10000048, 4'h0, 32'h0);
pci_burst_data(32'h1000004c, 4'h0, 32'h0);
pci_burst_data(32'h10000050, 4'h0, 32'h0);
pci_burst_data(32'h10000054, 4'h0, 32'h0);
pci_burst_data(32'h10000058, 4'h0, 32'h0);
pci_burst_data(32'h1000005c, 4'h0, 32'h0);
pci_burst_data(32'h10000060, 4'h0, 32'h0);
pci_burst_data(32'h10000064, 4'h0, 32'h0);
pci_burst_data(32'h10000068, 4'h0, 32'h0);
pci_burst_data(32'h1000006c, 4'h0, 32'h0);
pci_burst_data(32'h10000070, 4'h0, 32'h0);
pci_burst_data(32'h10000074, 4'h0, 32'h0);
pci_burst_data(32'h10000078, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h10f004e);
wait_for_pipe_a;
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'h4e0c01);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h120, 32'h60, "junk", 32'h600, 2'h2);
