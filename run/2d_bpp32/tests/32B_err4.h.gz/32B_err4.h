///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2014 Francis Bruno, All Rights Reserved
// 
//  This program is free software; you can redistribute it and/or modify it 
//  under the terms of the GNU General Public License as published by the Free 
//  Software Foundation; either version 3 of the License, or (at your option) 
//  any later version.
//
//  This program is distributed in the hope that it will be useful, but 
//  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
//  or FITNESS FOR A PARTICULAR PURPOSE. 
//  See the GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License along with
//  this program; if not, see <http://www.gnu.org/licenses>.
//
//  This code is available under licenses for commercial use. Please contact
//  Francis Bruno for more information.
//
//  http://www.gplgpu.com
//  http://www.asicsolutions.com
//
//  Title       :  
//  File        :  
//  Author      :  Frank Bruno
//  Created     :  14-May-2011
//  RCS File    :  $Source:$
//  Status      :  $Id:$
//
///////////////////////////////////////////////////////////////////////////////
//
//  Description : 
//  2D test suite - 32 Bpp
//
//////////////////////////////////////////////////////////////////////////////
//
//  Modules Instantiated:
//
///////////////////////////////////////////////////////////////////////////////
//
//  Modification History:
//
//  $Log:$
//
//
///////////////////////////////////////////////////////////////////////////////
/* VERILOG logging on. */
/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'h600);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0x600, 0x2000000); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'h600);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x600, 0x2000000, 0, 0, 79, 79); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h600);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h4f004f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 80, 0);
VR.ram_fill32(32'h180, 80, 0);
VR.ram_fill32(32'h300, 80, 0);
VR.ram_fill32(32'h480, 80, 0);
VR.ram_fill32(32'h600, 80, 0);
VR.ram_fill32(32'h780, 80, 0);
VR.ram_fill32(32'h900, 80, 0);
VR.ram_fill32(32'ha80, 80, 0);
VR.ram_fill32(32'hc00, 80, 0);
VR.ram_fill32(32'hd80, 80, 0);
VR.ram_fill32(32'hf00, 80, 0);
VR.ram_fill32(32'h1080, 80, 0);
VR.ram_fill32(32'h1200, 80, 0);
VR.ram_fill32(32'h1380, 80, 0);
VR.ram_fill32(32'h1500, 80, 0);
VR.ram_fill32(32'h1680, 80, 0);
VR.ram_fill32(32'h1800, 80, 0);
VR.ram_fill32(32'h1980, 80, 0);
VR.ram_fill32(32'h1b00, 80, 0);
VR.ram_fill32(32'h1c80, 80, 0);
VR.ram_fill32(32'h1e00, 80, 0);
VR.ram_fill32(32'h1f80, 80, 0);
VR.ram_fill32(32'h2100, 80, 0);
VR.ram_fill32(32'h2280, 80, 0);
VR.ram_fill32(32'h2400, 80, 0);
VR.ram_fill32(32'h2580, 80, 0);
VR.ram_fill32(32'h2700, 80, 0);
VR.ram_fill32(32'h2880, 80, 0);
VR.ram_fill32(32'h2a00, 80, 0);
VR.ram_fill32(32'h2b80, 80, 0);
VR.ram_fill32(32'h2d00, 80, 0);
VR.ram_fill32(32'h2e80, 80, 0);
VR.ram_fill32(32'h3000, 80, 0);
VR.ram_fill32(32'h3180, 80, 0);
VR.ram_fill32(32'h3300, 80, 0);
VR.ram_fill32(32'h3480, 80, 0);
VR.ram_fill32(32'h3600, 80, 0);
VR.ram_fill32(32'h3780, 80, 0);
VR.ram_fill32(32'h3900, 80, 0);
VR.ram_fill32(32'h3a80, 80, 0);
VR.ram_fill32(32'h3c00, 80, 0);
VR.ram_fill32(32'h3d80, 80, 0);
VR.ram_fill32(32'h3f00, 80, 0);
VR.ram_fill32(32'h4080, 80, 0);
VR.ram_fill32(32'h4200, 80, 0);
VR.ram_fill32(32'h4380, 80, 0);
VR.ram_fill32(32'h4500, 80, 0);
VR.ram_fill32(32'h4680, 80, 0);
VR.ram_fill32(32'h4800, 80, 0);
VR.ram_fill32(32'h4980, 80, 0);
VR.ram_fill32(32'h4b00, 80, 0);
VR.ram_fill32(32'h4c80, 80, 0);
VR.ram_fill32(32'h4e00, 80, 0);
VR.ram_fill32(32'h4f80, 80, 0);
VR.ram_fill32(32'h5100, 80, 0);
VR.ram_fill32(32'h5280, 80, 0);
VR.ram_fill32(32'h5400, 80, 0);
VR.ram_fill32(32'h5580, 80, 0);
VR.ram_fill32(32'h5700, 80, 0);
VR.ram_fill32(32'h5880, 80, 0);
VR.ram_fill32(32'h5a00, 80, 0);
VR.ram_fill32(32'h5b80, 80, 0);
VR.ram_fill32(32'h5d00, 80, 0);
VR.ram_fill32(32'h5e80, 80, 0);
VR.ram_fill32(32'h6000, 80, 0);
VR.ram_fill32(32'h6180, 80, 0);
VR.ram_fill32(32'h6300, 80, 0);
VR.ram_fill32(32'h6480, 80, 0);
VR.ram_fill32(32'h6600, 80, 0);
VR.ram_fill32(32'h6780, 80, 0);
VR.ram_fill32(32'h6900, 80, 0);
VR.ram_fill32(32'h6a80, 80, 0);
VR.ram_fill32(32'h6c00, 80, 0);
VR.ram_fill32(32'h6d80, 80, 0);
VR.ram_fill32(32'h6f00, 80, 0);
VR.ram_fill32(32'h7080, 80, 0);
VR.ram_fill32(32'h7200, 80, 0);
VR.ram_fill32(32'h7380, 80, 0);
VR.ram_fill32(32'h7500, 80, 0);
VR.ram_fill32(32'h7680, 80, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x600, 0x2000000, 0, 0, 79, 79); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h600);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h4f004f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0xc00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'hc00);
/* bbird_bitmap_write(0x800ff04, 0xffff, 0x0, 0x0, 0x0, 0x50, 0x20, 0xbc, 0x1); */
wait_for_pipe_a;
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h42000300+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'hc01);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h200001);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ff04, 0xffff, 0x20, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h20407efc);
pci_burst_data(32'h10000004, 4'h0, 32'h80070090);
pci_burst_data(32'h10000008, 4'h0, 32'hc6000023);
pci_burst_data(32'h1000000c, 4'h0, 32'hb89841c1);
pci_burst_data(32'h10000010, 4'h0, 32'h660701);
pci_burst_data(32'h10000014, 4'h0, 32'h47039f15);
pci_burst_data(32'h10000018, 4'h0, 32'h7bdcc68c);
pci_burst_data(32'h1000001c, 4'h0, 32'h71b000cc);
pci_burst_data(32'h10000020, 4'h0, 32'h66064d0e);
pci_burst_data(32'h10000024, 4'h0, 32'h18f8e73);
pci_burst_data(32'h10000028, 4'h0, 32'h4b39c418);
pci_burst_data(32'h1000002c, 4'h0, 32'h40c2302);
pci_burst_data(32'h10000030, 4'h0, 32'h80c031e);
pci_burst_data(32'h10000034, 4'h0, 32'h3008efc7);
pci_burst_data(32'h10000038, 4'h0, 32'h21c0706);
pci_burst_data(32'h1000003c, 4'h0, 32'hae183006);
pci_burst_data(32'h10000040, 4'h0, 32'h783f98c8);
pci_burst_data(32'h10000044, 4'h0, 32'h20020620);
pci_burst_data(32'h10000048, 4'h0, 32'h1dc4a060);
pci_burst_data(32'h1000004c, 4'h0, 32'h441ffc0);
pci_burst_data(32'h10000050, 4'h0, 32'ha18063fa);
pci_burst_data(32'h10000054, 4'h0, 32'h84003da4);
pci_burst_data(32'h10000058, 4'h0, 32'h60f04bf);
pci_burst_data(32'h1000005c, 4'h0, 32'h6b34a1fc);
pci_burst_data(32'h10000060, 4'h0, 32'h5c91c01);
pci_burst_data(32'h10000064, 4'h0, 32'hbe06c706);
pci_burst_data(32'h10000068, 4'h0, 32'h30431e11);
pci_burst_data(32'h1000006c, 4'h0, 32'h61c30591);
pci_burst_data(32'h10000070, 4'h0, 32'h301b3002);
pci_burst_data(32'h10000074, 4'h0, 32'h1120cc);
pci_burst_data(32'h10000078, 4'h0, 32'h20033cc1);
pci_burst_data(32'h1000007c, 4'h0, 32'h60e8000a);
pci_burst_data(rbase_a+XY1,4'h0,32'h50);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h200001);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ff84, 0xffff, 0x20, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h1b610021);
pci_burst_data(32'h10000004, 4'h0, 32'hf00863c1);
pci_burst_data(32'h10000008, 4'h0, 32'h321c7c6);
pci_burst_data(32'h1000000c, 4'h0, 32'hcfe108f8);
pci_burst_data(32'h10000010, 4'h0, 32'h994dfc0a);
pci_burst_data(32'h10000014, 4'h0, 32'hc3c0743);
pci_burst_data(32'h10000018, 4'h0, 32'hfc0b9ff1);
pci_burst_data(32'h1000001c, 4'h0, 32'h247815b);
pci_burst_data(32'h10000020, 4'h0, 32'h1c310416);
pci_burst_data(32'h10000024, 4'h0, 32'h89171f0b);
pci_burst_data(32'h10000028, 4'h0, 32'h41a064d);
pci_burst_data(32'h1000002c, 4'h0, 32'h7023831);
pci_burst_data(32'h10000030, 4'h0, 32'h4498956);
pci_burst_data(32'h10000034, 4'h0, 32'h72b1040b);
pci_burst_data(32'h10000038, 4'h0, 32'h9a54a182);
pci_burst_data(32'h1000003c, 4'h0, 32'h661d0449);
pci_burst_data(32'h10000040, 4'h0, 32'hf0c2e750);
pci_burst_data(32'h10000044, 4'h0, 32'h4589a54);
pci_burst_data(32'h10000048, 4'h0, 32'h1fc1620d);
pci_burst_data(32'h1000004c, 4'h0, 32'h9051fc44);
pci_burst_data(32'h10000050, 4'h0, 32'h63860490);
pci_burst_data(32'h10000054, 4'h0, 32'hef0474e0);
pci_burst_data(32'h10000058, 4'h0, 32'h911a31);
pci_burst_data(32'h1000005c, 4'h0, 32'hfdc1e202);
pci_burst_data(32'h10000060, 4'h0, 32'ha30f984);
pci_burst_data(32'h10000064, 4'h0, 32'ha9820091);
pci_burst_data(32'h10000068, 4'h0, 32'hf984b9c0);
pci_burst_data(32'h1000006c, 4'h0, 32'h811631);
pci_burst_data(32'h10000070, 4'h0, 32'h7fdba942);
pci_burst_data(32'h10000074, 4'h0, 32'h161cff0c);
pci_burst_data(32'h10000078, 4'h0, 32'h28020011);
pci_burst_data(32'h1000007c, 4'h0, 32'h6008070b);
pci_burst_data(rbase_a+XY1,4'h0,32'h200050);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h200001);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x8010004, 0xffff, 0x20, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h91021c);
pci_burst_data(32'h10000004, 4'h0, 32'he2946);
pci_burst_data(32'h10000008, 4'h0, 32'h16100000);
pci_burst_data(32'h1000000c, 4'h0, 32'h29060211);
pci_burst_data(32'h10000010, 4'h0, 32'h4);
pci_burst_data(32'h10000014, 4'h0, 32'h6911610);
pci_burst_data(32'h10000018, 4'h0, 32'h42aa6);
pci_burst_data(32'h1000001c, 4'h0, 32'h24180000);
pci_burst_data(32'h10000020, 4'h0, 32'h2a860491);
pci_burst_data(32'h10000024, 4'h0, 32'h4);
pci_burst_data(32'h10000028, 4'h0, 32'h4932718);
pci_burst_data(32'h1000002c, 4'h0, 32'h44a96);
pci_burst_data(32'h10000030, 4'h0, 32'h2040000);
pci_burst_data(32'h10000034, 4'h0, 32'h4a860491);
pci_burst_data(32'h10000038, 4'h0, 32'hc);
pci_burst_data(32'h1000003c, 4'h0, 32'h493231e);
pci_burst_data(32'h10000040, 4'h0, 32'h88856);
pci_burst_data(32'h10000044, 4'h0, 32'h21900000);
pci_burst_data(32'h10000048, 4'h0, 32'ha520493);
pci_burst_data(32'h1000004c, 4'h0, 32'h18009);
pci_burst_data(32'h10000050, 4'h0, 32'h49521d0);
pci_burst_data(32'h10000054, 4'h0, 32'h800f0a57);
pci_burst_data(32'h10000058, 4'h0, 32'h20d80027);
pci_burst_data(32'h1000005c, 4'h0, 32'h85d049d);
pci_burst_data(32'h10000060, 4'h0, 32'h67801c);
pci_burst_data(32'h10000064, 4'h0, 32'h48501e4);
pci_burst_data(32'h10000068, 4'h0, 32'h3f8a79);
pci_burst_data(32'h1000006c, 4'h0, 32'h11f40000);
pci_burst_data(32'h10000070, 4'h0, 32'h8390685);
pci_burst_data(32'h10000074, 4'h0, 32'h1800007d);
pci_burst_data(32'h10000078, 4'h0, 32'h38110b7);
pci_burst_data(32'h1000007c, 4'h0, 32'hcb1229);
pci_burst_data(rbase_a+XY1,4'h0,32'h400050);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h200001);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x8010084, 0xffff, 0x20, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h28307e);
pci_burst_data(32'h10000004, 4'h0, 32'h10290385);
pci_burst_data(32'h10000008, 4'h0, 32'h27ff81be);
pci_burst_data(32'h1000000c, 4'h0, 32'h385100c);
pci_burst_data(32'h10000010, 4'h0, 32'hc1fa3229);
pci_burst_data(32'h10000014, 4'h0, 32'h119427ff);
pci_burst_data(32'h10000018, 4'h0, 32'h20280385);
pci_burst_data(32'h1000001c, 4'h0, 32'h7ffe16c);
pci_burst_data(32'h10000020, 4'h0, 32'h185010c);
pci_burst_data(32'h10000024, 4'h0, 32'he35c6228);
pci_burst_data(32'h10000028, 4'h0, 32'h914e038f);
pci_burst_data(32'h1000002c, 4'h0, 32'h40390580);
pci_burst_data(32'h10000030, 4'h0, 32'hffc2f4);
pci_burst_data(32'h10000034, 4'h0, 32'h584919f);
pci_burst_data(32'h10000038, 4'h0, 32'h7e8c631);
pci_burst_data(32'h1000003c, 4'h0, 32'hcd807f);
pci_burst_data(32'h10000040, 4'h0, 32'h63104c4);
pci_burst_data(32'h10000044, 4'h0, 32'hc0000ec9);
pci_burst_data(32'h10000048, 4'h0, 32'h4e08848);
pci_burst_data(32'h1000004c, 4'h0, 32'h12db0479);
pci_burst_data(32'h10000050, 4'h0, 32'hc80c3000);
pci_burst_data(32'h10000054, 4'h0, 32'h66d04e4);
pci_burst_data(32'h10000058, 4'h0, 32'h180023b6);
pci_burst_data(32'h1000005c, 4'h0, 32'h484c01c);
pci_burst_data(32'h10000060, 4'h0, 32'hc2ff0c25);
pci_burst_data(32'h10000064, 4'h0, 32'hb0064e00);
pci_burst_data(32'h10000068, 4'h0, 32'h8a3f0480);
pci_burst_data(32'h1000006c, 4'h0, 32'hc3ff83b3);
pci_burst_data(32'h10000070, 4'h0, 32'h4849103);
pci_burst_data(32'h10000074, 4'h0, 32'h3f0fd82e);
pci_burst_data(32'h10000078, 4'h0, 32'h835f0000);
pci_burst_data(32'h1000007c, 4'h0, 32'h702a0484);
pci_burst_data(rbase_a+XY1,4'h0,32'h600050);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h200001);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x8010104, 0xffff, 0x20, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h7ffd);
pci_burst_data(32'h10000004, 4'h0, 32'h484c0c8);
pci_burst_data(32'h10000008, 4'h0, 32'h12fe24b);
pci_burst_data(32'h1000000c, 4'h0, 32'h60580800);
pci_burst_data(32'h10000010, 4'h0, 32'h825b0480);
pci_burst_data(32'h10000014, 4'h0, 32'h80001ff);
pci_burst_data(32'h10000018, 4'h0, 32'h484a0d0);
pci_burst_data(32'h1000001c, 4'h0, 32'he58072);
pci_burst_data(32'h10000020, 4'h0, 32'h20d20800);
pci_burst_data(32'h10000024, 4'h0, 32'h2ca0444);
pci_burst_data(32'h10000028, 4'h0, 32'h80000ff);
pci_burst_data(32'h1000002c, 4'h0, 32'h444a0de);
pci_burst_data(32'h10000030, 4'h0, 32'h6d0282);
pci_burst_data(32'h10000034, 4'h0, 32'hb0f60800);
pci_burst_data(32'h10000038, 4'h0, 32'h7820240);
pci_burst_data(32'h1000003c, 4'h0, 32'h800003f);
pci_burst_data(32'h10000040, 4'h0, 32'h2445844);
pci_burst_data(32'h10000044, 4'h0, 32'h1f3f93);
pci_burst_data(32'h10000048, 4'h0, 32'h4f883000);
pci_burst_data(32'h1000004c, 4'h0, 32'h23830344);
pci_burst_data(32'h10000050, 4'h0, 32'h3e);
pci_burst_data(32'h10000054, 4'h0, 32'h7e06018);
pci_burst_data(32'h10000058, 4'h0, 32'hfe0fe3);
pci_burst_data(32'h1000005c, 4'h0, 32'h70700000);
pci_burst_data(32'h10000060, 4'h0, 32'h1bc707e4);
pci_burst_data(32'h10000064, 4'h0, 32'h1fe);
pci_burst_data(32'h10000068, 4'h0, 32'h7e43ce0);
pci_burst_data(32'h1000006c, 4'h0, 32'h1ffee3c7);
pci_burst_data(32'h10000070, 4'h0, 32'h1fff0000);
pci_burst_data(32'h10000074, 4'h0, 32'h3c707fc);
pci_burst_data(32'h10000078, 4'h0, 32'hc00033f8);
pci_burst_data(32'h1000007c, 4'h0, 32'h7ff07f0);
pci_burst_data(rbase_a+XY1,4'h0,32'h800050);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h1c0001);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x8010184, 0xffff, 0x1c, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h43fc0287);
pci_burst_data(32'h10000004, 4'h0, 32'hfff06000);
pci_burst_data(32'h10000008, 4'h0, 32'h68f07ff);
pci_burst_data(32'h1000000c, 4'h0, 32'h300087be);
pci_burst_data(32'h10000010, 4'h0, 32'h7fffff8);
pci_burst_data(32'h10000014, 4'h0, 32'h8f9c148f);
pci_burst_data(32'h10000018, 4'h0, 32'hfffc0000);
pci_burst_data(32'h1000001c, 4'h0, 32'h8d9f07ff);
pci_burst_data(32'h10000020, 4'h0, 32'hf8a);
pci_burst_data(32'h10000024, 4'h0, 32'h7fffffe);
pci_burst_data(32'h10000028, 4'h0, 32'h1f800bbf);
pci_burst_data(32'h1000002c, 4'h0, 32'hffff0000);
pci_burst_data(32'h10000030, 4'h0, 32'h3a7f07ff);
pci_burst_data(32'h10000034, 4'h0, 32'h80003f80);
pci_burst_data(32'h10000038, 4'h0, 32'h7ffffff);
pci_burst_data(32'h1000003c, 4'h0, 32'h3fc020ff);
pci_burst_data(32'h10000040, 4'h0, 32'hffff8000);
pci_burst_data(32'h10000044, 4'h0, 32'h1ff07ff);
pci_burst_data(32'h10000048, 4'h0, 32'hc0007fe0);
pci_burst_data(32'h1000004c, 4'h0, 32'h7ffffff);
pci_burst_data(32'h10000050, 4'h0, 32'hfff80fff);
pci_burst_data(32'h10000054, 4'h0, 32'hffffe040);
pci_burst_data(32'h10000058, 4'h0, 32'hffff07ff);
pci_burst_data(32'h1000005c, 4'h0, 32'hf040ffff);
pci_burst_data(32'h10000060, 4'h0, 32'h7ffffff);
pci_burst_data(32'h10000064, 4'h0, 32'hffffffff);
pci_burst_data(32'h10000068, 4'h0, 32'hfffff041);
pci_burst_data(32'h1000006c, 4'h0, 32'h7ff);
pci_burst_data(rbase_a+XY1,4'h0,32'ha00050);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'hc00);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x4c0c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h4c0c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 80, 3, 3, 75, 75, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h4b004b);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h50);
pci_burst_data(rbase_a+XY1,4'h0,32'h30003);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_memxfer_setup(0, 0x8200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h8200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h50, 32'h50, "junk", 32'h600, 2'h2);
