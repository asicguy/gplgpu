///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2014 Francis Bruno, All Rights Reserved
// 
//  This program is free software; you can redistribute it and/or modify it 
//  under the terms of the GNU General Public License as published by the Free 
//  Software Foundation; either version 3 of the License, or (at your option) 
//  any later version.
//
//  This program is distributed in the hope that it will be useful, but 
//  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
//  or FITNESS FOR A PARTICULAR PURPOSE. 
//  See the GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License along with
//  this program; if not, see <http://www.gnu.org/licenses>.
//
//  This code is available under licenses for commercial use. Please contact
//  Francis Bruno for more information.
//
//  http://www.gplgpu.com
//  http://www.asicsolutions.com
//
//  Title       :  
//  File        :  
//  Author      :  Frank Bruno
//  Created     :  14-May-2011
//  RCS File    :  $Source:$
//  Status      :  $Id:$
//
///////////////////////////////////////////////////////////////////////////////
//
//  Description : 
//  2D test suite - 32 Bpp
//
//////////////////////////////////////////////////////////////////////////////
//
//  Modules Instantiated:
//
///////////////////////////////////////////////////////////////////////////////
//
//  Modification History:
//
//  $Log:$
//
//
///////////////////////////////////////////////////////////////////////////////
//     Reverse direction bitblit test
//     It fills each line of the display with the same random pattern,
//     then blits it backwards depending on the line number.
//     Line zero isn't touched, line 1 is shifted back 1 pixel, ...
//     up to line 15.  Only 100 pixels are moved per line.
// 
// # Reverse direction bitblit test
$display("# Reverse direction bitblit test");
// memxfer_setup 0 0 0xFFFFFFFF
pci_burst_data(rbase_w + 32'h00000000, 4'h0, 32'h00000000);
pci_burst_data(rbase_w + 32'h00000024, 4'h0, 32'hffffffff);
// 
// # Set bitmap to 32 bits/pixel, 128x16, starting at address 0.
$display("# Set bitmap to 32 bits/pixel, 128x16, starting at address 0.");
// bitmap 32 128 16 0
pci_burst_data(rbase_a + 32'h00000048, 4'h0, 32'h0);
pci_burst_data(rbase_a + 32'h00000020, 4'h0, 32'h02000000);
pci_burst_data(rbase_a + 32'h00000028, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000002c, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000040, 4'h0, 32'h00000200);
pci_burst_data(rbase_a + 32'h00000044, 4'h0, 32'h00000200);
pci_burst_data(rbase_a + 32'h00000080, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000084, 4'h0, 32'h00800010);
// clear_mem
VR.ram_fill32(32'h00000000, 128, 0);
VR.ram_fill32(32'h00000080, 128, 0);
VR.ram_fill32(32'h00000100, 128, 0);
VR.ram_fill32(32'h00000180, 128, 0);
VR.ram_fill32(32'h00000200, 128, 0);
VR.ram_fill32(32'h00000280, 128, 0);
VR.ram_fill32(32'h00000300, 128, 0);
VR.ram_fill32(32'h00000380, 128, 0);
VR.ram_fill32(32'h00000400, 128, 0);
VR.ram_fill32(32'h00000480, 128, 0);
VR.ram_fill32(32'h00000500, 128, 0);
VR.ram_fill32(32'h00000580, 128, 0);
VR.ram_fill32(32'h00000600, 128, 0);
VR.ram_fill32(32'h00000680, 128, 0);
VR.ram_fill32(32'h00000700, 128, 0);
VR.ram_fill32(32'h00000780, 128, 0);
// 
// cmd_raster_op 0xC	// Copy
pci_burst_data(rbase_a + 32'h00000054, 4'h0, 32'h0000000c);
// cmd_style 0 
pci_burst_data(rbase_a + 32'h00000058, 4'h0, 32'h00000000);
// cmd_clip 2	// Clip in
pci_burst_data(rbase_a + 32'h00000060, 4'h0, 32'h00000002);
// 
// write_mem 0x40000000 128	// 
//  0x14  0x1a  0x1a  0x18  0x17  0x16  0x10  0x17 
pci_burst_data(0 + 32'h40000000, 4'h0, 32'h00000014);
pci_burst_data(0 + 32'h40000004, 4'h0, 32'h0000001a);
pci_burst_data(0 + 32'h40000008, 4'h0, 32'h0000001a);
pci_burst_data(0 + 32'h4000000c, 4'h0, 32'h00000018);
pci_burst_data(0 + 32'h40000010, 4'h0, 32'h00000017);
pci_burst_data(0 + 32'h40000014, 4'h0, 32'h00000016);
pci_burst_data(0 + 32'h40000018, 4'h0, 32'h00000010);
pci_burst_data(0 + 32'h4000001c, 4'h0, 32'h00000017);
//  0x1c  0x1d  0x1a  0x14  0x14  0x18  0x12  0x17 
pci_burst_data(0 + 32'h40000020, 4'h0, 32'h0000001c);
pci_burst_data(0 + 32'h40000024, 4'h0, 32'h0000001d);
pci_burst_data(0 + 32'h40000028, 4'h0, 32'h0000001a);
pci_burst_data(0 + 32'h4000002c, 4'h0, 32'h00000014);
pci_burst_data(0 + 32'h40000030, 4'h0, 32'h00000014);
pci_burst_data(0 + 32'h40000034, 4'h0, 32'h00000018);
pci_burst_data(0 + 32'h40000038, 4'h0, 32'h00000012);
pci_burst_data(0 + 32'h4000003c, 4'h0, 32'h00000017);
//  0x16  0x1f  0x13  0x17  0x13  0x11  0x16  0x10 
pci_burst_data(0 + 32'h40000040, 4'h0, 32'h00000016);
pci_burst_data(0 + 32'h40000044, 4'h0, 32'h0000001f);
pci_burst_data(0 + 32'h40000048, 4'h0, 32'h00000013);
pci_burst_data(0 + 32'h4000004c, 4'h0, 32'h00000017);
pci_burst_data(0 + 32'h40000050, 4'h0, 32'h00000013);
pci_burst_data(0 + 32'h40000054, 4'h0, 32'h00000011);
pci_burst_data(0 + 32'h40000058, 4'h0, 32'h00000016);
pci_burst_data(0 + 32'h4000005c, 4'h0, 32'h00000010);
//  0x15  0x19  0x1a  0x18  0x12  0x1b  0x1f  0x16 
pci_burst_data(0 + 32'h40000060, 4'h0, 32'h00000015);
pci_burst_data(0 + 32'h40000064, 4'h0, 32'h00000019);
pci_burst_data(0 + 32'h40000068, 4'h0, 32'h0000001a);
pci_burst_data(0 + 32'h4000006c, 4'h0, 32'h00000018);
pci_burst_data(0 + 32'h40000070, 4'h0, 32'h00000012);
pci_burst_data(0 + 32'h40000074, 4'h0, 32'h0000001b);
pci_burst_data(0 + 32'h40000078, 4'h0, 32'h0000001f);
pci_burst_data(0 + 32'h4000007c, 4'h0, 32'h00000016);
//  0x15  0x1a  0x1f  0x1d  0x10  0x1f  0x14  0x1c 
pci_burst_data(0 + 32'h40000080, 4'h0, 32'h00000015);
pci_burst_data(0 + 32'h40000084, 4'h0, 32'h0000001a);
pci_burst_data(0 + 32'h40000088, 4'h0, 32'h0000001f);
pci_burst_data(0 + 32'h4000008c, 4'h0, 32'h0000001d);
pci_burst_data(0 + 32'h40000090, 4'h0, 32'h00000010);
pci_burst_data(0 + 32'h40000094, 4'h0, 32'h0000001f);
pci_burst_data(0 + 32'h40000098, 4'h0, 32'h00000014);
pci_burst_data(0 + 32'h4000009c, 4'h0, 32'h0000001c);
//  0x1c  0x1e  0x10  0x10  0x16  0x12  0x18  0x1d 
pci_burst_data(0 + 32'h400000a0, 4'h0, 32'h0000001c);
pci_burst_data(0 + 32'h400000a4, 4'h0, 32'h0000001e);
pci_burst_data(0 + 32'h400000a8, 4'h0, 32'h00000010);
pci_burst_data(0 + 32'h400000ac, 4'h0, 32'h00000010);
pci_burst_data(0 + 32'h400000b0, 4'h0, 32'h00000016);
pci_burst_data(0 + 32'h400000b4, 4'h0, 32'h00000012);
pci_burst_data(0 + 32'h400000b8, 4'h0, 32'h00000018);
pci_burst_data(0 + 32'h400000bc, 4'h0, 32'h0000001d);
//  0x11  0x1b  0x14  0x14  0x1c  0x1b  0x14  0x11 
pci_burst_data(0 + 32'h400000c0, 4'h0, 32'h00000011);
pci_burst_data(0 + 32'h400000c4, 4'h0, 32'h0000001b);
pci_burst_data(0 + 32'h400000c8, 4'h0, 32'h00000014);
pci_burst_data(0 + 32'h400000cc, 4'h0, 32'h00000014);
pci_burst_data(0 + 32'h400000d0, 4'h0, 32'h0000001c);
pci_burst_data(0 + 32'h400000d4, 4'h0, 32'h0000001b);
pci_burst_data(0 + 32'h400000d8, 4'h0, 32'h00000014);
pci_burst_data(0 + 32'h400000dc, 4'h0, 32'h00000011);
//  0x14  0x1f  0x1a  0x16  0x1a  0x19  0x1d  0x10 
pci_burst_data(0 + 32'h400000e0, 4'h0, 32'h00000014);
pci_burst_data(0 + 32'h400000e4, 4'h0, 32'h0000001f);
pci_burst_data(0 + 32'h400000e8, 4'h0, 32'h0000001a);
pci_burst_data(0 + 32'h400000ec, 4'h0, 32'h00000016);
pci_burst_data(0 + 32'h400000f0, 4'h0, 32'h0000001a);
pci_burst_data(0 + 32'h400000f4, 4'h0, 32'h00000019);
pci_burst_data(0 + 32'h400000f8, 4'h0, 32'h0000001d);
pci_burst_data(0 + 32'h400000fc, 4'h0, 32'h00000010);
//  0x13  0x1c  0x1d  0x13  0x1b  0x11  0x10  0x18 
pci_burst_data(0 + 32'h40000100, 4'h0, 32'h00000013);
pci_burst_data(0 + 32'h40000104, 4'h0, 32'h0000001c);
pci_burst_data(0 + 32'h40000108, 4'h0, 32'h0000001d);
pci_burst_data(0 + 32'h4000010c, 4'h0, 32'h00000013);
pci_burst_data(0 + 32'h40000110, 4'h0, 32'h0000001b);
pci_burst_data(0 + 32'h40000114, 4'h0, 32'h00000011);
pci_burst_data(0 + 32'h40000118, 4'h0, 32'h00000010);
pci_burst_data(0 + 32'h4000011c, 4'h0, 32'h00000018);
//  0x10  0x10  0x18  0x16  0x13  0x10  0x13  0x14 
pci_burst_data(0 + 32'h40000120, 4'h0, 32'h00000010);
pci_burst_data(0 + 32'h40000124, 4'h0, 32'h00000010);
pci_burst_data(0 + 32'h40000128, 4'h0, 32'h00000018);
pci_burst_data(0 + 32'h4000012c, 4'h0, 32'h00000016);
pci_burst_data(0 + 32'h40000130, 4'h0, 32'h00000013);
pci_burst_data(0 + 32'h40000134, 4'h0, 32'h00000010);
pci_burst_data(0 + 32'h40000138, 4'h0, 32'h00000013);
pci_burst_data(0 + 32'h4000013c, 4'h0, 32'h00000014);
//  0x1b  0x18  0x19  0x18  0x13  0x1d  0x19  0x17 
pci_burst_data(0 + 32'h40000140, 4'h0, 32'h0000001b);
pci_burst_data(0 + 32'h40000144, 4'h0, 32'h00000018);
pci_burst_data(0 + 32'h40000148, 4'h0, 32'h00000019);
pci_burst_data(0 + 32'h4000014c, 4'h0, 32'h00000018);
pci_burst_data(0 + 32'h40000150, 4'h0, 32'h00000013);
pci_burst_data(0 + 32'h40000154, 4'h0, 32'h0000001d);
pci_burst_data(0 + 32'h40000158, 4'h0, 32'h00000019);
pci_burst_data(0 + 32'h4000015c, 4'h0, 32'h00000017);
//  0x1c  0x13  0x1e  0x17  0x1d  0x1b  0x17  0x10 
pci_burst_data(0 + 32'h40000160, 4'h0, 32'h0000001c);
pci_burst_data(0 + 32'h40000164, 4'h0, 32'h00000013);
pci_burst_data(0 + 32'h40000168, 4'h0, 32'h0000001e);
pci_burst_data(0 + 32'h4000016c, 4'h0, 32'h00000017);
pci_burst_data(0 + 32'h40000170, 4'h0, 32'h0000001d);
pci_burst_data(0 + 32'h40000174, 4'h0, 32'h0000001b);
pci_burst_data(0 + 32'h40000178, 4'h0, 32'h00000017);
pci_burst_data(0 + 32'h4000017c, 4'h0, 32'h00000010);
//  0x17  0x14  0x14  0x12  0x15  0x14  0x1a  0x15 
pci_burst_data(0 + 32'h40000180, 4'h0, 32'h00000017);
pci_burst_data(0 + 32'h40000184, 4'h0, 32'h00000014);
pci_burst_data(0 + 32'h40000188, 4'h0, 32'h00000014);
pci_burst_data(0 + 32'h4000018c, 4'h0, 32'h00000012);
pci_burst_data(0 + 32'h40000190, 4'h0, 32'h00000015);
pci_burst_data(0 + 32'h40000194, 4'h0, 32'h00000014);
pci_burst_data(0 + 32'h40000198, 4'h0, 32'h0000001a);
pci_burst_data(0 + 32'h4000019c, 4'h0, 32'h00000015);
//  0x14  0x13  0x1c  0x17  0x13  0x1f  0x1c  0x1f 
pci_burst_data(0 + 32'h400001a0, 4'h0, 32'h00000014);
pci_burst_data(0 + 32'h400001a4, 4'h0, 32'h00000013);
pci_burst_data(0 + 32'h400001a8, 4'h0, 32'h0000001c);
pci_burst_data(0 + 32'h400001ac, 4'h0, 32'h00000017);
pci_burst_data(0 + 32'h400001b0, 4'h0, 32'h00000013);
pci_burst_data(0 + 32'h400001b4, 4'h0, 32'h0000001f);
pci_burst_data(0 + 32'h400001b8, 4'h0, 32'h0000001c);
pci_burst_data(0 + 32'h400001bc, 4'h0, 32'h0000001f);
//  0x17  0x15  0x17  0x1a  0x12  0x10  0x12  0x1f 
pci_burst_data(0 + 32'h400001c0, 4'h0, 32'h00000017);
pci_burst_data(0 + 32'h400001c4, 4'h0, 32'h00000015);
pci_burst_data(0 + 32'h400001c8, 4'h0, 32'h00000017);
pci_burst_data(0 + 32'h400001cc, 4'h0, 32'h0000001a);
pci_burst_data(0 + 32'h400001d0, 4'h0, 32'h00000012);
pci_burst_data(0 + 32'h400001d4, 4'h0, 32'h00000010);
pci_burst_data(0 + 32'h400001d8, 4'h0, 32'h00000012);
pci_burst_data(0 + 32'h400001dc, 4'h0, 32'h0000001f);
//  0x14  0x10  0x16  0x11  0x1b  0x1d  0x11  0x12 
pci_burst_data(0 + 32'h400001e0, 4'h0, 32'h00000014);
pci_burst_data(0 + 32'h400001e4, 4'h0, 32'h00000010);
pci_burst_data(0 + 32'h400001e8, 4'h0, 32'h00000016);
pci_burst_data(0 + 32'h400001ec, 4'h0, 32'h00000011);
pci_burst_data(0 + 32'h400001f0, 4'h0, 32'h0000001b);
pci_burst_data(0 + 32'h400001f4, 4'h0, 32'h0000001d);
pci_burst_data(0 + 32'h400001f8, 4'h0, 32'h00000011);
pci_burst_data(0 + 32'h400001fc, 4'h0, 32'h00000012);
// 
// bitblit   0  0  0  1  128 1
pci_burst_data(rbase_a + 32'h00000050, 4'h0, 32'h00000001);
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00800001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00000001);
// bitblit   0  0  0  2  128 2
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00800002);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00000002);
// bitblit   0  0  0  4  128 4
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00800004);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00000004);
// bitblit   0  0  0  8  128 8
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00800008);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00000008);
// 
$display("#define T2R_DIR_RL_TB         0x02            /* right-left, top-bottom */");
// #bitblit srcx srcy dstx dsty width height dir zoom
$display("#bitblit srcx srcy dstx dsty width height dir zoom");
// bitblit 100 0 110 0 100 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00640001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00640000);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h006e0000);
// bitblit 100 1 111 1 100 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00640001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00640001);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h006f0001);
// bitblit 100 2 112 2 100 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00640001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00640002);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00700002);
// bitblit 100 3 113 3 100 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00640001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00640003);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00710003);
// bitblit 100 4 114 4 100 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00640001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00640004);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00720004);
// bitblit 100 5 115 5 100 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00640001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00640005);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00730005);
// bitblit 100 6 116 6 100 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00640001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00640006);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00740006);
// bitblit 100 7 117 7 100 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00640001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00640007);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00750007);
// bitblit 100 8 118 8 100 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00640001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00640008);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00760008);
// bitblit 100 9 119 9 100 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00640001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00640009);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00770009);
// bitblit 100 10 120 10 100 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00640001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0064000a);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h0078000a);
// bitblit 100 11 121 11 100 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00640001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0064000b);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h0079000b);
// bitblit 100 12 122 12 100 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00640001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0064000c);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h007a000c);
// bitblit 100 13 123 13 100 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00640001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0064000d);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h007b000d);
// bitblit 100 14 124 14 100 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00640001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0064000e);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h007c000e);
// bitblit 100 15 125 15 100 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00640001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0064000f);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h007d000f);
// 
// 
// 
// 
// save_bmp junk 0 0 128 16
wait_for_pipe_a;
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h80, 32'h10, "junk", 32'h200, 32'h2);
// 
// end
