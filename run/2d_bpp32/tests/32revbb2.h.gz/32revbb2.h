///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2014 Francis Bruno, All Rights Reserved
// 
//  This program is free software; you can redistribute it and/or modify it 
//  under the terms of the GNU General Public License as published by the Free 
//  Software Foundation; either version 3 of the License, or (at your option) 
//  any later version.
//
//  This program is distributed in the hope that it will be useful, but 
//  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
//  or FITNESS FOR A PARTICULAR PURPOSE. 
//  See the GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License along with
//  this program; if not, see <http://www.gnu.org/licenses>.
//
//  This code is available under licenses for commercial use. Please contact
//  Francis Bruno for more information.
//
//  http://www.gplgpu.com
//  http://www.asicsolutions.com
//
//  Title       :  
//  File        :  
//  Author      :  Frank Bruno
//  Created     :  14-May-2011
//  RCS File    :  $Source:$
//  Status      :  $Id:$
//
///////////////////////////////////////////////////////////////////////////////
//
//  Description : 
//  2D test suite - 32 Bpp
//
//////////////////////////////////////////////////////////////////////////////
//
//  Modules Instantiated:
//
///////////////////////////////////////////////////////////////////////////////
//
//  Modification History:
//
//  $Log:$
//
//
///////////////////////////////////////////////////////////////////////////////
// 
// # Reverse direction bitblit test 2 - width is exactly 128 bytes
$display("# Reverse direction bitblit test 2 - width is exactly 128 bytes");
// memxfer_setup 0 0 0xFFFFFFFF
pci_burst_data(rbase_w + 32'h00000000, 4'h0, 32'h00000000);
pci_burst_data(rbase_w + 32'h00000024, 4'h0, 32'hffffffff);
// 
// # Set bitmap to 32 bits/pixel, 48x16, starting at address 0.
$display("# Set bitmap to 32 bits/pixel, 48x16, starting at address 0.");
// bitmap 32 48 16 0
pci_burst_data(rbase_a + 32'h00000048, 4'h0, 32'h0);
pci_burst_data(rbase_a + 32'h00000020, 4'h0, 32'h02000000);
pci_burst_data(rbase_a + 32'h00000028, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000002c, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000040, 4'h0, 32'h000000c0);
pci_burst_data(rbase_a + 32'h00000044, 4'h0, 32'h000000c0);
pci_burst_data(rbase_a + 32'h00000080, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000084, 4'h0, 32'h00300010);
// clear_mem
VR.ram_fill32(32'h00000000, 48, 0);
VR.ram_fill32(32'h00000030, 48, 0);
VR.ram_fill32(32'h00000060, 48, 0);
VR.ram_fill32(32'h00000090, 48, 0);
VR.ram_fill32(32'h000000c0, 48, 0);
VR.ram_fill32(32'h000000f0, 48, 0);
VR.ram_fill32(32'h00000120, 48, 0);
VR.ram_fill32(32'h00000150, 48, 0);
VR.ram_fill32(32'h00000180, 48, 0);
VR.ram_fill32(32'h000001b0, 48, 0);
VR.ram_fill32(32'h000001e0, 48, 0);
VR.ram_fill32(32'h00000210, 48, 0);
VR.ram_fill32(32'h00000240, 48, 0);
VR.ram_fill32(32'h00000270, 48, 0);
VR.ram_fill32(32'h000002a0, 48, 0);
VR.ram_fill32(32'h000002d0, 48, 0);
// 
// cmd_raster_op 0xC	// Copy
pci_burst_data(rbase_a + 32'h00000054, 4'h0, 32'h0000000c);
// cmd_style 0 
pci_burst_data(rbase_a + 32'h00000058, 4'h0, 32'h00000000);
// cmd_clip 2	// Clip in
pci_burst_data(rbase_a + 32'h00000060, 4'h0, 32'h00000002);
// 
// write_mem 0x40000000 48	// 
//  0x14  0x1a  0x1a  0x18  0x17  0x16  0x10  0x17 
pci_burst_data(0 + 32'h40000000, 4'h0, 32'h00000014);
pci_burst_data(0 + 32'h40000004, 4'h0, 32'h0000001a);
pci_burst_data(0 + 32'h40000008, 4'h0, 32'h0000001a);
pci_burst_data(0 + 32'h4000000c, 4'h0, 32'h00000018);
pci_burst_data(0 + 32'h40000010, 4'h0, 32'h00000017);
pci_burst_data(0 + 32'h40000014, 4'h0, 32'h00000016);
pci_burst_data(0 + 32'h40000018, 4'h0, 32'h00000010);
pci_burst_data(0 + 32'h4000001c, 4'h0, 32'h00000017);
//  0x1c  0x1d  0x1a  0x14  0x14  0x18  0x12  0x17 
pci_burst_data(0 + 32'h40000020, 4'h0, 32'h0000001c);
pci_burst_data(0 + 32'h40000024, 4'h0, 32'h0000001d);
pci_burst_data(0 + 32'h40000028, 4'h0, 32'h0000001a);
pci_burst_data(0 + 32'h4000002c, 4'h0, 32'h00000014);
pci_burst_data(0 + 32'h40000030, 4'h0, 32'h00000014);
pci_burst_data(0 + 32'h40000034, 4'h0, 32'h00000018);
pci_burst_data(0 + 32'h40000038, 4'h0, 32'h00000012);
pci_burst_data(0 + 32'h4000003c, 4'h0, 32'h00000017);
//  0x16  0x1f  0x13  0x17  0x13  0x11  0x16  0x10 
pci_burst_data(0 + 32'h40000040, 4'h0, 32'h00000016);
pci_burst_data(0 + 32'h40000044, 4'h0, 32'h0000001f);
pci_burst_data(0 + 32'h40000048, 4'h0, 32'h00000013);
pci_burst_data(0 + 32'h4000004c, 4'h0, 32'h00000017);
pci_burst_data(0 + 32'h40000050, 4'h0, 32'h00000013);
pci_burst_data(0 + 32'h40000054, 4'h0, 32'h00000011);
pci_burst_data(0 + 32'h40000058, 4'h0, 32'h00000016);
pci_burst_data(0 + 32'h4000005c, 4'h0, 32'h00000010);
//  0x15  0x19  0x1a  0x18  0x12  0x1b  0x1f  0x16 
pci_burst_data(0 + 32'h40000060, 4'h0, 32'h00000015);
pci_burst_data(0 + 32'h40000064, 4'h0, 32'h00000019);
pci_burst_data(0 + 32'h40000068, 4'h0, 32'h0000001a);
pci_burst_data(0 + 32'h4000006c, 4'h0, 32'h00000018);
pci_burst_data(0 + 32'h40000070, 4'h0, 32'h00000012);
pci_burst_data(0 + 32'h40000074, 4'h0, 32'h0000001b);
pci_burst_data(0 + 32'h40000078, 4'h0, 32'h0000001f);
pci_burst_data(0 + 32'h4000007c, 4'h0, 32'h00000016);
//  0x15  0x1a  0x1f  0x1d  0x10  0x1f  0x14  0x1c 
pci_burst_data(0 + 32'h40000080, 4'h0, 32'h00000015);
pci_burst_data(0 + 32'h40000084, 4'h0, 32'h0000001a);
pci_burst_data(0 + 32'h40000088, 4'h0, 32'h0000001f);
pci_burst_data(0 + 32'h4000008c, 4'h0, 32'h0000001d);
pci_burst_data(0 + 32'h40000090, 4'h0, 32'h00000010);
pci_burst_data(0 + 32'h40000094, 4'h0, 32'h0000001f);
pci_burst_data(0 + 32'h40000098, 4'h0, 32'h00000014);
pci_burst_data(0 + 32'h4000009c, 4'h0, 32'h0000001c);
//  0x1d  0x1a  0x11  0x15  0x19  0x13  0x19  0x12 
pci_burst_data(0 + 32'h400000a0, 4'h0, 32'h0000001d);
pci_burst_data(0 + 32'h400000a4, 4'h0, 32'h0000001a);
pci_burst_data(0 + 32'h400000a8, 4'h0, 32'h00000011);
pci_burst_data(0 + 32'h400000ac, 4'h0, 32'h00000015);
pci_burst_data(0 + 32'h400000b0, 4'h0, 32'h00000019);
pci_burst_data(0 + 32'h400000b4, 4'h0, 32'h00000013);
pci_burst_data(0 + 32'h400000b8, 4'h0, 32'h00000019);
pci_burst_data(0 + 32'h400000bc, 4'h0, 32'h00000012);
// 
// bitblit   0  0  0  1  48 1
pci_burst_data(rbase_a + 32'h00000050, 4'h0, 32'h00000001);
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00300001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00000001);
// bitblit   0  0  0  2  48 2
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00300002);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00000002);
// bitblit   0  0  0  4  48 4
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00300004);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00000004);
// bitblit   0  0  0  8  48 8
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00300008);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00000008);
// 
$display("#define T2R_DIR_RL_TB         0x02            /* right-left, top-bottom */");
// #bitblit srcx srcy dstx dsty width height dir zoom
$display("#bitblit srcx srcy dstx dsty width height dir zoom");
// bitblit 32 1 33 1 32 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00200001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00200001);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00210001);
// bitblit 32 2 34 2 32 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00200001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00200002);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00220002);
// bitblit 32 3 35 3 32 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00200001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00200003);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00230003);
// bitblit 32 4 36 4 32 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00200001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00200004);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00240004);
// bitblit 32 5 37 5 32 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00200001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00200005);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00250005);
// bitblit 32 6 38 6 32 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00200001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00200006);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00260006);
// bitblit 32 7 39 7 32 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00200001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00200007);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00270007);
// bitblit 32 8 40 8 32 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00200001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00200008);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00280008);
// bitblit 32 9 41 9 32 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00200001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h00200009);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h00290009);
// bitblit 32 10 42 10 32 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00200001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0020000a);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h002a000a);
// bitblit 32 11 43 11 32 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00200001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0020000b);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h002b000b);
// bitblit 32 12 44 12 32 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00200001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0020000c);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h002c000c);
// bitblit 32 13 45 13 32 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00200001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0020000d);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h002d000d);
// bitblit 32 14 46 14 32 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00200001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0020000e);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h002e000e);
// bitblit 32 15 47 15 32 1 0x02
pci_burst_data(rbase_a + 32'h00000090, 4'h0, 32'h00200001);
pci_burst_data(rbase_a + 32'h00000094, 4'h0, 32'h00000002);
pci_burst_data(rbase_a + 32'h00000098, 4'h0, 32'h00000000);
pci_burst_data(rbase_a + 32'h00000088, 4'h0, 32'h0020000f);
pci_burst_data(rbase_a + 32'h0000008c, 4'h0, 32'h002f000f);
// 
// 
// 
// 
// save_bmp junk 0 0 48 16
wait_for_pipe_a;
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h30, 32'h10, "junk", 32'hc0, 32'h2);
// 
// end
