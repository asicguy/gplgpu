///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2014 Francis Bruno, All Rights Reserved
// 
//  This program is free software; you can redistribute it and/or modify it 
//  under the terms of the GNU General Public License as published by the Free 
//  Software Foundation; either version 3 of the License, or (at your option) 
//  any later version.
//
//  This program is distributed in the hope that it will be useful, but 
//  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
//  or FITNESS FOR A PARTICULAR PURPOSE. 
//  See the GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License along with
//  this program; if not, see <http://www.gnu.org/licenses>.
//
//  This code is available under licenses for commercial use. Please contact
//  Francis Bruno for more information.
//
//  http://www.gplgpu.com
//  http://www.asicsolutions.com
//
//  Title       :  
//  File        :  
//  Author      :  Frank Bruno
//  Created     :  14-May-2011
//  RCS File    :  $Source:$
//  Status      :  $Id:$
//
///////////////////////////////////////////////////////////////////////////////
//
//  Description : 
//  2D test suite - 32 Bpp
//
//////////////////////////////////////////////////////////////////////////////
//
//  Modules Instantiated:
//
///////////////////////////////////////////////////////////////////////////////
//
//  Modification History:
//
//  $Log:$
//
//
///////////////////////////////////////////////////////////////////////////////
/* VERILOG logging on. */
/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'h600);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0x600, 0x2000000); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'h600);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x600, 0x2000000, 0, 0, 287, 159); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h600);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h11f009f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 288, 0);
VR.ram_fill32(32'h180, 288, 0);
VR.ram_fill32(32'h300, 288, 0);
VR.ram_fill32(32'h480, 288, 0);
VR.ram_fill32(32'h600, 288, 0);
VR.ram_fill32(32'h780, 288, 0);
VR.ram_fill32(32'h900, 288, 0);
VR.ram_fill32(32'ha80, 288, 0);
VR.ram_fill32(32'hc00, 288, 0);
VR.ram_fill32(32'hd80, 288, 0);
VR.ram_fill32(32'hf00, 288, 0);
VR.ram_fill32(32'h1080, 288, 0);
VR.ram_fill32(32'h1200, 288, 0);
VR.ram_fill32(32'h1380, 288, 0);
VR.ram_fill32(32'h1500, 288, 0);
VR.ram_fill32(32'h1680, 288, 0);
VR.ram_fill32(32'h1800, 288, 0);
VR.ram_fill32(32'h1980, 288, 0);
VR.ram_fill32(32'h1b00, 288, 0);
VR.ram_fill32(32'h1c80, 288, 0);
VR.ram_fill32(32'h1e00, 288, 0);
VR.ram_fill32(32'h1f80, 288, 0);
VR.ram_fill32(32'h2100, 288, 0);
VR.ram_fill32(32'h2280, 288, 0);
VR.ram_fill32(32'h2400, 288, 0);
VR.ram_fill32(32'h2580, 288, 0);
VR.ram_fill32(32'h2700, 288, 0);
VR.ram_fill32(32'h2880, 288, 0);
VR.ram_fill32(32'h2a00, 288, 0);
VR.ram_fill32(32'h2b80, 288, 0);
VR.ram_fill32(32'h2d00, 288, 0);
VR.ram_fill32(32'h2e80, 288, 0);
VR.ram_fill32(32'h3000, 288, 0);
VR.ram_fill32(32'h3180, 288, 0);
VR.ram_fill32(32'h3300, 288, 0);
VR.ram_fill32(32'h3480, 288, 0);
VR.ram_fill32(32'h3600, 288, 0);
VR.ram_fill32(32'h3780, 288, 0);
VR.ram_fill32(32'h3900, 288, 0);
VR.ram_fill32(32'h3a80, 288, 0);
VR.ram_fill32(32'h3c00, 288, 0);
VR.ram_fill32(32'h3d80, 288, 0);
VR.ram_fill32(32'h3f00, 288, 0);
VR.ram_fill32(32'h4080, 288, 0);
VR.ram_fill32(32'h4200, 288, 0);
VR.ram_fill32(32'h4380, 288, 0);
VR.ram_fill32(32'h4500, 288, 0);
VR.ram_fill32(32'h4680, 288, 0);
VR.ram_fill32(32'h4800, 288, 0);
VR.ram_fill32(32'h4980, 288, 0);
VR.ram_fill32(32'h4b00, 288, 0);
VR.ram_fill32(32'h4c80, 288, 0);
VR.ram_fill32(32'h4e00, 288, 0);
VR.ram_fill32(32'h4f80, 288, 0);
VR.ram_fill32(32'h5100, 288, 0);
VR.ram_fill32(32'h5280, 288, 0);
VR.ram_fill32(32'h5400, 288, 0);
VR.ram_fill32(32'h5580, 288, 0);
VR.ram_fill32(32'h5700, 288, 0);
VR.ram_fill32(32'h5880, 288, 0);
VR.ram_fill32(32'h5a00, 288, 0);
VR.ram_fill32(32'h5b80, 288, 0);
VR.ram_fill32(32'h5d00, 288, 0);
VR.ram_fill32(32'h5e80, 288, 0);
VR.ram_fill32(32'h6000, 288, 0);
VR.ram_fill32(32'h6180, 288, 0);
VR.ram_fill32(32'h6300, 288, 0);
VR.ram_fill32(32'h6480, 288, 0);
VR.ram_fill32(32'h6600, 288, 0);
VR.ram_fill32(32'h6780, 288, 0);
VR.ram_fill32(32'h6900, 288, 0);
VR.ram_fill32(32'h6a80, 288, 0);
VR.ram_fill32(32'h6c00, 288, 0);
VR.ram_fill32(32'h6d80, 288, 0);
VR.ram_fill32(32'h6f00, 288, 0);
VR.ram_fill32(32'h7080, 288, 0);
VR.ram_fill32(32'h7200, 288, 0);
VR.ram_fill32(32'h7380, 288, 0);
VR.ram_fill32(32'h7500, 288, 0);
VR.ram_fill32(32'h7680, 288, 0);
VR.ram_fill32(32'h7800, 288, 0);
VR.ram_fill32(32'h7980, 288, 0);
VR.ram_fill32(32'h7b00, 288, 0);
VR.ram_fill32(32'h7c80, 288, 0);
VR.ram_fill32(32'h7e00, 288, 0);
VR.ram_fill32(32'h7f80, 288, 0);
VR.ram_fill32(32'h8100, 288, 0);
VR.ram_fill32(32'h8280, 288, 0);
VR.ram_fill32(32'h8400, 288, 0);
VR.ram_fill32(32'h8580, 288, 0);
VR.ram_fill32(32'h8700, 288, 0);
VR.ram_fill32(32'h8880, 288, 0);
VR.ram_fill32(32'h8a00, 288, 0);
VR.ram_fill32(32'h8b80, 288, 0);
VR.ram_fill32(32'h8d00, 288, 0);
VR.ram_fill32(32'h8e80, 288, 0);
VR.ram_fill32(32'h9000, 288, 0);
VR.ram_fill32(32'h9180, 288, 0);
VR.ram_fill32(32'h9300, 288, 0);
VR.ram_fill32(32'h9480, 288, 0);
VR.ram_fill32(32'h9600, 288, 0);
VR.ram_fill32(32'h9780, 288, 0);
VR.ram_fill32(32'h9900, 288, 0);
VR.ram_fill32(32'h9a80, 288, 0);
VR.ram_fill32(32'h9c00, 288, 0);
VR.ram_fill32(32'h9d80, 288, 0);
VR.ram_fill32(32'h9f00, 288, 0);
VR.ram_fill32(32'ha080, 288, 0);
VR.ram_fill32(32'ha200, 288, 0);
VR.ram_fill32(32'ha380, 288, 0);
VR.ram_fill32(32'ha500, 288, 0);
VR.ram_fill32(32'ha680, 288, 0);
VR.ram_fill32(32'ha800, 288, 0);
VR.ram_fill32(32'ha980, 288, 0);
VR.ram_fill32(32'hab00, 288, 0);
VR.ram_fill32(32'hac80, 288, 0);
VR.ram_fill32(32'hae00, 288, 0);
VR.ram_fill32(32'haf80, 288, 0);
VR.ram_fill32(32'hb100, 288, 0);
VR.ram_fill32(32'hb280, 288, 0);
VR.ram_fill32(32'hb400, 288, 0);
VR.ram_fill32(32'hb580, 288, 0);
VR.ram_fill32(32'hb700, 288, 0);
VR.ram_fill32(32'hb880, 288, 0);
VR.ram_fill32(32'hba00, 288, 0);
VR.ram_fill32(32'hbb80, 288, 0);
VR.ram_fill32(32'hbd00, 288, 0);
VR.ram_fill32(32'hbe80, 288, 0);
VR.ram_fill32(32'hc000, 288, 0);
VR.ram_fill32(32'hc180, 288, 0);
VR.ram_fill32(32'hc300, 288, 0);
VR.ram_fill32(32'hc480, 288, 0);
VR.ram_fill32(32'hc600, 288, 0);
VR.ram_fill32(32'hc780, 288, 0);
VR.ram_fill32(32'hc900, 288, 0);
VR.ram_fill32(32'hca80, 288, 0);
VR.ram_fill32(32'hcc00, 288, 0);
VR.ram_fill32(32'hcd80, 288, 0);
VR.ram_fill32(32'hcf00, 288, 0);
VR.ram_fill32(32'hd080, 288, 0);
VR.ram_fill32(32'hd200, 288, 0);
VR.ram_fill32(32'hd380, 288, 0);
VR.ram_fill32(32'hd500, 288, 0);
VR.ram_fill32(32'hd680, 288, 0);
VR.ram_fill32(32'hd800, 288, 0);
VR.ram_fill32(32'hd980, 288, 0);
VR.ram_fill32(32'hdb00, 288, 0);
VR.ram_fill32(32'hdc80, 288, 0);
VR.ram_fill32(32'hde00, 288, 0);
VR.ram_fill32(32'hdf80, 288, 0);
VR.ram_fill32(32'he100, 288, 0);
VR.ram_fill32(32'he280, 288, 0);
VR.ram_fill32(32'he400, 288, 0);
VR.ram_fill32(32'he580, 288, 0);
VR.ram_fill32(32'he700, 288, 0);
VR.ram_fill32(32'he880, 288, 0);
VR.ram_fill32(32'hea00, 288, 0);
VR.ram_fill32(32'heb80, 288, 0);
VR.ram_fill32(32'hed00, 288, 0);
VR.ram_fill32(32'hee80, 288, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x600, 0x2000000, 0, 0, 287, 159); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h600);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h11f009f);
/* bbird_memxfer_setup(0, 0x8200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h8200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
/* bbird_memxfer_setup(1, 0x0, 0x0, 0x0, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW1_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_CTRL,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_WKEY,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_KYDAT,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_line_pat(0x16, 0x5); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h16);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h5);
wait_for_pipe_a;
/* bbird_colors(0x13, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h13);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x420c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h420c00);
/* bbird_font_write("Wow!"); { 0x3, 0x6 } */
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h42000300+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'h4e0c01);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
/* Writing character 'W' */
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_set_cache(hostbitmap, 0x0, 0xc); */
pci_burst_data(32'h10000000, 4'h0, 32'h0);
pci_burst_data(32'h10000004, 4'h0, 32'h0);
pci_burst_data(32'h10000008, 4'h0, 32'h0);
pci_burst_data(32'h1000000c, 4'h0, 32'h0);
pci_burst_data(32'h10000010, 4'h0, 32'h1fffe0);
pci_burst_data(32'h10000014, 4'h0, 32'h7ffe000);
pci_burst_data(32'h10000018, 4'h0, 32'h7ffff8);
pci_burst_data(32'h1000001c, 4'h0, 32'h1ffff800);
pci_burst_data(32'h10000020, 4'h0, 32'hfffffc);
pci_burst_data(32'h10000024, 4'h0, 32'h3ffffc00);
pci_burst_data(32'h10000028, 4'h0, 32'h1fffffe);
pci_burst_data(32'h1000002c, 4'h0, 32'h7ffffe00);
pci_burst_data(rbase_a+XY2,4'h0,32'h400006);
pci_burst_data(rbase_a+XY1,4'h0,32'h50006);
pci_burst_data(rbase_a+XY2,4'h0,32'h400010);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_set_cache(hostbitmap, 0x0, 0x20); */
pci_burst_data(32'h10000000, 4'h0, 32'h3fffffe);
pci_burst_data(32'h10000004, 4'h0, 32'h7ffffe00);
pci_burst_data(32'h10000008, 4'h0, 32'h3ffffff);
pci_burst_data(32'h1000000c, 4'h0, 32'hfbffff00);
pci_burst_data(32'h10000010, 4'h0, 32'h3e3ffff);
pci_burst_data(32'h10000014, 4'h0, 32'hf3ff3f00);
pci_burst_data(32'h10000018, 4'h0, 32'h3c1ffdf);
pci_burst_data(32'h1000001c, 4'h0, 32'hf3fc0f00);
pci_burst_data(32'h10000020, 4'h0, 32'h381ffcf);
pci_burst_data(32'h10000024, 4'h0, 32'hf3f80700);
pci_burst_data(32'h10000028, 4'h0, 32'h3a0ffcf);
pci_burst_data(32'h1000002c, 4'h0, 32'h7bf80300);
pci_burst_data(32'h10000030, 4'h0, 32'h1e0ffce);
pci_burst_data(32'h10000034, 4'h0, 32'h7cf00200);
pci_burst_data(32'h10000038, 4'h0, 32'hc0fe1e);
pci_burst_data(32'h1000003c, 4'h0, 32'h3f300403);
pci_burst_data(32'h10000040, 4'h0, 32'h8000e1fc);
pci_burst_data(32'h10000044, 4'h0, 32'hfc00007);
pci_burst_data(32'h10000048, 4'h0, 32'h1ff8);
pci_burst_data(32'h1000004c, 4'h0, 32'h3f80000);
pci_burst_data(32'h10000050, 4'h0, 32'hffffffc0);
pci_burst_data(32'h10000054, 4'h0, 32'hffffff);
pci_burst_data(32'h10000058, 4'h0, 32'hffffe000);
pci_burst_data(32'h1000005c, 4'h0, 32'h11fffff);
pci_burst_data(32'h10000060, 4'h0, 32'h1f80);
pci_burst_data(32'h10000064, 4'h0, 32'h1e00000);
pci_burst_data(32'h10000068, 4'h0, 32'he001ff80);
pci_burst_data(32'h1000006c, 4'h0, 32'h1f8001f);
pci_burst_data(32'h10000070, 4'h0, 32'hf001ff00);
pci_burst_data(32'h10000074, 4'h0, 32'hfc003f);
pci_burst_data(32'h10000078, 4'h0, 32'hf001ff00);
pci_burst_data(32'h1000007c, 4'h0, 32'hfc003f);
pci_burst_data(rbase_a+XY1,4'h0,32'h5000c);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_set_cache(hostbitmap, 0x0, 0x20); */
pci_burst_data(32'h10000000, 4'h0, 32'hf803ff00);
pci_burst_data(32'h10000004, 4'h0, 32'h7e007f);
pci_burst_data(32'h10000008, 4'h0, 32'hf803fe00);
pci_burst_data(32'h1000000c, 4'h0, 32'h7e007f);
pci_burst_data(32'h10000010, 4'h0, 32'hfc07fe00);
pci_burst_data(32'h10000014, 4'h0, 32'h3f00ff);
pci_burst_data(32'h10000018, 4'h0, 32'hfc07fe00);
pci_burst_data(32'h1000001c, 4'h0, 32'h3f00ff);
pci_burst_data(32'h10000020, 4'h0, 32'h7e0ffc00);
pci_burst_data(32'h10000024, 4'h0, 32'h1f81ff);
pci_burst_data(32'h10000028, 4'h0, 32'h7e0ffc00);
pci_burst_data(32'h1000002c, 4'h0, 32'h1f81ff);
pci_burst_data(32'h10000030, 4'h0, 32'h3f1ffc00);
pci_burst_data(32'h10000034, 4'h0, 32'hfc3ff);
pci_burst_data(32'h10000038, 4'h0, 32'h3f1ff800);
pci_burst_data(32'h1000003c, 4'h0, 32'hfc3fe);
pci_burst_data(32'h10000040, 4'h0, 32'h1fbff800);
pci_burst_data(32'h10000044, 4'h0, 32'h7e7fe);
pci_burst_data(32'h10000048, 4'h0, 32'h1ffff800);
pci_burst_data(32'h1000004c, 4'h0, 32'h7e7fe);
pci_burst_data(32'h10000050, 4'h0, 32'hffff000);
pci_burst_data(32'h10000054, 4'h0, 32'h3fffc);
pci_burst_data(32'h10000058, 4'h0, 32'hffff000);
pci_burst_data(32'h1000005c, 4'h0, 32'h3fffc);
pci_burst_data(32'h10000060, 4'h0, 32'h7fff000);
pci_burst_data(32'h10000064, 4'h0, 32'h1fffc);
pci_burst_data(32'h10000068, 4'h0, 32'h7ffe000);
pci_burst_data(32'h1000006c, 4'h0, 32'h1fff8);
pci_burst_data(32'h10000070, 4'h0, 32'h3ffe000);
pci_burst_data(32'h10000074, 4'h0, 32'hfff8);
pci_burst_data(32'h10000078, 4'h0, 32'h3ffc000);
pci_burst_data(32'h1000007c, 4'h0, 32'hfff8);
pci_burst_data(rbase_a+XY1,4'h0,32'h5001c);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_set_cache(hostbitmap, 0x0, 0x20); */
pci_burst_data(32'h10000000, 4'h0, 32'h1ffc000);
pci_burst_data(32'h10000004, 4'h0, 32'h7ff0);
pci_burst_data(32'h10000008, 4'h0, 32'hff8000);
pci_burst_data(32'h1000000c, 4'h0, 32'h3ff0);
pci_burst_data(32'h10000010, 4'h0, 32'h7f0000);
pci_burst_data(32'h10000014, 4'h0, 32'h1fe0);
pci_burst_data(32'h10000018, 4'h0, 32'h3e0000);
pci_burst_data(32'h1000001c, 4'h0, 32'hfc0);
pci_burst_data(32'h10000020, 4'h0, 32'h0);
pci_burst_data(32'h10000024, 4'h0, 32'h0);
pci_burst_data(32'h10000028, 4'h0, 32'h0);
pci_burst_data(32'h1000002c, 4'h0, 32'h0);
pci_burst_data(32'h10000030, 4'h0, 32'h0);
pci_burst_data(32'h10000034, 4'h0, 32'h0);
pci_burst_data(32'h10000038, 4'h0, 32'h0);
pci_burst_data(32'h1000003c, 4'h0, 32'h0);
pci_burst_data(32'h10000040, 4'h0, 32'h0);
pci_burst_data(32'h10000044, 4'h0, 32'h0);
pci_burst_data(32'h10000048, 4'h0, 32'h0);
pci_burst_data(32'h1000004c, 4'h0, 32'h0);
pci_burst_data(32'h10000050, 4'h0, 32'h0);
pci_burst_data(32'h10000054, 4'h0, 32'h0);
pci_burst_data(32'h10000058, 4'h0, 32'h0);
pci_burst_data(32'h1000005c, 4'h0, 32'h0);
pci_burst_data(32'h10000060, 4'h0, 32'h0);
pci_burst_data(32'h10000064, 4'h0, 32'h0);
pci_burst_data(32'h10000068, 4'h0, 32'h0);
pci_burst_data(32'h1000006c, 4'h0, 32'h0);
pci_burst_data(32'h10000070, 4'h0, 32'h0);
pci_burst_data(32'h10000074, 4'h0, 32'h0);
pci_burst_data(32'h10000078, 4'h0, 32'h0);
pci_burst_data(32'h1000007c, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h5002c);
/* Writing character 'o' */
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_set_cache(hostbitmap, 0x0, 0x16); */
pci_burst_data(32'h10000000, 4'h0, 32'h0);
pci_burst_data(32'h10000004, 4'h0, 32'h0);
pci_burst_data(32'h10000008, 4'h0, 32'h0);
pci_burst_data(32'h1000000c, 4'h0, 32'h0);
pci_burst_data(32'h10000010, 4'h0, 32'h0);
pci_burst_data(32'h10000014, 4'h0, 32'h0);
pci_burst_data(32'h10000018, 4'h0, 32'h0);
pci_burst_data(32'h1000001c, 4'h0, 32'h0);
pci_burst_data(32'h10000020, 4'h0, 32'h0);
pci_burst_data(32'h10000024, 4'h0, 32'h0);
pci_burst_data(32'h10000028, 4'h0, 32'h0);
pci_burst_data(32'h1000002c, 4'h0, 32'h0);
pci_burst_data(32'h10000030, 4'h0, 32'h0);
pci_burst_data(32'h10000034, 4'h0, 32'h0);
pci_burst_data(32'h10000038, 4'h0, 32'h801ffe00);
pci_burst_data(32'h1000003c, 4'h0, 32'hc0ffffc0);
pci_burst_data(32'h10000040, 4'h0, 32'hc3fffff0);
pci_burst_data(32'h10000044, 4'h0, 32'hc7fffff8);
pci_burst_data(32'h10000048, 4'h0, 32'h8ffc0ffc);
pci_burst_data(32'h1000004c, 4'h0, 32'hff003fc);
pci_burst_data(32'h10000050, 4'h0, 32'h1fe001fe);
pci_burst_data(32'h10000054, 4'h0, 32'h1fe001fe);
pci_burst_data(rbase_a+XY2,4'h0,32'h1e0016);
pci_burst_data(rbase_a+XY1,4'h0,32'h490006);
pci_burst_data(rbase_a+XY2,4'h0,32'h1e0020);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_set_cache(hostbitmap, 0x0, 0x20); */
pci_burst_data(32'h10000000, 4'h0, 32'h1fc000fe);
pci_burst_data(32'h10000004, 4'h0, 32'h3fc000ff);
pci_burst_data(32'h10000008, 4'h0, 32'h3fc000ff);
pci_burst_data(32'h1000000c, 4'h0, 32'h3fc000ff);
pci_burst_data(32'h10000010, 4'h0, 32'h3fc000ff);
pci_burst_data(32'h10000014, 4'h0, 32'h3fc000ff);
pci_burst_data(32'h10000018, 4'h0, 32'h3fc000ff);
pci_burst_data(32'h1000001c, 4'h0, 32'h3fc000ff);
pci_burst_data(32'h10000020, 4'h0, 32'h3fc000ff);
pci_burst_data(32'h10000024, 4'h0, 32'h3fc000ff);
pci_burst_data(32'h10000028, 4'h0, 32'h3fe001ff);
pci_burst_data(32'h1000002c, 4'h0, 32'h3fe001ff);
pci_burst_data(32'h10000030, 4'h0, 32'h3ff003ff);
pci_burst_data(32'h10000034, 4'h0, 32'h1ffc0ffe);
pci_burst_data(32'h10000038, 4'h0, 32'h1ffffffe);
pci_burst_data(32'h1000003c, 4'h0, 32'hffffffc);
pci_burst_data(32'h10000040, 4'h0, 32'h7fffff8);
pci_burst_data(32'h10000044, 4'h0, 32'h3fffff0);
pci_burst_data(32'h10000048, 4'h0, 32'hffffc0);
pci_burst_data(32'h1000004c, 4'h0, 32'h3fff00);
pci_burst_data(32'h10000050, 4'h0, 32'h0);
pci_burst_data(32'h10000054, 4'h0, 32'h0);
pci_burst_data(32'h10000058, 4'h0, 32'h0);
pci_burst_data(32'h1000005c, 4'h0, 32'h0);
pci_burst_data(32'h10000060, 4'h0, 32'h0);
pci_burst_data(32'h10000064, 4'h0, 32'h0);
pci_burst_data(32'h10000068, 4'h0, 32'h0);
pci_burst_data(32'h1000006c, 4'h0, 32'h0);
pci_burst_data(32'h10000070, 4'h0, 32'h0);
pci_burst_data(32'h10000074, 4'h0, 32'h80000000);
pci_burst_data(32'h10000078, 4'h0, 32'hc0000000);
pci_burst_data(32'h1000007c, 4'h0, 32'hc0000000);
pci_burst_data(rbase_a+XY1,4'h0,32'h49001c);
/* Writing character 'w' */
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_set_cache(hostbitmap, 0x0, 0x12); */
pci_burst_data(32'h10000000, 4'h0, 32'h0);
pci_burst_data(32'h10000004, 4'h0, 32'h0);
pci_burst_data(32'h10000008, 4'h0, 32'h0);
pci_burst_data(32'h1000000c, 4'h0, 32'h0);
pci_burst_data(32'h10000010, 4'h0, 32'h0);
pci_burst_data(32'h10000014, 4'h0, 32'h0);
pci_burst_data(32'h10000018, 4'h0, 32'h0);
pci_burst_data(32'h1000001c, 4'h0, 32'h0);
pci_burst_data(32'h10000020, 4'h0, 32'h0);
pci_burst_data(32'h10000024, 4'h0, 32'h0);
pci_burst_data(32'h10000028, 4'h0, 32'h0);
pci_burst_data(32'h1000002c, 4'h0, 32'h0);
pci_burst_data(32'h10000030, 4'h0, 32'h0);
pci_burst_data(32'h10000034, 4'h0, 32'h0);
pci_burst_data(32'h10000038, 4'h0, 32'h0);
pci_burst_data(32'h1000003c, 4'h0, 32'h0);
pci_burst_data(32'h10000040, 4'h0, 32'h0);
pci_burst_data(32'h10000044, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h2f000c);
pci_burst_data(rbase_a+XY1,4'h0,32'h6b0006);
pci_burst_data(rbase_a+XY2,4'h0,32'h2f0015);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_set_cache(hostbitmap, 0x0, 0x20); */
pci_burst_data(32'h10000000, 4'h0, 32'h0);
pci_burst_data(32'h10000004, 4'h0, 32'h0);
pci_burst_data(32'h10000008, 4'h0, 32'h0);
pci_burst_data(32'h1000000c, 4'h0, 32'hffe001f8);
pci_burst_data(32'h10000010, 4'h0, 32'h7fe01ff);
pci_burst_data(32'h10000014, 4'h0, 32'h7fffffc);
pci_burst_data(32'h10000018, 4'h0, 32'hff0e3f);
pci_burst_data(32'h1000001c, 4'h0, 32'h8c3f9ff0);
pci_burst_data(32'h10000020, 4'h0, 32'hbfc0003f);
pci_burst_data(32'h10000024, 4'h0, 32'h1fc87f);
pci_burst_data(32'h10000028, 4'h0, 32'hc07f7f00);
pci_burst_data(32'h1000002c, 4'h0, 32'h7e00000f);
pci_burst_data(32'h10000030, 4'h0, 32'h707c0ff);
pci_burst_data(32'h10000034, 4'h0, 32'hc0ff7c00);
pci_burst_data(32'h10000038, 4'h0, 32'h7c000707);
pci_burst_data(32'h1000003c, 4'h0, 32'hf83c1fe);
pci_burst_data(32'h10000040, 4'h0, 32'h81fe3c00);
pci_burst_data(32'h10000044, 4'h0, 32'h3c000f8b);
pci_burst_data(32'h10000048, 4'h0, 32'h1fcf03fc);
pci_burst_data(32'h1000004c, 4'h0, 32'h3fc1e00);
pci_burst_data(32'h10000050, 4'h0, 32'h1e001fc6);
pci_burst_data(32'h10000054, 4'h0, 32'h3fe007f8);
pci_burst_data(32'h10000058, 4'h0, 32'h7f80f00);
pci_burst_data(32'h1000005c, 4'h0, 32'hf003fe0);
pci_burst_data(32'h10000060, 4'h0, 32'h7f700ff0);
pci_burst_data(32'h10000064, 4'h0, 32'hff00780);
pci_burst_data(32'h10000068, 4'h0, 32'h7807f70);
pci_burst_data(32'h1000006c, 4'h0, 32'hfe381fe0);
pci_burst_data(32'h10000070, 4'h0, 32'h1fe003c0);
pci_burst_data(32'h10000074, 4'h0, 32'h3c0fe38);
pci_burst_data(32'h10000078, 4'h0, 32'hfc1c3fc0);
pci_burst_data(32'h1000007c, 4'h0, 32'h1e1);
pci_burst_data(rbase_a+XY1,4'h0,32'h6b0012);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_set_cache(hostbitmap, 0x0, 0x20); */
pci_burst_data(32'h10000000, 4'h0, 32'hfc1c3fc0);
pci_burst_data(32'h10000004, 4'h0, 32'h7f8001e1);
pci_burst_data(32'h10000008, 4'h0, 32'hf3f80e);
pci_burst_data(32'h1000000c, 4'h0, 32'hf80e7f80);
pci_burst_data(32'h10000010, 4'h0, 32'hff0000f3);
pci_burst_data(32'h10000014, 4'h0, 32'h7ff007);
pci_burst_data(32'h10000018, 4'h0, 32'hf007ff00);
pci_burst_data(32'h1000001c, 4'h0, 32'hfe00007f);
pci_burst_data(32'h10000020, 4'h0, 32'h3fe003);
pci_burst_data(32'h10000024, 4'h0, 32'he003fe00);
pci_burst_data(32'h10000028, 4'h0, 32'hfc00003f);
pci_burst_data(32'h1000002c, 4'h0, 32'h1fc001);
pci_burst_data(32'h10000030, 4'h0, 32'hc001fc00);
pci_burst_data(32'h10000034, 4'h0, 32'h1f);
pci_burst_data(32'h10000038, 4'h0, 32'h0);
pci_burst_data(32'h1000003c, 4'h0, 32'h0);
pci_burst_data(32'h10000040, 4'h0, 32'h0);
pci_burst_data(32'h10000044, 4'h0, 32'h0);
pci_burst_data(32'h10000048, 4'h0, 32'h0);
pci_burst_data(32'h1000004c, 4'h0, 32'h0);
pci_burst_data(32'h10000050, 4'h0, 32'h0);
pci_burst_data(32'h10000054, 4'h0, 32'h0);
pci_burst_data(32'h10000058, 4'h0, 32'h0);
pci_burst_data(32'h1000005c, 4'h0, 32'h0);
pci_burst_data(32'h10000060, 4'h0, 32'h0);
pci_burst_data(32'h10000064, 4'h0, 32'h0);
pci_burst_data(32'h10000068, 4'h0, 32'h0);
pci_burst_data(32'h1000006c, 4'h0, 32'h0);
pci_burst_data(32'h10000070, 4'h0, 32'h0);
pci_burst_data(32'h10000074, 4'h0, 32'h0);
pci_burst_data(32'h10000078, 4'h0, 32'h0);
pci_burst_data(32'h1000007c, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h6b0027);
/* Writing character '!' */
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_set_cache(hostbitmap, 0x0, 0x1b); */
pci_burst_data(32'h10000000, 4'h0, 32'h30000000);
pci_burst_data(32'h10000004, 4'h0, 32'hf1fe70fc);
pci_burst_data(32'h10000008, 4'h0, 32'hf3fff3ff);
pci_burst_data(32'h1000000c, 4'h0, 32'hf3fff3ff);
pci_burst_data(32'h10000010, 4'h0, 32'hf3fff3ff);
pci_burst_data(32'h10000014, 4'h0, 32'he3fcf3fe);
pci_burst_data(32'h10000018, 4'h0, 32'h3fcc3fc);
pci_burst_data(32'h1000001c, 4'h0, 32'h3fc03fc);
pci_burst_data(32'h10000020, 4'h0, 32'h3fc03fc);
pci_burst_data(32'h10000024, 4'h0, 32'h3fc03fc);
pci_burst_data(32'h10000028, 4'h0, 32'h3fc03fc);
pci_burst_data(32'h1000002c, 4'h0, 32'h3fc03fc);
pci_burst_data(32'h10000030, 4'h0, 32'h3fc03fc);
pci_burst_data(32'h10000034, 4'h0, 32'h3fc03fc);
pci_burst_data(32'h10000038, 4'h0, 32'hffc0ffc);
pci_burst_data(32'h1000003c, 4'h0, 32'h3f007f8);
pci_burst_data(32'h10000040, 4'h0, 32'h0);
pci_burst_data(32'h10000044, 4'h0, 32'h7f803f0);
pci_burst_data(32'h10000048, 4'h0, 32'hffc0ffc);
pci_burst_data(32'h1000004c, 4'h0, 32'hffc0ffc);
pci_burst_data(32'h10000050, 4'h0, 32'h3f007f8);
pci_burst_data(32'h10000054, 4'h0, 32'h0);
pci_burst_data(32'h10000058, 4'h0, 32'h0);
pci_burst_data(32'h1000005c, 4'h0, 32'h0);
pci_burst_data(32'h10000060, 4'h0, 32'h0);
pci_burst_data(32'h10000064, 4'h0, 32'h0);
pci_burst_data(32'h10000068, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'hc0036);
pci_burst_data(rbase_a+XY1,4'h0,32'h9c0006);
wait_for_pipe_a;
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'h4e0c01);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h120, 32'h60, "junk", 32'h600, 2'h2);
