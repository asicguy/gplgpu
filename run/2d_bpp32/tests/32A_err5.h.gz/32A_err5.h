///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2014 Francis Bruno, All Rights Reserved
// 
//  This program is free software; you can redistribute it and/or modify it 
//  under the terms of the GNU General Public License as published by the Free 
//  Software Foundation; either version 3 of the License, or (at your option) 
//  any later version.
//
//  This program is distributed in the hope that it will be useful, but 
//  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
//  or FITNESS FOR A PARTICULAR PURPOSE. 
//  See the GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License along with
//  this program; if not, see <http://www.gnu.org/licenses>.
//
//  This code is available under licenses for commercial use. Please contact
//  Francis Bruno for more information.
//
//  http://www.gplgpu.com
//  http://www.asicsolutions.com
//
//  Title       :  
//  File        :  
//  Author      :  Frank Bruno
//  Created     :  14-May-2011
//  RCS File    :  $Source:$
//  Status      :  $Id:$
//
///////////////////////////////////////////////////////////////////////////////
//
//  Description : 
//  2D test suite - 32 Bpp
//
//////////////////////////////////////////////////////////////////////////////
//
//  Modules Instantiated:
//
///////////////////////////////////////////////////////////////////////////////
//
//  Modification History:
//
//  $Log:$
//
//
///////////////////////////////////////////////////////////////////////////////
/* VERILOG logging on. */
/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'h600);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0x600, 0x2000000); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'h600);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x600, 0x2000000, 0, 0, 127, 63); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h600);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h7f003f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 128, 0);
VR.ram_fill32(32'h180, 128, 0);
VR.ram_fill32(32'h300, 128, 0);
VR.ram_fill32(32'h480, 128, 0);
VR.ram_fill32(32'h600, 128, 0);
VR.ram_fill32(32'h780, 128, 0);
VR.ram_fill32(32'h900, 128, 0);
VR.ram_fill32(32'ha80, 128, 0);
VR.ram_fill32(32'hc00, 128, 0);
VR.ram_fill32(32'hd80, 128, 0);
VR.ram_fill32(32'hf00, 128, 0);
VR.ram_fill32(32'h1080, 128, 0);
VR.ram_fill32(32'h1200, 128, 0);
VR.ram_fill32(32'h1380, 128, 0);
VR.ram_fill32(32'h1500, 128, 0);
VR.ram_fill32(32'h1680, 128, 0);
VR.ram_fill32(32'h1800, 128, 0);
VR.ram_fill32(32'h1980, 128, 0);
VR.ram_fill32(32'h1b00, 128, 0);
VR.ram_fill32(32'h1c80, 128, 0);
VR.ram_fill32(32'h1e00, 128, 0);
VR.ram_fill32(32'h1f80, 128, 0);
VR.ram_fill32(32'h2100, 128, 0);
VR.ram_fill32(32'h2280, 128, 0);
VR.ram_fill32(32'h2400, 128, 0);
VR.ram_fill32(32'h2580, 128, 0);
VR.ram_fill32(32'h2700, 128, 0);
VR.ram_fill32(32'h2880, 128, 0);
VR.ram_fill32(32'h2a00, 128, 0);
VR.ram_fill32(32'h2b80, 128, 0);
VR.ram_fill32(32'h2d00, 128, 0);
VR.ram_fill32(32'h2e80, 128, 0);
VR.ram_fill32(32'h3000, 128, 0);
VR.ram_fill32(32'h3180, 128, 0);
VR.ram_fill32(32'h3300, 128, 0);
VR.ram_fill32(32'h3480, 128, 0);
VR.ram_fill32(32'h3600, 128, 0);
VR.ram_fill32(32'h3780, 128, 0);
VR.ram_fill32(32'h3900, 128, 0);
VR.ram_fill32(32'h3a80, 128, 0);
VR.ram_fill32(32'h3c00, 128, 0);
VR.ram_fill32(32'h3d80, 128, 0);
VR.ram_fill32(32'h3f00, 128, 0);
VR.ram_fill32(32'h4080, 128, 0);
VR.ram_fill32(32'h4200, 128, 0);
VR.ram_fill32(32'h4380, 128, 0);
VR.ram_fill32(32'h4500, 128, 0);
VR.ram_fill32(32'h4680, 128, 0);
VR.ram_fill32(32'h4800, 128, 0);
VR.ram_fill32(32'h4980, 128, 0);
VR.ram_fill32(32'h4b00, 128, 0);
VR.ram_fill32(32'h4c80, 128, 0);
VR.ram_fill32(32'h4e00, 128, 0);
VR.ram_fill32(32'h4f80, 128, 0);
VR.ram_fill32(32'h5100, 128, 0);
VR.ram_fill32(32'h5280, 128, 0);
VR.ram_fill32(32'h5400, 128, 0);
VR.ram_fill32(32'h5580, 128, 0);
VR.ram_fill32(32'h5700, 128, 0);
VR.ram_fill32(32'h5880, 128, 0);
VR.ram_fill32(32'h5a00, 128, 0);
VR.ram_fill32(32'h5b80, 128, 0);
VR.ram_fill32(32'h5d00, 128, 0);
VR.ram_fill32(32'h5e80, 128, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0x600, 0x2000000, 0, 0, 127, 63); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'h600);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h7f003f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x8400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
wait_for_pipe_a;
/* bbird_line_pat(0x93939393, 0x10); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h93939393);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h10);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0x15, 0x16, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h15);
pci_burst_data(rbase_a+BACK,4'h0,32'h16);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_rectangle(0x5, 0x0, 0x25, 0x6); */
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 5, 0, 33, 7, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h210007);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h50000);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0x18, 0x17, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h18);
pci_burst_data(rbase_a+BACK,4'h0,32'h17);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_rectangle(0x10, 0x4, 0x20, 0xa); */
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 16, 4, 17, 7, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h110007);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h100004);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0xc00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'hc00);
/* bbird_area_pattern(0x20, 0x20, 0x2080000); */
wait_for_pipe_a;
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h42000300+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'hc01);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h200001);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ff3c, 0x0, 0x20, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h0);
pci_burst_data(32'h10000004, 4'h0, 32'h3c000);
pci_burst_data(32'h10000008, 4'h0, 32'h1c3800);
pci_burst_data(32'h1000000c, 4'h0, 32'h600600);
pci_burst_data(32'h10000010, 4'h0, 32'h8c3100);
pci_burst_data(32'h10000014, 4'h0, 32'h1142880);
pci_burst_data(32'h10000018, 4'h0, 32'h1181880);
pci_burst_data(32'h1000001c, 4'h0, 32'h2018040);
pci_burst_data(32'h10000020, 4'h0, 32'h203c040);
pci_burst_data(32'h10000024, 4'h0, 32'h1100880);
pci_burst_data(32'h10000028, 4'h0, 32'h10c3080);
pci_burst_data(32'h1000002c, 4'h0, 32'h83c100);
pci_burst_data(32'h10000030, 4'h0, 32'h600600);
pci_burst_data(32'h10000034, 4'h0, 32'h1c3800);
pci_burst_data(32'h10000038, 4'h0, 32'h3c000);
pci_burst_data(32'h1000003c, 4'h0, 32'h0);
pci_burst_data(32'h10000040, 4'h0, 32'h0);
pci_burst_data(32'h10000044, 4'h0, 32'h3c000);
pci_burst_data(32'h10000048, 4'h0, 32'h1c3800);
pci_burst_data(32'h1000004c, 4'h0, 32'h600600);
pci_burst_data(32'h10000050, 4'h0, 32'h8c3100);
pci_burst_data(32'h10000054, 4'h0, 32'h1142880);
pci_burst_data(32'h10000058, 4'h0, 32'h1181880);
pci_burst_data(32'h1000005c, 4'h0, 32'h2018040);
pci_burst_data(32'h10000060, 4'h0, 32'h203c040);
pci_burst_data(32'h10000064, 4'h0, 32'h1100880);
pci_burst_data(32'h10000068, 4'h0, 32'h10c3080);
pci_burst_data(32'h1000006c, 4'h0, 32'h83c100);
pci_burst_data(32'h10000070, 4'h0, 32'h600600);
pci_burst_data(32'h10000074, 4'h0, 32'h1c3800);
pci_burst_data(32'h10000078, 4'h0, 32'h3c000);
pci_burst_data(32'h1000007c, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h200020);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x2480c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h2480c00);
wait_for_pipe_a;
/* bbird_bitblit(32, 32, 31, 3, 34, 17, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h220011);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h200020);
pci_burst_data(rbase_a+XY1,4'h0,32'h1f0003);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* bbird_memxfer_setup(0, 0x8200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h8200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h40, 32'h10, "junk", 32'h600, 2'h2);
