///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2014 Francis Bruno, All Rights Reserved
// 
//  This program is free software; you can redistribute it and/or modify it 
//  under the terms of the GNU General Public License as published by the Free 
//  Software Foundation; either version 3 of the License, or (at your option) 
//  any later version.
//
//  This program is distributed in the hope that it will be useful, but 
//  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
//  or FITNESS FOR A PARTICULAR PURPOSE. 
//  See the GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License along with
//  this program; if not, see <http://www.gnu.org/licenses>.
//
//  This code is available under licenses for commercial use. Please contact
//  Francis Bruno for more information.
//
//  http://www.gplgpu.com
//  http://www.asicsolutions.com
//
//  Title       :  
//  File        :  
//  Author      :  Frank Bruno
//  Created     :  14-May-2011
//  RCS File    :  $Source:$
//  Status      :  $Id:$
//
///////////////////////////////////////////////////////////////////////////////
//
//  Description : 
//  2D test suite - 32 Bpp
//
//////////////////////////////////////////////////////////////////////////////
//
//  Modules Instantiated:
//
///////////////////////////////////////////////////////////////////////////////
//
//  Modification History:
//
//  $Log:$
//
//
///////////////////////////////////////////////////////////////////////////////
/* VERILOG logging on. */
/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'ha00);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0xa00, 0x2000000); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'ha00);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0xa00, 0x2000000, 0, 0, 191, 31); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'ha00);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'hbf001f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 192, 0);
VR.ram_fill32(32'h280, 192, 0);
VR.ram_fill32(32'h500, 192, 0);
VR.ram_fill32(32'h780, 192, 0);
VR.ram_fill32(32'ha00, 192, 0);
VR.ram_fill32(32'hc80, 192, 0);
VR.ram_fill32(32'hf00, 192, 0);
VR.ram_fill32(32'h1180, 192, 0);
VR.ram_fill32(32'h1400, 192, 0);
VR.ram_fill32(32'h1680, 192, 0);
VR.ram_fill32(32'h1900, 192, 0);
VR.ram_fill32(32'h1b80, 192, 0);
VR.ram_fill32(32'h1e00, 192, 0);
VR.ram_fill32(32'h2080, 192, 0);
VR.ram_fill32(32'h2300, 192, 0);
VR.ram_fill32(32'h2580, 192, 0);
VR.ram_fill32(32'h2800, 192, 0);
VR.ram_fill32(32'h2a80, 192, 0);
VR.ram_fill32(32'h2d00, 192, 0);
VR.ram_fill32(32'h2f80, 192, 0);
VR.ram_fill32(32'h3200, 192, 0);
VR.ram_fill32(32'h3480, 192, 0);
VR.ram_fill32(32'h3700, 192, 0);
VR.ram_fill32(32'h3980, 192, 0);
VR.ram_fill32(32'h3c00, 192, 0);
VR.ram_fill32(32'h3e80, 192, 0);
VR.ram_fill32(32'h4100, 192, 0);
VR.ram_fill32(32'h4380, 192, 0);
VR.ram_fill32(32'h4600, 192, 0);
VR.ram_fill32(32'h4880, 192, 0);
VR.ram_fill32(32'h4b00, 192, 0);
VR.ram_fill32(32'h4d80, 192, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0xa00, 0x2000000, 0, 0, 191, 31); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'ha00);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'hbf001f);
/* bbird_memxfer_setup(0, 0x8200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h8200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
/* bbird_memxfer_setup(1, 0x0, 0x0, 0x0, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW1_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_CTRL,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_WKEY,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_KYDAT,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_line_pat(0x16, 0x5); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h16);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h5);
wait_for_pipe_a;
/* bbird_colors(0x1, 0x9, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
pci_burst_data(rbase_a+BACK,4'h0,32'h9);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_rectangle(0x28, 0x8, 0x3b, 0xd); */
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 40, 8, 20, 6, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h140006);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h280008);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_write_pixel(0x0, 0x2, 0x33333333); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h33333333);
pci_burst_data(rbase_a+XY0,4'h0,32'h2);
pci_burst_data(rbase_a+XY1,4'h0,32'h2);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
wait_for_pipe_a;
/* bbird_write_pixel(0x2, 0x3, 0x33333333); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h33333333);
pci_burst_data(rbase_a+XY0,4'h0,32'h20003);
pci_burst_data(rbase_a+XY1,4'h0,32'h20003);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
wait_for_pipe_a;
/* bbird_colors(0x13, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h13);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
pci_burst_data(32'h40000004, 4'h0, 32'h01020300);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x420c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h420c00);
/* bbird_font_write("Hello world!"); { 0x5, 0x2 } */
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'h4e0c01);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+32'hF8,4'h0,32'h0);
/* Writing character 'H' */
/* bbird_font_cache(0, 32, 'H', 0x1); */
/* caching character 'H' */
pci_burst_data(32'ha0014000, 4'h0, 32'h0);
pci_burst_data(32'ha0014004, 4'h0, 32'h0);
pci_burst_data(32'ha0014008, 4'h0, 32'h3cc000);
pci_burst_data(32'ha001400c, 4'h0, 32'h3e6000);
pci_burst_data(32'ha0014010, 4'h0, 32'hc0033ffc);
pci_burst_data(32'ha0014014, 4'h0, 32'he0019ffe);
pci_burst_data(32'ha0014018, 4'h0, 32'h7000cfff);
pci_burst_data(32'ha001401c, 4'h0, 32'h3000e7ff);
pci_burst_data(32'ha0014020, 4'h0, 32'h30c0f303);
pci_burst_data(32'ha0014024, 4'h0, 32'h11e0f383);
pci_burst_data(32'ha0014028, 4'h0, 32'h3f0f3c0);
pci_burst_data(32'ha001402c, 4'h0, 32'h7f8f3c0);
pci_burst_data(32'ha0014030, 4'h0, 32'hfccf3c0);
pci_burst_data(32'ha0014034, 4'h0, 32'hf86f3c0);
pci_burst_data(32'ha0014038, 4'h0, 32'hf03f3c0);
pci_burst_data(32'ha001403c, 4'h0, 32'hf01f3c0);
pci_burst_data(32'ha0014040, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha0014044, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha0014048, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha001404c, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha0014050, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha0014054, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha0014058, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha001405c, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha0014060, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha0014064, 4'h0, 32'hf00f3c0);
pci_burst_data(32'ha0014068, 4'h0, 32'hcf00f3c0);
pci_burst_data(32'ha001406c, 4'h0, 32'hef00f3c0);
pci_burst_data(32'ha0014070, 4'h0, 32'hf780f3c0);
pci_burst_data(32'ha0014074, 4'h0, 32'hf3c079e0);
pci_burst_data(32'ha0014078, 4'h0, 32'h31e03cf0);
pci_burst_data(32'ha001407c, 4'h0, 32'h10f01ef8);
pci_burst_data(32'ha0014080, 4'h0, 32'h780ffc);
pci_burst_data(32'ha0014084, 4'h0, 32'h3c07fe);
pci_burst_data(32'ha0014088, 4'h0, 32'h1c0003);
pci_burst_data(32'ha001408c, 4'h0, 32'h180001);
pci_burst_data(32'ha0014090, 4'h0, 32'h300000);
pci_burst_data(32'ha0014094, 4'h0, 32'h200000);
pci_burst_data(32'ha0014098, 4'h0, 32'h0);
pci_burst_data(32'ha001409c, 4'h0, 32'h0);
wait_for_pipe_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h20);
pci_burst_data(rbase_a+XY2,4'h0,32'h1c0028);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h80002);
/* Writing character 'e' */
/* bbird_font_cache(40, 32, 'e', 0x1); */
/* caching character 'e' */
pci_burst_data(32'ha00140a0, 4'h0, 32'h0);
pci_burst_data(32'ha00140a4, 4'h0, 32'h0);
pci_burst_data(32'ha00140a8, 4'h0, 32'h0);
pci_burst_data(32'ha00140ac, 4'h0, 32'h0);
pci_burst_data(32'ha00140b0, 4'h0, 32'h0);
pci_burst_data(32'ha00140b4, 4'h0, 32'hf800700);
pci_burst_data(32'ha00140b8, 4'h0, 32'h3fe01fc0);
pci_burst_data(32'ha00140bc, 4'h0, 32'h7e387f30);
pci_burst_data(32'ha00140c0, 4'h0, 32'h3c3e7c3c);
pci_burst_data(32'ha00140c4, 4'h0, 32'hc3d1c3f);
pci_burst_data(32'ha00140c8, 4'h0, 32'h33c063c);
pci_burst_data(32'ha00140cc, 4'h0, 32'hfc01fc);
pci_burst_data(32'ha00140d0, 4'h0, 32'hfc00fc);
pci_burst_data(32'ha00140d4, 4'h0, 32'hc3fe81fc);
pci_burst_data(32'ha00140d8, 4'h0, 32'h3ff07ff9);
pci_burst_data(32'ha00140dc, 4'h0, 32'hfc01fe0);
pci_burst_data(32'ha00140e0, 4'h0, 32'h3000780);
pci_burst_data(32'ha00140e4, 4'h0, 32'h0);
pci_burst_data(32'ha00140e8, 4'h0, 32'h0);
pci_burst_data(32'ha00140ec, 4'h0, 32'h0);
wait_for_pipe_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h280020);
pci_burst_data(rbase_a+XY2,4'h0,32'h100028);
pci_burst_data(rbase_a+XY3,4'h0,32'h6);
pci_burst_data(rbase_a+XY1,4'h0,32'h260002);
/* Writing character 'l' */
/* bbird_font_cache(60, 32, 'l', 0x1); */
/* caching character 'l' */
pci_burst_data(32'ha00140f0, 4'h0, 32'hc0800000);
pci_burst_data(32'ha00140f4, 4'h0, 32'h3c3c3663);
pci_burst_data(32'ha00140f8, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha00140fc, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha0014100, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha0014104, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha0014108, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha001410c, 4'h0, 32'hf8fc3e3f);
pci_burst_data(32'ha0014110, 4'h0, 32'h2070);
pci_burst_data(32'ha0014114, 4'h0, 32'h0);
wait_for_pipe_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h3c0020);
pci_burst_data(rbase_a+XY2,4'h0,32'h80028);
pci_burst_data(rbase_a+XY3,4'h0,32'h4);
pci_burst_data(rbase_a+XY1,4'h0,32'h380002);
/* Writing character 'l' */
wait_for_pipe_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h3c0020);
pci_burst_data(rbase_a+XY2,4'h0,32'h80028);
pci_burst_data(rbase_a+XY3,4'h0,32'h4);
pci_burst_data(rbase_a+XY1,4'h0,32'h430002);
/* Writing character 'o' */
/* bbird_font_cache(70, 32, 'o', 0x1); */
/* caching character 'o' */
pci_burst_data(32'ha0014118, 4'h0, 32'h0);
pci_burst_data(32'ha001411c, 4'h0, 32'h0);
pci_burst_data(32'ha0014120, 4'h0, 32'h0);
pci_burst_data(32'ha0014124, 4'h0, 32'h0);
pci_burst_data(32'ha0014128, 4'h0, 32'h0);
pci_burst_data(32'ha001412c, 4'h0, 32'h7800300);
pci_burst_data(32'ha0014130, 4'h0, 32'h9fe00fc0);
pci_burst_data(32'ha0014134, 4'h0, 32'h7ff8dff0);
pci_burst_data(32'ha0014138, 4'h0, 32'h3e0e3f1c);
pci_burst_data(32'ha001413c, 4'h0, 32'h3c0f3c0e);
pci_burst_data(32'ha0014140, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha0014144, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha0014148, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha001414c, 4'h0, 32'h1c3e3c1f);
pci_burst_data(32'ha0014150, 4'h0, 32'hefc1c7e);
pci_burst_data(32'ha0014154, 4'h0, 32'h3f007f8);
pci_burst_data(32'ha0014158, 4'h0, 32'hc001e0);
pci_burst_data(32'ha001415c, 4'h0, 32'h0);
pci_burst_data(32'ha0014160, 4'h0, 32'h0);
pci_burst_data(32'ha0014164, 4'h0, 32'h0);
wait_for_pipe_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h460020);
pci_burst_data(rbase_a+XY2,4'h0,32'he0028);
pci_burst_data(rbase_a+XY3,4'h0,32'h6);
pci_burst_data(rbase_a+XY1,4'h0,32'h4d0002);
/* Writing character ' ' */
/* bbird_font_cache(90, 32, ' ', 0x1); */
/* caching character ' ' */
/* Writing character 'w' */
/* bbird_font_cache(90, 32, 'w', 0x1); */
/* caching character 'w' */
pci_burst_data(32'ha0014168, 4'h0, 32'h0);
pci_burst_data(32'ha001416c, 4'h0, 32'h0);
pci_burst_data(32'ha0014170, 4'h0, 32'h0);
pci_burst_data(32'ha0014174, 4'h0, 32'h18000030);
pci_burst_data(32'ha0014178, 4'h0, 32'hc0000);
pci_burst_data(32'ha001417c, 4'h0, 32'he00);
pci_burst_data(32'ha0014180, 4'h0, 32'h7000007);
pci_burst_data(32'ha0014184, 4'h0, 32'h80f0000);
pci_burst_data(32'ha0014188, 4'h0, 32'h1c1c1f08);
pci_burst_data(32'ha001418c, 4'h0, 32'h7e3e3e3f);
pci_burst_data(32'ha0014190, 4'h0, 32'hfcfc3d7f);
pci_burst_data(32'ha0014194, 4'h0, 32'hbc7c7c3c);
pci_burst_data(32'ha0014198, 4'h0, 32'h3cfc3c3c);
pci_burst_data(32'ha001419c, 4'h0, 32'h3c3c7c3c);
pci_burst_data(32'ha00141a0, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha00141a4, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha00141a8, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha00141ac, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha00141b0, 4'h0, 32'h3c3c3c3c);
pci_burst_data(32'ha00141b4, 4'h0, 32'h3c3c7c3c);
pci_burst_data(32'ha00141b8, 4'h0, 32'hfc3c3cfc);
pci_burst_data(32'ha00141bc, 4'h0, 32'hfefc7c7f);
pci_burst_data(32'ha00141c0, 4'h0, 32'hc7f0fcfc);
pci_burst_data(32'ha00141c4, 4'h0, 32'hcf83e0df);
pci_burst_data(32'ha00141c8, 4'h0, 32'h80c701c0);
pci_burst_data(32'ha00141cc, 4'h0, 32'h4200);
pci_burst_data(32'ha00141d0, 4'h0, 32'h0);
pci_burst_data(32'ha00141d4, 4'h0, 32'h0);
pci_burst_data(32'ha00141d8, 4'h0, 32'h0);
pci_burst_data(32'ha00141dc, 4'h0, 32'h0);
wait_for_pipe_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h5a0020);
pci_burst_data(rbase_a+XY2,4'h0,32'h160028);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h690002);
/* Writing character 'o' */
wait_for_pipe_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h460020);
pci_burst_data(rbase_a+XY2,4'h0,32'he0028);
pci_burst_data(rbase_a+XY3,4'h0,32'h6);
pci_burst_data(rbase_a+XY1,4'h0,32'h800002);
/* Writing character 'r' */
/* bbird_font_cache(120, 32, 'r', 0x1); */
/* caching character 'r' */
pci_burst_data(32'ha00141e0, 4'h0, 32'h0);
pci_burst_data(32'ha00141e4, 4'h0, 32'h0);
pci_burst_data(32'ha00141e8, 4'h0, 32'h0);
pci_burst_data(32'ha00141ec, 4'h0, 32'h0);
pci_burst_data(32'ha00141f0, 4'h0, 32'h0);
pci_burst_data(32'ha00141f4, 4'h0, 32'h0);
pci_burst_data(32'ha00141f8, 4'h0, 32'h0);
pci_burst_data(32'ha00141fc, 4'h0, 32'h30300000);
pci_burst_data(32'ha0014200, 4'h0, 32'h787800);
pci_burst_data(32'ha0014204, 4'h0, 32'hfe00fcfc);
pci_burst_data(32'ha0014208, 4'h0, 32'hf3f701ff);
pci_burst_data(32'ha001420c, 4'h0, 32'hc3e1f383);
pci_burst_data(32'ha0014210, 4'h0, 32'hf0e3c0f0);
pci_burst_data(32'ha0014214, 4'h0, 32'hc0f0e3c0);
pci_burst_data(32'ha0014218, 4'h0, 32'he0c0f0e1);
pci_burst_data(32'ha001421c, 4'h0, 32'hf0e000f0);
pci_burst_data(32'ha0014220, 4'h0, 32'hf0e000);
pci_burst_data(32'ha0014224, 4'h0, 32'h8000f0c0);
pci_burst_data(32'ha0014228, 4'h0, 32'hf00000f0);
pci_burst_data(32'ha001422c, 4'h0, 32'hf40000);
pci_burst_data(32'ha0014230, 4'h0, 32'hc000fc80);
pci_burst_data(32'ha0014234, 4'h0, 32'hf0e03cf8);
pci_burst_data(32'ha0014238, 4'h0, 32'hfe0f01e);
pci_burst_data(32'ha001423c, 4'h0, 32'hc07c0f8);
pci_burst_data(32'ha0014240, 4'h0, 32'h40380);
pci_burst_data(32'ha0014244, 4'h0, 32'h1);
pci_burst_data(32'ha0014248, 4'h0, 32'h0);
pci_burst_data(32'ha001424c, 4'h0, 32'h0);
pci_burst_data(32'ha0014250, 4'h0, 32'h0);
pci_burst_data(32'ha0014254, 4'h0, 32'h0);
wait_for_pipe_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h780020);
pci_burst_data(rbase_a+XY2,4'h0,32'h120028);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h8f0002);
/* Writing character 'l' */
wait_for_pipe_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h3c0020);
pci_burst_data(rbase_a+XY2,4'h0,32'h80028);
pci_burst_data(rbase_a+XY3,4'h0,32'h4);
pci_burst_data(rbase_a+XY1,4'h0,32'ha30002);
/* Writing character 'd' */
/* bbird_font_cache(150, 32, 'd', 0x1); */
/* caching character 'd' */
pci_burst_data(32'ha0014258, 4'h0, 32'h0);
pci_burst_data(32'ha001425c, 4'h0, 32'h0);
pci_burst_data(32'ha0014260, 4'h0, 32'h1e000c);
pci_burst_data(32'ha0014264, 4'h0, 32'h7f003f);
pci_burst_data(32'ha0014268, 4'h0, 32'h1fb00ff);
pci_burst_data(32'ha001426c, 4'h0, 32'h7e003f0);
pci_burst_data(32'ha0014270, 4'h0, 32'h7fe0cfc0);
pci_burst_data(32'ha0014274, 4'h0, 32'h3e183f30);
pci_burst_data(32'ha0014278, 4'h0, 32'h3c0e3c0c);
pci_burst_data(32'ha001427c, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha0014280, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha0014284, 4'h0, 32'h3c0f3c0f);
pci_burst_data(32'ha0014288, 4'h0, 32'h3c3f3c1f);
pci_burst_data(32'ha001428c, 4'h0, 32'h3cff3c7f);
pci_burst_data(32'ha0014290, 4'h0, 32'hffc1ffe);
pci_burst_data(32'ha0014294, 4'h0, 32'h3f007f8);
pci_burst_data(32'ha0014298, 4'h0, 32'hc001e0);
pci_burst_data(32'ha001429c, 4'h0, 32'h0);
pci_burst_data(32'ha00142a0, 4'h0, 32'h0);
pci_burst_data(32'ha00142a4, 4'h0, 32'h0);
wait_for_pipe_a;
pci_burst_data(rbase_a+XY0,4'h0,32'h960020);
pci_burst_data(rbase_a+XY2,4'h0,32'h100028);
pci_burst_data(rbase_a+XY3,4'h0,32'h6);
pci_burst_data(rbase_a+XY1,4'h0,32'had0002);
/* Writing character '!' */
/* bbird_font_cache(170, 32, '!', 0x1); */
/* caching character '!' */
pci_burst_data(32'ha00142a8, 4'h0, 32'h0);
pci_burst_data(32'ha00142ac, 4'h0, 32'h0);
pci_burst_data(32'ha00142b0, 4'h0, 32'h78783030);
pci_burst_data(32'ha00142b4, 4'h0, 32'hfdfefcfc);
pci_burst_data(32'ha00142b8, 4'h0, 32'hffffffff);
pci_burst_data(32'ha00142bc, 4'h0, 32'h79fe7bff);
pci_burst_data(32'ha00142c0, 4'h0, 32'h31fe31fe);
pci_burst_data(32'ha00142c4, 4'h0, 32'hfc01fe);
pci_burst_data(32'ha00142c8, 4'h0, 32'hfc00fc);
pci_burst_data(32'ha00142cc, 4'h0, 32'h780078);
pci_burst_data(32'ha00142d0, 4'h0, 32'h780078);
pci_burst_data(32'ha00142d4, 4'h0, 32'h300030);
pci_burst_data(32'ha00142d8, 4'h0, 32'h0);
pci_burst_data(32'ha00142dc, 4'h0, 32'h780030);
pci_burst_data(32'ha00142e0, 4'h0, 32'hfc00fc);
pci_burst_data(32'ha00142e4, 4'h0, 32'h300078);
pci_burst_data(32'ha00142e8, 4'h0, 32'h0);
pci_burst_data(32'ha00142ec, 4'h0, 32'h0);
pci_burst_data(32'ha00142f0, 4'h0, 32'h0);
pci_burst_data(32'ha00142f4, 4'h0, 32'h0);
wait_for_pipe_a;
pci_burst_data(rbase_a+XY0,4'h0,32'haa0020);
pci_burst_data(rbase_a+XY2,4'h0,32'ha0028);
pci_burst_data(rbase_a+XY3,4'h0,32'h6);
pci_burst_data(rbase_a+XY1,4'h0,32'hc00002);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x420c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h420c00);
rd(MEM_RD, 32'h40000000, 1);
wait_for_pipe_a;
/* bbird_write_pixel(0x2, 0x5, 0xcc); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'hcc);
pci_burst_data(rbase_a+XY0,4'h0,32'h20005);
pci_burst_data(rbase_a+XY1,4'h0,32'h20005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h420c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'hc0, 32'h20, "junk", 32'ha00, 2'h2);
