///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2014 Francis Bruno, All Rights Reserved
// 
//  This program is free software; you can redistribute it and/or modify it 
//  under the terms of the GNU General Public License as published by the Free 
//  Software Foundation; either version 3 of the License, or (at your option) 
//  any later version.
//
//  This program is distributed in the hope that it will be useful, but 
//  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
//  or FITNESS FOR A PARTICULAR PURPOSE. 
//  See the GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License along with
//  this program; if not, see <http://www.gnu.org/licenses>.
//
//  This code is available under licenses for commercial use. Please contact
//  Francis Bruno for more information.
//
//  http://www.gplgpu.com
//  http://www.asicsolutions.com
//
//  Title       :  
//  File        :  
//  Author      :  Frank Bruno
//  Created     :  14-May-2011
//  RCS File    :  $Source:$
//  Status      :  $Id:$
//
///////////////////////////////////////////////////////////////////////////////
//
//  Description : 
//  2D test suite - 32 Bpp
//
//////////////////////////////////////////////////////////////////////////////
//
//  Modules Instantiated:
//
///////////////////////////////////////////////////////////////////////////////
//
//  Modification History:
//
//  $Log:$
//
//
///////////////////////////////////////////////////////////////////////////////
/* VERILOG logging on. */
/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'ha00);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'h190);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h40);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h1);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0xa00, 0x2000000); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'ha00);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0xa00, 0x2000000, 0, 0, 255, 63); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'ha00);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'hff003f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 256, 0);
VR.ram_fill32(32'h280, 256, 0);
VR.ram_fill32(32'h500, 256, 0);
VR.ram_fill32(32'h780, 256, 0);
VR.ram_fill32(32'ha00, 256, 0);
VR.ram_fill32(32'hc80, 256, 0);
VR.ram_fill32(32'hf00, 256, 0);
VR.ram_fill32(32'h1180, 256, 0);
VR.ram_fill32(32'h1400, 256, 0);
VR.ram_fill32(32'h1680, 256, 0);
VR.ram_fill32(32'h1900, 256, 0);
VR.ram_fill32(32'h1b80, 256, 0);
VR.ram_fill32(32'h1e00, 256, 0);
VR.ram_fill32(32'h2080, 256, 0);
VR.ram_fill32(32'h2300, 256, 0);
VR.ram_fill32(32'h2580, 256, 0);
VR.ram_fill32(32'h2800, 256, 0);
VR.ram_fill32(32'h2a80, 256, 0);
VR.ram_fill32(32'h2d00, 256, 0);
VR.ram_fill32(32'h2f80, 256, 0);
VR.ram_fill32(32'h3200, 256, 0);
VR.ram_fill32(32'h3480, 256, 0);
VR.ram_fill32(32'h3700, 256, 0);
VR.ram_fill32(32'h3980, 256, 0);
VR.ram_fill32(32'h3c00, 256, 0);
VR.ram_fill32(32'h3e80, 256, 0);
VR.ram_fill32(32'h4100, 256, 0);
VR.ram_fill32(32'h4380, 256, 0);
VR.ram_fill32(32'h4600, 256, 0);
VR.ram_fill32(32'h4880, 256, 0);
VR.ram_fill32(32'h4b00, 256, 0);
VR.ram_fill32(32'h4d80, 256, 0);
VR.ram_fill32(32'h5000, 256, 0);
VR.ram_fill32(32'h5280, 256, 0);
VR.ram_fill32(32'h5500, 256, 0);
VR.ram_fill32(32'h5780, 256, 0);
VR.ram_fill32(32'h5a00, 256, 0);
VR.ram_fill32(32'h5c80, 256, 0);
VR.ram_fill32(32'h5f00, 256, 0);
VR.ram_fill32(32'h6180, 256, 0);
VR.ram_fill32(32'h6400, 256, 0);
VR.ram_fill32(32'h6680, 256, 0);
VR.ram_fill32(32'h6900, 256, 0);
VR.ram_fill32(32'h6b80, 256, 0);
VR.ram_fill32(32'h6e00, 256, 0);
VR.ram_fill32(32'h7080, 256, 0);
VR.ram_fill32(32'h7300, 256, 0);
VR.ram_fill32(32'h7580, 256, 0);
VR.ram_fill32(32'h7800, 256, 0);
VR.ram_fill32(32'h7a80, 256, 0);
VR.ram_fill32(32'h7d00, 256, 0);
VR.ram_fill32(32'h7f80, 256, 0);
VR.ram_fill32(32'h8200, 256, 0);
VR.ram_fill32(32'h8480, 256, 0);
VR.ram_fill32(32'h8700, 256, 0);
VR.ram_fill32(32'h8980, 256, 0);
VR.ram_fill32(32'h8c00, 256, 0);
VR.ram_fill32(32'h8e80, 256, 0);
VR.ram_fill32(32'h9100, 256, 0);
VR.ram_fill32(32'h9380, 256, 0);
VR.ram_fill32(32'h9600, 256, 0);
VR.ram_fill32(32'h9880, 256, 0);
VR.ram_fill32(32'h9b00, 256, 0);
VR.ram_fill32(32'h9d80, 256, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0xa00, 0x2000000, 0, 0, 255, 63); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'ha00);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'hff003f);
/* bbird_memxfer_setup(0, 0x8200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h8200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
/* bbird_memxfer_setup(1, 0x0, 0x0, 0x0, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW1_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_CTRL,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_WKEY,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_KYDAT,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW1_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xaaff, 0xff0055, 0x0, 0xf); */
pci_burst_data(rbase_a+FORE,4'h0,32'haaff);
pci_burst_data(rbase_a+BACK,4'h0,32'hff0055);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line(1, 1, 8, 8); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h10001);
pci_burst_data(rbase_a+XY1,4'h0,32'h80008);
wait_for_pipe_a;
/* bbird_colors(0xff0055, 0xaaff, 0x0, 0xf); */
pci_burst_data(rbase_a+FORE,4'h0,32'hff0055);
pci_burst_data(rbase_a+BACK,4'h0,32'haaff);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line(4, 1, 4, 8); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h40001);
pci_burst_data(rbase_a+XY1,4'h0,32'h40008);
wait_for_pipe_a;
/* bbird_colors(0x5500ff, 0xaaff, 0x0, 0xf); */
pci_burst_data(rbase_a+FORE,4'h0,32'h5500ff);
pci_burst_data(rbase_a+BACK,4'h0,32'haaff);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line(1, 4, 8, 4); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h10004);
pci_burst_data(rbase_a+XY1,4'h0,32'h80004);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_colors(0xaa5500, 0xac5505, 0x0, 0xf); */
pci_burst_data(rbase_a+FORE,4'h0,32'haa5500);
pci_burst_data(rbase_a+BACK,4'h0,32'hac5505);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
/* bbird_font_write("Multiple test"); { 0x6, 0x20 } */
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
pci_burst_data(rbase_a+FORE,4'h0,32'hac5505);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 6, 32, 139, 22, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h8b0016);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h60020);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'haa5500);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'h4c0c01);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+32'hF8,4'h0,32'h0);
/* Writing character 'M' */
/* bbird_font_cache(0, 64, 'M', 0x1); */
/* caching character 'M' */
pci_burst_data(32'ha0028000, 4'h0, 32'h0);
pci_burst_data(32'ha0028004, 4'h0, 32'hfffc0000);
pci_burst_data(32'ha0028008, 4'h0, 32'hbfdf7e1f);
pci_burst_data(32'ha002800c, 4'h0, 32'h33e78e37);
pci_burst_data(32'ha0028010, 4'h0, 32'he06e78e);
pci_burst_data(32'ha0028014, 4'h0, 32'hc001c33);
pci_burst_data(32'ha0028018, 4'h0, 32'h1803ffe0);
pci_burst_data(32'ha002801c, 4'h0, 32'he1c0c00);
pci_burst_data(32'ha0028020, 4'h0, 32'h1e0e1c1e);
pci_burst_data(32'ha0028024, 4'h0, 32'h1e1e0e1c);
pci_burst_data(32'ha0028028, 4'h0, 32'he1e3e0e);
pci_burst_data(32'ha002802c, 4'h0, 32'h3f4e5e3e);
pci_burst_data(32'ha0028030, 4'h0, 32'h1f843c);
pci_burst_data(32'ha0028034, 4'h0, 32'h0);
pci_burst_data(32'ha0028038, 4'h0, 32'h0);
pci_burst_data(32'ha002803c, 4'h0, 32'h0);
pci_burst_data(32'ha0028040, 4'h0, 32'h0);
pci_burst_data(32'ha0028048, 4'h0, 32'h28000);
pci_burst_data(32'ha002804c, 4'h0, 32'h1716);
/* Writing character 'u' */
/* bbird_font_cache(20, 64, 'u', 0x1); */
/* caching character 'u' */
pci_burst_data(32'ha0028050, 4'h0, 32'h0);
pci_burst_data(32'ha0028054, 4'h0, 32'h0);
pci_burst_data(32'ha0028058, 4'h0, 32'h0);
pci_burst_data(32'ha002805c, 4'h0, 32'hf70ee787);
pci_burst_data(32'ha0028060, 4'h0, 32'he70ef70e);
pci_burst_data(32'ha0028064, 4'h0, 32'h870ec70e);
pci_burst_data(32'ha0028068, 4'h0, 32'h70e870e);
pci_burst_data(32'ha002806c, 4'h0, 32'h7fc079e);
pci_burst_data(32'ha0028070, 4'h0, 32'hef8);
pci_burst_data(32'ha0028074, 4'h0, 32'h0);
pci_burst_data(32'ha0028078, 4'h0, 32'h0);
pci_burst_data(32'ha0028080, 4'h0, 32'h28050);
pci_burst_data(32'ha0028084, 4'h0, 32'hc16);
pci_burst_data(32'ha0000000, 4'h0, 32'ha028048);
pci_burst_data(32'ha0000004, 4'h0, 32'h70020);
pci_burst_data(32'ha0000008, 4'h0, 32'h28080);
pci_burst_data(32'ha000000c, 4'h0, 32'h200020);
/* Writing character 'l' */
/* bbird_font_cache(36, 64, 'l', 0x1); */
/* caching character 'l' */
pci_burst_data(32'ha0028090, 4'h0, 32'hf060000);
pci_burst_data(32'ha0028094, 4'h0, 32'hceee0e0f);
pci_burst_data(32'ha0028098, 4'h0, 32'hcececece);
pci_burst_data(32'ha002809c, 4'h0, 32'hcececece);
pci_burst_data(32'ha00280a0, 4'h0, 32'hff);
pci_burst_data(32'ha00280a4, 4'h0, 32'h0);
pci_burst_data(32'ha00280a8, 4'h0, 32'h60028090);
pci_burst_data(32'ha00280ac, 4'h0, 32'h516);
/* Writing character 't' */
/* bbird_font_cache(44, 64, 't', 0x1); */
/* caching character 't' */
pci_burst_data(32'ha00280b0, 4'h0, 32'he0c0000);
pci_burst_data(32'ha00280b4, 4'h0, 32'h3f8e0e0e);
pci_burst_data(32'ha00280b8, 4'h0, 32'he0e4e7f);
pci_burst_data(32'ha00280bc, 4'h0, 32'he0e0e0e);
pci_burst_data(32'ha00280c0, 4'h0, 32'h3c);
pci_burst_data(32'ha00280c4, 4'h0, 32'h0);
pci_burst_data(32'ha00280c8, 4'h0, 32'h600280b0);
pci_burst_data(32'ha00280cc, 4'h0, 32'h716);
pci_burst_data(32'ha0000010, 4'h0, 32'ha0280a8);
pci_burst_data(32'ha0000014, 4'h0, 32'h2e0020);
pci_burst_data(32'ha0000018, 4'h0, 32'h280c8);
pci_burst_data(32'ha000001c, 4'h0, 32'h350020);
/* Writing character 'i' */
/* bbird_font_cache(52, 64, 'i', 0x1); */
/* caching character 'i' */
pci_burst_data(32'ha00280d0, 4'h0, 32'he0e0400);
pci_burst_data(32'ha00280d4, 4'h0, 32'h1e0c0004);
pci_burst_data(32'ha00280d8, 4'h0, 32'he0e8f9f);
pci_burst_data(32'ha00280dc, 4'h0, 32'hf0e0e0e);
pci_burst_data(32'ha00280e0, 4'h0, 32'h6060c007);
pci_burst_data(32'ha00280e4, 4'h0, 32'hc0);
pci_burst_data(32'ha00280e8, 4'h0, 32'h600280d0);
pci_burst_data(32'ha00280ec, 4'h0, 32'h516);
/* Writing character 'p' */
/* bbird_font_cache(60, 64, 'p', 0x1); */
/* caching character 'p' */
pci_burst_data(32'ha00280f0, 4'h0, 32'h0);
pci_burst_data(32'ha00280f4, 4'h0, 32'h0);
pci_burst_data(32'ha00280f8, 4'h0, 32'h0);
pci_burst_data(32'ha00280fc, 4'h0, 32'he1fec0ff);
pci_burst_data(32'ha0028100, 4'h0, 32'h3f0e739e);
pci_burst_data(32'ha0028104, 4'h0, 32'h3f0e3f0e);
pci_burst_data(32'ha0028108, 4'h0, 32'h3f6e3f0e);
pci_burst_data(32'ha002810c, 4'h0, 32'hf3fe7fbe);
pci_burst_data(32'ha0028110, 4'h0, 32'hee1ee);
pci_burst_data(32'ha0028114, 4'h0, 32'he000e);
pci_burst_data(32'ha0028118, 4'h0, 32'h1f000e);
pci_burst_data(32'ha0028120, 4'h0, 32'h280f0);
pci_burst_data(32'ha0028124, 4'h0, 32'hb16);
pci_burst_data(32'ha0000020, 4'h0, 32'ha0280e8);
pci_burst_data(32'ha0000024, 4'h0, 32'h3d0020);
pci_burst_data(32'ha0000028, 4'h0, 32'h28120);
pci_burst_data(32'ha000002c, 4'h0, 32'h440020);
/* Writing character 'l' */
/* Writing character 'e' */
/* bbird_font_cache(76, 64, 'e', 0x1); */
/* caching character 'e' */
pci_burst_data(32'ha0028130, 4'h0, 32'h0);
pci_burst_data(32'ha0028134, 4'h0, 32'hf000c000);
pci_burst_data(32'ha0028138, 4'h0, 32'h38007800);
pci_burst_data(32'ha002813c, 4'h0, 32'h7dfe38fc);
pci_burst_data(32'ha0028140, 4'h0, 32'h39c739cf);
pci_burst_data(32'ha0028144, 4'h0, 32'h386738e7);
pci_burst_data(32'ha0028148, 4'h0, 32'h3a1f3937);
pci_burst_data(32'ha002814c, 4'h0, 32'h39fe3b0f);
pci_burst_data(32'ha0028150, 4'h0, 32'h7cfc);
pci_burst_data(32'ha0028154, 4'h0, 32'h0);
pci_burst_data(32'ha0028158, 4'h0, 32'h0);
pci_burst_data(32'ha0028160, 4'h0, 32'h28130);
pci_burst_data(32'ha0028164, 4'h0, 32'ha16);
pci_burst_data(32'ha0000030, 4'h0, 32'ha0280a8);
pci_burst_data(32'ha0000034, 4'h0, 32'h510020);
pci_burst_data(32'ha0000038, 4'h0, 32'h28160);
pci_burst_data(32'ha000003c, 4'h0, 32'h580020);
/* Writing character ' ' */
/* bbird_font_cache(92, 64, ' ', 0x1); */
/* caching character ' ' */
/* Writing character 't' */
/* Writing character 'e' */
pci_burst_data(32'ha0000040, 4'h0, 32'ha0280c8);
pci_burst_data(32'ha0000044, 4'h0, 32'h6b0020);
pci_burst_data(32'ha0000048, 4'h0, 32'h28160);
pci_burst_data(32'ha000004c, 4'h0, 32'h730020);
/* Writing character 's' */
/* bbird_font_cache(92, 64, 's', 0x1); */
/* caching character 's' */
pci_burst_data(32'ha0028170, 4'h0, 32'h0);
pci_burst_data(32'ha0028174, 4'h0, 32'h1c001800);
pci_burst_data(32'ha0028178, 4'h0, 32'h1c001c00);
pci_burst_data(32'ha002817c, 4'h0, 32'h7ffc1cf8);
pci_burst_data(32'ha0028180, 4'h0, 32'h9c9eff1e);
pci_burst_data(32'ha0028184, 4'h0, 32'h1c781c3c);
pci_burst_data(32'ha0028188, 4'h0, 32'h1dc11ce2);
pci_burst_data(32'ha002818c, 4'h0, 32'h1dfe1dc3);
pci_burst_data(32'ha0028190, 4'h0, 32'h78fc);
pci_burst_data(32'ha0028194, 4'h0, 32'h0);
pci_burst_data(32'ha0028198, 4'h0, 32'h0);
pci_burst_data(32'ha00281a0, 4'h0, 32'h28170);
pci_burst_data(32'ha00281a4, 4'h0, 32'h916);
/* Writing character 't' */
pci_burst_data(32'ha0000050, 4'h0, 32'ha0281a0);
pci_burst_data(32'ha0000054, 4'h0, 32'h7f0020);
pci_burst_data(32'ha0000058, 4'h0, 32'h280c8);
pci_burst_data(32'ha000005c, 4'h0, 32'h8a0020);
pci_burst_data(rbase_a+32'hFC,4'h0,32'h60);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h100, 32'h40, "junk", 32'ha00, 2'h2);
