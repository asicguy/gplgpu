///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2014 Francis Bruno, All Rights Reserved
// 
//  This program is free software; you can redistribute it and/or modify it 
//  under the terms of the GNU General Public License as published by the Free 
//  Software Foundation; either version 3 of the License, or (at your option) 
//  any later version.
//
//  This program is distributed in the hope that it will be useful, but 
//  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
//  or FITNESS FOR A PARTICULAR PURPOSE. 
//  See the GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License along with
//  this program; if not, see <http://www.gnu.org/licenses>.
//
//  This code is available under licenses for commercial use. Please contact
//  Francis Bruno for more information.
//
//  http://www.gplgpu.com
//  http://www.asicsolutions.com
//
//  Title       :  
//  File        :  
//  Author      :  Frank Bruno
//  Created     :  14-May-2011
//  RCS File    :  $Source:$
//  Status      :  $Id:$
//
///////////////////////////////////////////////////////////////////////////////
//
//  Description : 
//  2D test suite - 32 Bpp
//
//////////////////////////////////////////////////////////////////////////////
//
//  Modules Instantiated:
//
///////////////////////////////////////////////////////////////////////////////
//
//  Modification History:
//
//  $Log:$
//
//
///////////////////////////////////////////////////////////////////////////////
/* VERILOG logging on. */
/* bbird_set_mode(mode_struct, 0x011); */
/* bbird_set_engine(BBIRD_SELECT_ENGINE_A); */
wait_for_pipe_a;
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h100);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0);
pci_burst_data(rbase_g+INT_VCNT,4'h0,32'h0);
pci_burst_data(rbase_g+INT_HCNT,4'h0,32'h0);
pci_burst_data(rbase_g+DB_ADR,4'h0,32'h0);
pci_burst_data(rbase_g+DB_PTCH,4'h0,32'ha00);
pci_burst_data(rbase_g+CRT_HAC,4'h0,32'ha0);
pci_burst_data(rbase_g+CRT_HBL,4'h0,32'h28);
pci_burst_data(rbase_g+CRT_HFP,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_HS,4'h0,32'h18);
pci_burst_data(rbase_g+CRT_VAC,4'h0,32'h1e0);
pci_burst_data(rbase_g+CRT_VBL,4'h0,32'h2c);
pci_burst_data(rbase_g+CRT_VFP,4'h0,32'ha);
pci_burst_data(rbase_g+CRT_VS,4'h0,32'h4);
pci_burst_data(rbase_g+CRT_BORD,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_ZOOM,4'h0,32'h0);
pci_burst_data(rbase_g+CRT_1CON,4'h0,32'h170);
pci_burst_data(rbase_g+CRT_2CON,4'h0,32'h0+`DISPLAY_MODE);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h0+`BLOCK_MODE);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_src_bitmap(0x0, 0xa00, 0x2000000); */
pci_burst_data(rbase_a+DE_SORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_SPTCH,4'h0,32'ha00);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0xa00, 0x2000000, 0, 0, 63, 15); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'ha00);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h3f000f);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_colors(0xffffffff, 0x0, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'hffffffff);
pci_burst_data(rbase_a+BACK,4'h0,32'h0);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_line_pat(0xffffffff, 0x0); */
pci_burst_data(rbase_a+LPAT,4'h0,32'hffffffff);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h0);
VR.ram_fill32(32'h0, 64, 0);
VR.ram_fill32(32'h280, 64, 0);
VR.ram_fill32(32'h500, 64, 0);
VR.ram_fill32(32'h780, 64, 0);
VR.ram_fill32(32'ha00, 64, 0);
VR.ram_fill32(32'hc80, 64, 0);
VR.ram_fill32(32'hf00, 64, 0);
VR.ram_fill32(32'h1180, 64, 0);
VR.ram_fill32(32'h1400, 64, 0);
VR.ram_fill32(32'h1680, 64, 0);
VR.ram_fill32(32'h1900, 64, 0);
VR.ram_fill32(32'h1b80, 64, 0);
VR.ram_fill32(32'h1e00, 64, 0);
VR.ram_fill32(32'h2080, 64, 0);
VR.ram_fill32(32'h2300, 64, 0);
VR.ram_fill32(32'h2580, 64, 0);
wait_for_pipe_a;
wait_for_pipe_a;
/* bbird_dst_bitmap(0x0, 0xa00, 0x2000000, 0, 0, 63, 15); */
pci_burst_data(rbase_a+DE_DORG,4'h0,32'h0);
pci_burst_data(rbase_a+DE_DPTCH,4'h0,32'ha00);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
pci_burst_data(rbase_a+CLPTL,4'h0,32'h0);
pci_burst_data(rbase_a+CLPBR,4'h0,32'h3f000f);
/* bbird_memxfer_setup(0, 0x8200000, 0xffffffff, 0xf, 0x0, 0xffffffff); */
pci_burst_data(rbase_w+MW0_ORG,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_PGE,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_CTRL,4'h0,32'h8200000);
pci_burst_data(rbase_w+MW0_WKEY,4'h0,32'hf);
pci_burst_data(rbase_w+MW0_KYDAT,4'h0,32'hffffffff);
pci_burst_data(rbase_w+MW0_WSRC,4'h0,32'h0);
pci_burst_data(rbase_w+MW0_MASK,4'h0,32'hffffffff);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x8400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
wait_for_pipe_a;
/* bbird_line_pat(0x16, 0x5); */
pci_burst_data(rbase_a+LPAT,4'h0,32'h16);
pci_burst_data(rbase_a+PCTRL,4'h0,32'h5);
wait_for_pipe_a;
/* bbird_colors(0x1, 0x9, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
pci_burst_data(rbase_a+BACK,4'h0,32'h9);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_rectangle(0x28, 0x8, 0x3b, 0xd); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 0, 40, 8, 20, 6, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h140006);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h280008);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
wait_for_pipe_a;
/* bbird_write_pixel(0x0, 0x2, 0x33333333); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h33333333);
pci_burst_data(rbase_a+XY0,4'h0,32'h2);
pci_burst_data(rbase_a+XY1,4'h0,32'h2);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
wait_for_pipe_a;
/* bbird_write_pixel(0x2, 0x3, 0x33333333); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h33333333);
pci_burst_data(rbase_a+XY0,4'h0,32'h20003);
pci_burst_data(rbase_a+XY1,4'h0,32'h20003);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h1);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
pci_burst_data(32'h40000004, 4'h0, 32'h01020300);
wait_for_pipe_a;
/* bbird_write_pixel(0x8, 0x7, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h80007);
pci_burst_data(rbase_a+XY1,4'h0,32'h80007);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x9, 0x8, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h90008);
pci_burst_data(rbase_a+XY1,4'h0,32'h90008);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0xa, 0x9, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'ha0009);
pci_burst_data(rbase_a+XY1,4'h0,32'ha0009);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0xb, 0x5, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'hb0005);
pci_burst_data(rbase_a+XY1,4'h0,32'hb0005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x5, 0x6, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h50006);
pci_burst_data(rbase_a+XY1,4'h0,32'h50006);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x6, 0x7, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h60007);
pci_burst_data(rbase_a+XY1,4'h0,32'h60007);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x7, 0x8, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h70008);
pci_burst_data(rbase_a+XY1,4'h0,32'h70008);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x8, 0x9, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h80009);
pci_burst_data(rbase_a+XY1,4'h0,32'h80009);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x9, 0x5, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h90005);
pci_burst_data(rbase_a+XY1,4'h0,32'h90005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0xa, 0x6, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'ha0006);
pci_burst_data(rbase_a+XY1,4'h0,32'ha0006);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0xb, 0x7, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'hb0007);
pci_burst_data(rbase_a+XY1,4'h0,32'hb0007);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x5, 0x8, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h50008);
pci_burst_data(rbase_a+XY1,4'h0,32'h50008);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x6, 0x9, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h60009);
pci_burst_data(rbase_a+XY1,4'h0,32'h60009);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x7, 0x5, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h70005);
pci_burst_data(rbase_a+XY1,4'h0,32'h70005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x8, 0x6, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h80006);
pci_burst_data(rbase_a+XY1,4'h0,32'h80006);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_write_pixel(0x9, 0x7, 0x2); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'h2);
pci_burst_data(rbase_a+XY0,4'h0,32'h90007);
pci_burst_data(rbase_a+XY1,4'h0,32'h90007);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h8400c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_colors(0x12, 0x11, 0x0, 0x0); */
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
pci_burst_data(rbase_a+BACK,4'h0,32'h11);
pci_burst_data(rbase_a+DE_KEY,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x410c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h410c00);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0xc00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'hc00);
/* bbird_area_pattern(0x0, 0x74, 0x2080000); */
wait_for_pipe_a;
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h42000300+`BLOCK_MODE);
pci_burst_data(rbase_a+CMD,4'h0,32'hc01);
pci_burst_data(rbase_a+XY0,4'h0,32'h0);
pci_burst_data(rbase_a+XY2,4'h0,32'h200001);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
/* write_bitmap(0x800ff14, 0x0, 0x20, 1); */
pci_burst_data(32'h10000000, 4'h0, 32'h0);
pci_burst_data(32'h10000004, 4'h0, 32'h3c000);
pci_burst_data(32'h10000008, 4'h0, 32'h1c3800);
pci_burst_data(32'h1000000c, 4'h0, 32'h600600);
pci_burst_data(32'h10000010, 4'h0, 32'h8c3100);
pci_burst_data(32'h10000014, 4'h0, 32'h1142880);
pci_burst_data(32'h10000018, 4'h0, 32'h1181880);
pci_burst_data(32'h1000001c, 4'h0, 32'h2018040);
pci_burst_data(32'h10000020, 4'h0, 32'h203c040);
pci_burst_data(32'h10000024, 4'h0, 32'h1100880);
pci_burst_data(32'h10000028, 4'h0, 32'h10c3080);
pci_burst_data(32'h1000002c, 4'h0, 32'h83c100);
pci_burst_data(32'h10000030, 4'h0, 32'h600600);
pci_burst_data(32'h10000034, 4'h0, 32'h1c3800);
pci_burst_data(32'h10000038, 4'h0, 32'h3c000);
pci_burst_data(32'h1000003c, 4'h0, 32'h0);
pci_burst_data(32'h10000040, 4'h0, 32'h0);
pci_burst_data(32'h10000044, 4'h0, 32'h3c000);
pci_burst_data(32'h10000048, 4'h0, 32'h1c3800);
pci_burst_data(32'h1000004c, 4'h0, 32'h600600);
pci_burst_data(32'h10000050, 4'h0, 32'h8c3100);
pci_burst_data(32'h10000054, 4'h0, 32'h1142880);
pci_burst_data(32'h10000058, 4'h0, 32'h1181880);
pci_burst_data(32'h1000005c, 4'h0, 32'h2018040);
pci_burst_data(32'h10000060, 4'h0, 32'h203c040);
pci_burst_data(32'h10000064, 4'h0, 32'h1100880);
pci_burst_data(32'h10000068, 4'h0, 32'h10c3080);
pci_burst_data(32'h1000006c, 4'h0, 32'h83c100);
pci_burst_data(32'h10000070, 4'h0, 32'h600600);
pci_burst_data(32'h10000074, 4'h0, 32'h1c3800);
pci_burst_data(32'h10000078, 4'h0, 32'h3c000);
pci_burst_data(32'h1000007c, 4'h0, 32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h74);
pci_burst_data(rbase_a+BUF_CTRL,4'h0,32'h2000000+`BLOCK_MODE);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x400c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h400c00);
wait_for_pipe_a;
/* bbird_flags(0xffffffff, 0x0, 0x24a0c00, 0x0); */
pci_burst_data(rbase_a+MASK,4'h0,32'hffffffff);
pci_burst_data(rbase_a+CMD,4'h0,32'h24a0c00);
wait_for_pipe_a;
/* bbird_bitblit(0, 116, 0, 0, 63, 13, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h3f000d);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h74);
pci_burst_data(rbase_a+XY1,4'h0,32'h0);
wait_for_pipe_a;
/* bbird_bitblit(0, 116, 7, 6, 3, 2, 0, 0); */
pci_burst_data(rbase_a+CMD_OPC,4'h0,32'h1);
pci_burst_data(rbase_a+XY2,4'h0,32'h30002);
pci_burst_data(rbase_a+XY3,4'h0,32'h0);
pci_burst_data(rbase_a+XY4,4'h0,32'h0);
pci_burst_data(rbase_a+XY0,4'h0,32'h74);
pci_burst_data(rbase_a+XY1,4'h0,32'h70006);
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD_ROP,4'h0,32'h0);
pci_burst_data(rbase_a+XY1,4'h0,32'h70006);
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD_ROP,4'h0,32'h1);
pci_burst_data(rbase_a+XY1,4'h0,32'ha0006);
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD_ROP,4'h0,32'h2);
pci_burst_data(rbase_a+XY1,4'h0,32'hd0006);
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD_ROP,4'h0,32'h3);
pci_burst_data(rbase_a+XY1,4'h0,32'h100006);
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD_ROP,4'h0,32'h4);
pci_burst_data(rbase_a+XY1,4'h0,32'h130006);
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD_ROP,4'h0,32'h5);
pci_burst_data(rbase_a+XY1,4'h0,32'h160006);
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD_ROP,4'h0,32'h6);
pci_burst_data(rbase_a+XY1,4'h0,32'h190006);
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD_ROP,4'h0,32'h7);
pci_burst_data(rbase_a+XY1,4'h0,32'h1c0006);
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD_ROP,4'h0,32'h8);
pci_burst_data(rbase_a+XY1,4'h0,32'h1f0006);
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD_ROP,4'h0,32'h9);
pci_burst_data(rbase_a+XY1,4'h0,32'h220006);
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD_ROP,4'h0,32'ha);
pci_burst_data(rbase_a+XY1,4'h0,32'h250006);
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD_ROP,4'h0,32'hb);
pci_burst_data(rbase_a+XY1,4'h0,32'h280006);
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD_ROP,4'h0,32'hc);
pci_burst_data(rbase_a+XY1,4'h0,32'h2b0006);
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD_ROP,4'h0,32'hd);
pci_burst_data(rbase_a+XY1,4'h0,32'h2e0006);
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD_ROP,4'h0,32'he);
pci_burst_data(rbase_a+XY1,4'h0,32'h310006);
wait_for_pipe_a;
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD_ROP,4'h0,32'hf);
pci_burst_data(rbase_a+XY1,4'h0,32'h340006);
wait_for_pipe_a;
rd(MEM_RD, 32'h40000000, 1);
wait_for_pipe_a;
/* bbird_write_pixel(0x2, 0x5, 0xcc); */
pci_burst_data(rbase_a+CMD,4'h0,32'h8410c02);
pci_burst_data(rbase_a+FORE,4'h0,32'hcc);
pci_burst_data(rbase_a+XY0,4'h0,32'h20005);
pci_burst_data(rbase_a+XY1,4'h0,32'h20005);
wait_for_pipe_a;
pci_burst_data(rbase_a+CMD,4'h0,32'h24a0c00);
pci_burst_data(rbase_a+FORE,4'h0,32'h12);
wait_for_pipe_a;
/* bbird_engine_wait(BBIRD_WAIT_DONE); */
wait_for_de_a;
wait_for_mc_a;
VR.save_fbmp(32'h0, 32'h40, 32'h10, "junk", 32'ha00, 2'h2);
